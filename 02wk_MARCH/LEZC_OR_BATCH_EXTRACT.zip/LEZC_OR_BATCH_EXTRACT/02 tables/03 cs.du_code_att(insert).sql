insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('LEZC', 'CAS_PERMIT_NO', ' ');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('LEZC', 'CAS_PERMIT_NO_DESCR', 'BIR Permit to use no.:');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('LEZC', 'CAS_PERMIT_NO_DESCR_OLD_0', 'CAS BIR Permit No.');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('LEZC', 'CAS_PERMIT_NO_DESCR_OLD_1', 'Permit to use (PTU) No.');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('LEZC', 'CAS_PERMIT_NO_OLD_0', ' ');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('LEZC', 'CAS_PERMIT_NO_SEPARATOR', '_PTU_CAS_');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('LEZC', 'DATA_SOURCE', 'CCB');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('LEZC', 'DATE_OF_ISSUANCE', '04/12/2016');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('LEZC', 'DATE_OF_ISSUANCE_DESCR', 'Date of Issuance:');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('LEZC', 'CAS_PERMIT_AC_DESCR', 'Acknowledgment Certificate No.:');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('LEZC', 'SEQ_AC_DESCR', 'Series:');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('LEZC', 'CAS_PERMIT_ON_OLD_0', 'On :');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('LEZC', 'VERSION_RELEASE_1', 'This is BIR approved system generated report from Online Receipting System Version 2 Release 2');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('LEZC', 'GENERATED_MSG_NEW', ' ');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('LEZC', 'GET_OLD2_PERMIT_EFF_FROM', '08/01/2020');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('LEZC', 'GET_OLD2_PERMIT_EFF_TO', '06/30/2022');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('LEZC', 'DU_ADDRESS', 'LIMA Square Loop, LIMA Technology Center Bugtong na Pulo 4217 Lipa City, Batangas Philippines');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('LEZC', 'DU_BUS_STYLE', 'Lima Enerzone Corporation');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('LEZC', 'DU_EMAIL', ' ');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('LEZC', 'DU_FACEBOOK', ' ');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('LEZC', 'DU_TEL_NO', '043-406-0301');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('LEZC', 'DU_TIN', '005-183-049-00000');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('LEZC', 'EFFECTIVE_DATE_DESCR', 'Effective Date:');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('LEZC', 'EFFECTIVE_DATE_FROM', '08/01/2020');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('LEZC', 'EFFECTIVE_DATE_TO', '07/31/2025');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('LEZC', 'END_SEQ_0', '199999999');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('LEZC', 'END_SEQ_1', '399999999');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('LEZC', 'GENERATED_MSG', 'THIS IS A SYSTEM GENERATED OFFICIAL RECEIPT');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('LEZC', 'GENERATED_MSG_AR', 'THIS DOCUMENT IS NOT VALID FOR CLAIM OF INPUT TAX');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('LEZC', 'GENERATED_MSG_OR', 'THIS RECEIPT SHALL BE VALID FOR FIVE(5) YEARS FROM THE DATE OF PERMIT TO USE');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('LEZC', 'GET_NEW_PERMIT_EFF', '09/13/2022');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('LEZC', 'GET_OLD_PERMIT_EFF_FROM', '07/01/2022');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('LEZC', 'GET_OLD_PERMIT_EFF_TO', '09/12/2022');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('LEZC', 'OR_PREFFIX', ' ');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('LEZC', 'SEQ_DESCR', 'Series No.:');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('LEZC', 'START_SEQ_0', '1');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('LEZC', 'START_SEQ_1', '300000001');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('LEZC', 'VERSION_RELEASE', 'This is BIR approved system generated report from Online Receipting System Version 2 Release 2 No Signature is required.');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('LEZC', 'DU_WEBSITE', ' ');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('LEZC', 'DU_TWITTER', ' ');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('LEZC', 'DEFAULT_REVENUE_TAG', 'VATABLE');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('LEZC', 'DU_TEL_NO_1', '043-981-0876');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('LEZC', 'LEZC_FOOTER', 'This receipt was validated by LIMA. Thank you.');

