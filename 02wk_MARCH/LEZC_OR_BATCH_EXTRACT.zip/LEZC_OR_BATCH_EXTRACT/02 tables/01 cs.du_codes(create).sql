-- Create table
create table DU_CODES
(
  du_code        VARCHAR2(10) not null,
  du_description VARCHAR2(100),
  status         VARCHAR2(1) default 'A',
  du_logo        BLOB
);
-- Create/Recreate primary, unique and foreign key constraints 
alter table DU_CODES
  add constraint DU_LOGS_PK primary key (DU_CODE);
-- Grant/Revoke object privileges 
grant select on DU_CODES to KATAMBAK_USER;
