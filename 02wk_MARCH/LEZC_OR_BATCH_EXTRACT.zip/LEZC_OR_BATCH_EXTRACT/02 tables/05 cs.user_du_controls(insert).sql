

insert into cs.user_du_controls (USERNAME, DU_CODE)
values ('CS', 'BEZC');

commit;
