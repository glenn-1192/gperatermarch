-- Create table
create table DU_CODE_ATT
(
  du_code   VARCHAR2(10) not null,
  att_code  VARCHAR2(30) not null,
  att_value VARCHAR2(500)
);

-- Create/Recreate primary, unique and foreign key constraints 
alter table DU_CODE_ATT
  add constraint DU_CODE_ATT_PK primary key (DU_CODE, ATT_CODE);
-- Grant/Revoke object privileges 
grant select on DU_CODE_ATT to KATAMBAK_USER;
