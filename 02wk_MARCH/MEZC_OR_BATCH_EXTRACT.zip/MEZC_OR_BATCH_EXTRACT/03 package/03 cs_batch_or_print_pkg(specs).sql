create or replace package cs_batch_or_print_pkg as

  function blob2img(p_blob in blob) return clob;

  function get_du_address(p_du_code in varchar2, p_batch_no in number, p_tran_no in number)
    return varchar2;

  function get_du_prefix(p_du_code in varchar2, p_batch_no in number, p_tran_no in number) return varchar2;

  function get_tin_prefix(p_du_code in varchar2, p_batch_no in number) return varchar2;

  function get_receipt_prefix(p_du_code in varchar2, p_tran_no in number) return varchar2;

  function get_du_tin(p_du_code in varchar2, p_batch_no in number) return varchar2;

  function get_or_footer_info(p_du_code in varchar2,p_batch_no in number, p_tran_no in number, p_or_no in number, p_ext_batch_no in number
                              )
    return varchar2 ;

  function get_site_info(p_site_code    in varchar2,
                         p_collector_no in number,
                         p_or_count     in number) return varchar2;

  function get_total_change(p_ext_batch_no in number, p_tran_no in number)
    return number;

  function get_total_amount_received(p_ext_batch_no in number,
                                     p_tran_no      in number) return number;

  function get_total_cash(p_ext_batch_no in number, p_tran_no in number)
    return number;

  function get_cas_permit_info(p_du_code in varchar2, p_tag in varchar2,
                               p_batch_no in number,
                               p_tran_no in number,
                               p_or_no in number,
                               p_ext_batch_no in number)
    return varchar2;

  function get_cas_serial_no(p_receipt_type varchar2,
                             p_du_code      in varchar2,
                             p_tag          in varchar2
                             ) return varchar2;

  function get_forms_of_payment(p_ext_batch_no in number,
                                p_tran_no      in number) return varchar2;

  function get_payer_name(p_last_name   in varchar2,
                          p_first_name  in varchar2,
                          p_middle_name in varchar2) return varchar2;

  function get_entry(p_du_code in varchar2, p_att_code in varchar)
    return varchar2;

end cs_batch_or_print_pkg;
