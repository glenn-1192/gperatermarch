

insert into cs.du_codes (DU_CODE, DU_DESCRIPTION, STATUS)
values ('MEZC', 'Mactan Enerzone Corporation', 'A');

commit;
