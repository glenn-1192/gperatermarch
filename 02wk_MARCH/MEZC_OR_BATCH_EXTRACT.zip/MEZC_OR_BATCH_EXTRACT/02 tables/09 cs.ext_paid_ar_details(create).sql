-- Create table
create table EXT_PAID_AR_DETAILS
(
  ext_batch_no    NUMBER not null,
  tran_no         NUMBER not null,
  seq_no          NUMBER(3) not null,
  acct_no         NUMBER,
  bill_no         VARCHAR2(12),
  bill_month      DATE,
  bill_date       DATE,
  due_date        DATE,
  ar_balance      NUMBER(15,2),
  org_bill_amount NUMBER(15,2)
);
-- Create/Recreate primary, unique and foreign key constraints 
alter table EXT_PAID_AR_DETAILS
  add constraint EXT_PAID_AR_DTLS_PK primary key (EXT_BATCH_NO, TRAN_NO, SEQ_NO);
alter table EXT_PAID_AR_DETAILS
  add constraint EXT_PAID_AR_DTLS_FK foreign key (EXT_BATCH_NO, TRAN_NO)
  references EXT_PAYMENT_TRANSACTIONS (EXT_BATCH_NO, TRAN_NO);
-- Grant/Revoke object privileges 
grant select on EXT_PAID_AR_DETAILS to KATAMBAK_USER;
