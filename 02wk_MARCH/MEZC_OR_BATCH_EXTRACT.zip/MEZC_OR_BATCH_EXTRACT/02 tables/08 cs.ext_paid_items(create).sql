-- Create table
create table EXT_PAID_ITEMS
(
  ext_batch_no  NUMBER not null,
  tran_no       NUMBER not null,
  seq_no        NUMBER(3) not null,
  pay_code      VARCHAR2(30),
  amount_credit NUMBER(15,2),
  bill_no       VARCHAR2(12)
);
-- Create/Recreate primary, unique and foreign key constraints 
alter table EXT_PAID_ITEMS
  add constraint EXT_PAID_ITEMS_PK primary key (EXT_BATCH_NO, TRAN_NO, SEQ_NO);
  
alter table EXT_PAID_ITEMS
  add constraint EXT_PAID_ITEMS_FK foreign key (EXT_BATCH_NO, TRAN_NO)
  references EXT_PAYMENT_TRANSACTIONS (EXT_BATCH_NO, TRAN_NO);
-- Grant/Revoke object privileges 
grant select on EXT_PAID_ITEMS to KATAMBAK_USER;
