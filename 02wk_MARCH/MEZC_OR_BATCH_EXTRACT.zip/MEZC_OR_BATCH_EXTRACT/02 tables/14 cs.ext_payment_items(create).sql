-- Create table
create table EXT_PAYMENT_ITEMS
(
  pay_code          VARCHAR2(20) not null,
  description       VARCHAR2(100),
  gl_acct_code      VARCHAR2(100),
  print_label       VARCHAR2(100),
  feedback_proc     VARCHAR2(100),
  pay_priority      NUMBER(4),
  ar_credit         NUMBER(1),
  miscellaneous     NUMBER(1),
  ar                NUMBER(1),
  print_priority    NUMBER,
  misc_vatable      NUMBER(1),
  misc_default_amt  NUMBER(10,2),
  misc_vat_pay_code VARCHAR2(20),
  dst_id            VARCHAR2(10),
  tender_type_cd    VARCHAR2(4)
);
-- Create/Recreate primary, unique and foreign key constraints 
alter table EXT_PAYMENT_ITEMS
  add constraint EXT_PAYMENT_ITEMS_PK primary key (PAY_CODE);
-- Grant/Revoke object privileges 
grant select on EXT_PAYMENT_ITEMS to KATAMBAK_USER;
