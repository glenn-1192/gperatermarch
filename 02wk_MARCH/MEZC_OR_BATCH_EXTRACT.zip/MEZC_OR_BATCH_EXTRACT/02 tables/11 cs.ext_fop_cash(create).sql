-- Create table
create table EXT_FOP_CASH
(
  ext_batch_no    NUMBER not null,
  tran_no         NUMBER not null,
  seq_no          NUMBER(3) not null,
  amount_tendered NUMBER(15,2)
);
-- Create/Recreate primary, unique and foreign key constraints 
alter table EXT_FOP_CASH
  add constraint EXT_FOP_CASH_PK primary key (EXT_BATCH_NO, TRAN_NO, SEQ_NO);
alter table EXT_FOP_CASH
  add constraint EXT_FOP_CASH_FK foreign key (EXT_BATCH_NO, TRAN_NO, SEQ_NO)
  references EXT_FORMS_OF_PAYMENTS (EXT_BATCH_NO, TRAN_NO, SEQ_NO);
-- Grant/Revoke object privileges 
grant select on EXT_FOP_CASH to KATAMBAK_USER;
