create or replace package body cs_batch_or_print_pkg as

  /*
       revision history
                
                v1.0.0 by gperater on march 07, 2024
                       purpose of change : newly created package for the sole purpose of installing clpc or batch extract, functions and procedure
                                           cascaded from dlpc or batch extract
                       remarks : new functions and procedures created
                                           

  */

  function blob2img(p_blob in blob) return clob is
    l_clob clob;
    l_step pls_integer := 12000;
  begin
    for i in 0 .. trunc((dbms_lob.getlength(p_blob) - 1) / l_step) loop
      l_clob := l_clob ||
                utl_raw.cast_to_varchar2(utl_encode.base64_encode(dbms_lob.substr(p_blob,
                                                                                  l_step,
                                                                                  i *
                                                                                  l_step + 1)));
    end loop;
    return l_clob;
  end blob2img;

  function get_du_address(p_du_code in varchar2, p_batch_no in number, p_tran_no in number)
    return varchar2 as

  l_br_address varchar(500);
  l_last_digit varchar2(5);
  begin
    declare
       l_three_digit varchar2(5);
    begin
    select pst.last_3_digit
    into l_three_digit
    from
           payment_transactions pt,
           collection_batches cb,
           pop_sites_tin pst

           where pt.batch_no = cb.batch_no
           and   cb.site_code = pst.site_code
           and   cb.batch_no = p_batch_no
           and   pt.tran_no = p_tran_no;

   l_last_digit := l_three_digit;

   if l_last_digit = 001
   then
   l_br_address :=  cs_batch_or_print_pkg.get_entry(p_du_code  => p_du_code,
                                                    p_att_code => 'DU_ADDRESS');

   /*elsif l_last_digit = 003
   then
     l_br_address :=  cs_batch_or_print_pkg.get_entry(p_du_code  => p_du_code,
                                                      p_att_code => 'DU_ADDRESS_003');

   elsif l_last_digit = 004
   then
     l_br_address :=  cs_batch_or_print_pkg.get_entry(p_du_code  => p_du_code,
                                                      p_att_code => 'DU_ADDRESS_004');

   elsif l_last_digit = 005
   then
     l_br_address :=  cs_batch_or_print_pkg.get_entry(p_du_code  => p_du_code,
                                                      p_att_code => 'DU_ADDRESS_005');

   elsif l_last_digit in (002,006,008,009)
   then
     l_br_address :=  cs_batch_or_print_pkg.get_entry(p_du_code  => p_du_code,
                                                      p_att_code => 'DU_ADDRESS');*/

   end if;

   exception
      when no_data_found
        then null;

    end;

    return l_br_address;

  end get_du_address;

  function get_du_prefix(p_du_code in varchar2, p_batch_no in number, p_tran_no in number) return varchar2
    as

    l_orar_prefix varchar2(5);
    --l_receipt_prefix varchar2(2);
    l_receipt_prefix_orar varchar2(2);
    --l_tin_prefix varchar2(30);
    l_tin_prefix_orar varchar2(30);

    begin
      l_receipt_prefix_orar := cs_batch_or_print_pkg.get_receipt_prefix(p_du_code => p_du_code,
                                                                        p_tran_no => p_tran_no);

      l_tin_prefix_orar := cs_batch_or_print_pkg.get_tin_prefix(p_du_code => p_du_code,
                                                                p_batch_no => p_batch_no);

      l_orar_prefix := l_receipt_prefix_orar || l_tin_prefix_orar;

    return l_orar_prefix;

  end get_du_prefix;


  function get_tin_prefix(p_du_code in varchar2, p_batch_no in number) return varchar2
   as
      l_tin varchar2(4);
   begin
      begin
         select tin.last_3_digit
         into   l_tin
         from   collection_batches batches,
                pop_sites_tin tin
         where  batches.site_code = tin.site_code
         and    batches.batch_no  = p_batch_no;

         l_tin := l_tin; --||'-';
      exception
         when no_data_found
         then
            null;
      end;

      return l_tin;

   end get_tin_prefix;

  function get_receipt_prefix(p_du_code in varchar2, p_tran_no in number) return varchar2
   as

      l_code varchar2(2) := ' ';
      l_found  number(1);
   begin
      begin
         select 1
         into   l_found
         from   ext_paid_items trans,
                ar_pay_codes ar
         where  trans.pay_code = ar.pay_code
         and    trans.tran_no  = p_tran_no;

         l_code := 'N';
      exception
         when too_many_rows
         then
            l_code := 'N';
         when no_data_found
         then
            l_code := '';
      end;
         return l_code;
   end get_receipt_prefix;


  function get_du_tin (p_du_code in varchar2, p_batch_no in number)
           return varchar2 as

  l_du_tin varchar2(30);

  begin
    declare
           l_tin varchar2(30);
    begin
           select tin
           into l_tin
           from pop_sites_tin a,
                collection_batches b
           where a.site_code = b.site_code
           and   b.batch_no = p_batch_no;

    l_du_tin := l_tin;

    exception
      when no_data_found
        then null;

    end;

    return l_du_tin;

  end get_du_tin;

  function get_or_footer_info(p_du_code in varchar2,p_batch_no in number, p_tran_no in number, p_or_no in number, p_ext_batch_no in number)
    return varchar2 as

    l_or_footer varchar2(200);
  begin

                declare
                          l_cas_permit_no varchar2(100);
                          l_issued_on varchar2(50);
                          l_receipt_prefix varchar2(2);
                          l_last_digit varchar2(5);
                          l_or_date date;

                          l_or_start number;
                          l_or_end   number;
                          l_ar_start number;
                          l_ar_end   number;
                begin
                  select  substr(tin.cas_permit_no,1,30) cas_permit_no, --tin.cas_permit_no,
                          to_char(tin.issued_on, 'MM/DD/YYYY'),
                          cs_or_pkg.get_receipt_prefix(p_tran_no),
                          tin.last_3_digit,
                          trunc(pt.or_date)
            into   l_cas_permit_no,
                   l_issued_on,
                   l_receipt_prefix,
                   l_last_digit,
                   l_or_date
            from
                    collection_batches batches,
                    pop_sites_tin      tin,
                    ext_payment_transactions pt,
                    or_extract_params oep
            where   batches.site_code = tin.site_code
            and     batches.batch_no = pt.batch_no
            and     oep.ext_batch_no = pt.ext_batch_no
            and     pt.or_no = p_or_no
            and     oep.ext_batch_no = p_ext_batch_no
            and     batches.batch_no = p_batch_no
            and     pt.tran_no = p_tran_no;

            select or_series_start,
                   or_series_end,
                   ar_series_start,
                   ar_series_end
            into l_or_start,
                 l_or_end,
                 l_ar_start,
                 l_ar_end
            from   cas_permit_config
            where  cas_permit_no = l_cas_permit_no
            and    last_3_digit = l_last_digit;

            if l_or_date >= to_date('09/22/2022','mm/dd/yyyy')
            then

            if l_receipt_prefix is null
            then
        l_or_footer := cs_batch_or_print_pkg.get_entry(p_du_code  => p_du_code,p_att_code => 'CAS_PERMIT_AC_DESCR')--'Acknowledgement Certificate No.:'
                       || l_cas_permit_no --tin.cas_permit_no
                       || ' '
                       || cs_batch_or_print_pkg.get_entry(p_du_code  => p_du_code,p_att_code => 'DATE_OF_ISSUANCE_DESCR') --' Date of Issuance:'
                       || l_issued_on --to_char(tin.issued_on, 'MM/DD/YYYY')
                       || ' '
                       || cs_batch_or_print_pkg.get_entry(p_du_code  => p_du_code,p_att_code => 'SEQ_AC_DESCR') --'Series:'
                       || l_receipt_prefix --get_receipt_prefix(p_tran_no)
                       || l_last_digit --tin.last_3_digit
                       || '-'
                       || to_char(l_or_start, 'fm000000000')
                       || '-'
                       || l_receipt_prefix --get_receipt_prefix(p_tran_no)
                       || l_last_digit --tin.last_3_digit
                       || '-'
                       || l_or_end; --'999999999'

        else l_receipt_prefix := 'N';
        l_or_footer := cs_batch_or_print_pkg.get_entry(p_du_code  => p_du_code,p_att_code => 'CAS_PERMIT_AC_DESCR') --'Acknowledgement Certificate No.:'
                        || l_cas_permit_no --tin.cas_permit_no
                        || ' '
                        || cs_batch_or_print_pkg.get_entry(p_du_code  => p_du_code,p_att_code => 'DATE_OF_ISSUANCE_DESCR') --' Date of Issuance:'
                        || l_issued_on --to_char(tin.issued_on, 'MM/DD/YYYY')
                        || ' '
                        || cs_batch_or_print_pkg.get_entry(p_du_code  => p_du_code,p_att_code => 'SEQ_AC_DESCR') --'Series:'
                        || l_receipt_prefix --get_receipt_prefix(p_tran_no)
                        || l_last_digit --tin.last_3_digit
                        || '-'
                        || to_char(l_ar_start, 'fm000000000')
                        || '-'
                        || l_receipt_prefix --get_receipt_prefix(p_tran_no)
                        || l_last_digit --tin.last_3_digit
                        || '-'
                        || l_ar_end; --'999999999'


        end if;
     end if;

     /*if l_or_date <= to_date('09/21/2022','mm/dd/yyyy')
      then
       l_or_footer := cs_batch_or_print_pkg.get_entry(p_du_code  => p_du_code,p_att_code => 'CAS_PERMIT_NO_DESCR') --'BIR Permit to use no.:'
                   || substr(cs_batch_or_print_pkg.get_entry(p_du_code  => p_du_code,p_att_code => 'CAS_PERMIT_NO'),1,30) --'04-2016-123-0008-00006'
                   || ' '
                   || cs_batch_or_print_pkg.get_entry(p_du_code  => p_du_code,p_att_code => 'DATE_OF_ISSUANCE_DESCR') --'Date of Issuance:'
                   || cs_batch_or_print_pkg.get_entry(p_du_code  => p_du_code,p_att_code => 'DATE_OF_ISSUANCE') --to_date('04/12/2016','mm/dd/yyyy')
                   || ' '
                   --|| cs_batch_or_print_pkg.get_entry(p_du_code  => p_du_code,p_att_code => 'EFFECTIVE_DATE_DESCR') --'Effective Date'
                   --|| ' '
                   --|| cs_batch_or_print_pkg.get_entry(p_du_code  => p_du_code,p_att_code => 'EFFECTIVE_DATE_FROM')--'08/01/2020'
                   --|| '-'
                   --|| cs_batch_or_print_pkg.get_entry(p_du_code  => p_du_code,p_att_code => 'EFFECTIVE_DATE_TO')--'09/26/2022'
                   --|| ' '
                   || cs_batch_or_print_pkg.get_entry(p_du_code  => p_du_code,p_att_code => 'SEQ_AC_DESCR') --'Series No.:' SEQ_AC_DESCR
                   || cs_batch_or_print_pkg.get_entry(p_du_code  => p_du_code,p_att_code => 'START_SEQ_0')--'1000000001'
                   || '-'
                   || cs_batch_or_print_pkg.get_entry(p_du_code  => p_du_code,p_att_code => 'END_SEQ_0');--'1999999999';
    end if;*/



    exception
      when no_data_found then
        null;
    end;

    return l_or_footer;

  end get_or_footer_info;

  function get_site_info(p_site_code    in varchar2,
                         p_collector_no in number,
                         p_or_count     in number) return varchar2 as
    l_site_code varchar2(300);
  begin
    l_site_code := p_site_code;
    if p_collector_no is not null then
      if l_site_code is not null then
        l_site_code := l_site_code || '-';
      end if;

      l_site_code := l_site_code || p_collector_no;
    end if;

    if p_or_count is not null then
      if l_site_code is not null then
        l_site_code := l_site_code || '-';
      end if;

      l_site_code := l_site_code || p_or_count;
    end if;

    return l_site_code;
  end get_site_info;

  function get_total_change(p_ext_batch_no in number, p_tran_no in number)
    return number as
    l_total_cash number;
    l_change     number;
  begin
    l_total_cash := cs_batch_or_print_pkg.get_total_cash(p_ext_batch_no => p_ext_batch_no,
                                                         p_tran_no      => p_tran_no);

    select l_total_cash - nvl(sum(amount_paid), 0)
      into l_change
      from ext_forms_of_payments
     where ext_batch_no = p_ext_batch_no
       and tran_no = p_tran_no
       and payment_type = 'CASH';

    return nvl(l_change, 0);
  end get_total_change;

  function get_total_amount_received(p_ext_batch_no in number,
                                     p_tran_no      in number) return number as
    l_total_cash            number;
    l_total_amount_received number;
  begin
    l_total_cash := cs_batch_or_print_pkg.get_total_cash(p_ext_batch_no => p_ext_batch_no,
                                                         p_tran_no      => p_tran_no);

    select nvl(sum(amount_paid), 0) + l_total_cash
      into l_total_amount_received
      from ext_forms_of_payments
     where ext_batch_no = p_ext_batch_no
       and tran_no = p_tran_no
       and payment_type != 'CASH';

    return nvl(l_total_amount_received, 0);
  end get_total_amount_received;

  function get_total_cash(p_ext_batch_no in number, p_tran_no in number)
    return number as
    l_cash number;
  begin
    select nvl(sum(amount_tendered), 0)
      into l_cash
      from ext_fop_cash
     where ext_batch_no = p_ext_batch_no
       and tran_no = p_tran_no;

    return nvl(l_cash, 0);
  end get_total_cash;

  function get_cas_permit_info(p_du_code in varchar2, p_tag in varchar2,
                               p_batch_no in number,
                               p_tran_no in number,
                               p_or_no in number,
                               p_ext_batch_no in number)
    return varchar2 as
    l_cas_permit       varchar2(600);
    l_cas_permit_descr du_code_att.att_value%type;
    l_cas_permit_no    du_code_att.att_value%type;
    l_cas_permit_on    du_code_att.att_value%type;
    l_cas_permit_septr du_code_att.att_value%type;
    l_issuance_descr   du_code_att.att_value%type;
    l_issuance_date    du_code_att.att_value%type;
    l_eff_dt_descr     du_code_att.att_value%type;
    l_eff_dt_from      du_code_att.att_value%type;
    l_eff_dt_to        du_code_att.att_value%type;
  begin
    if p_tag in ('OLD_0','OLD_2') then
      l_cas_permit_descr := cs_batch_or_print_pkg.get_entry(p_du_code  => p_du_code,
                                                            p_att_code => 'CAS_PERMIT_NO_DESCR_OLD_0');
      l_cas_permit_no    := cs_batch_or_print_pkg.get_entry(p_du_code  => p_du_code,
                                                            p_att_code => 'CAS_PERMIT_NO_OLD_0');
      l_cas_permit_on    := cs_batch_or_print_pkg.get_entry(p_du_code  => p_du_code,
                                                            p_att_code => 'CAS_PERMIT_ON_OLD_0');
      l_issuance_date    := cs_batch_or_print_pkg.get_entry(p_du_code  => p_du_code,
                                                            p_att_code => 'DATE_OF_ISSUANCE');
      l_cas_permit       := l_cas_permit_descr || ' ' || l_cas_permit_no || ' ' || l_cas_permit_on || ' ' || l_issuance_date;
    elsif p_tag = 'OLD_1' then
      l_cas_permit_descr := cs_batch_or_print_pkg.get_entry(p_du_code  => p_du_code,
                                                            p_att_code => 'CAS_PERMIT_NO_DESCR');
      l_cas_permit_no    := cs_batch_or_print_pkg.get_entry(p_du_code  => p_du_code,
                                                            p_att_code => 'CAS_PERMIT_NO');
      l_issuance_descr    := cs_batch_or_print_pkg.get_entry(p_du_code  => p_du_code,
                                                            p_att_code => 'DATE_OF_ISSUANCE_DESCR');
       l_issuance_date    := cs_batch_or_print_pkg.get_entry(p_du_code  => p_du_code,
                                                            p_att_code => 'DATE_OF_ISSUANCE');
      l_eff_dt_descr    := cs_batch_or_print_pkg.get_entry(p_du_code  => p_du_code,
                                                            p_att_code => 'EFFECTIVE_DATE_DESCR');
       l_eff_dt_from    := cs_batch_or_print_pkg.get_entry(p_du_code  => p_du_code,
                                                            p_att_code => 'EFFECTIVE_DATE_FROM');
     l_eff_dt_to    := cs_batch_or_print_pkg.get_entry(p_du_code  => p_du_code,
                                                            p_att_code => 'EFFECTIVE_DATE_TO');
      /*l_cas_permit_septr := cs_batch_or_print_pkg.get_entry(p_du_code  => p_du_code,
                                                            p_att_code => 'CAS_PERMIT_NO_SEPARATOR');*/
      l_cas_permit       := l_cas_permit_descr || ' ' ||
                            substr(l_cas_permit_no, 1, 30) || ' ' ||
                            l_issuance_descr || l_issuance_date || ' ' ||
                            l_eff_dt_descr || ' ' || l_eff_dt_from || '-' || l_eff_dt_to;

    elsif p_tag = 'NEW' then
      l_cas_permit  := cs_batch_or_print_pkg.get_or_footer_info(p_du_code => p_du_code,
                                                                p_batch_no => p_batch_no,
                                                                p_tran_no => p_tran_no,
                                                                p_or_no => p_or_no,
                                                                p_ext_batch_no => p_ext_batch_no);
     /* l_cas_permit_descr := cs_batch_or_print_pkg.get_entry(p_du_code  => p_du_code,
                                                            p_att_code => 'CAS_PERMIT_NO_DESCR');
      l_cas_permit_no    := cs_batch_or_print_pkg.get_entry(p_du_code  => p_du_code,
                                                            p_att_code => 'CAS_PERMIT_NO');
      l_issuance_descr   := cs_batch_or_print_pkg.get_entry(p_du_code  => p_du_code,
                                                            p_att_code => 'DATE_OF_ISSUANCE_DESCR');
      l_issuance_date    := cs_batch_or_print_pkg.get_entry(p_du_code  => p_du_code,
                                                            p_att_code => 'DATE_OF_ISSUANCE');
      l_eff_dt_descr     := cs_batch_or_print_pkg.get_entry(p_du_code  => p_du_code,
                                                            p_att_code => 'EFFECTIVE_DATE_DESCR');
      l_eff_dt_from      := cs_batch_or_print_pkg.get_entry(p_du_code  => p_du_code,
                                                            p_att_code => 'EFFECTIVE_DATE_FROM');
      l_eff_dt_to        := cs_batch_or_print_pkg.get_entry(p_du_code  => p_du_code,
                                                            p_att_code => 'EFFECTIVE_DATE_TO');
      l_cas_permit       := l_cas_permit_descr ||
                            substr(l_cas_permit_no, 1, 4) || '-' ||
                            substr(l_cas_permit_no, 6, 4) || '-' ||
                            substr(l_cas_permit_no, 11, 6) || ' ' ||
                            l_issuance_descr || l_issuance_date || ' ' ||
                            l_eff_dt_descr || l_eff_dt_from || '-' ||
                            l_eff_dt_to; */
      /* l_cas_permit_descr := cs_batch_or_print_pkg.get_entry(p_du_code  => p_du_code,
                                                            p_att_code => 'CAS_PERMIT_NO_DESCR');
      l_cas_permit_no    := cs_batch_or_print_pkg.get_entry(p_du_code  => p_du_code,
                                                            p_att_code => 'CAS_PERMIT_NO');
      l_issuance_descr   := cs_batch_or_print_pkg.get_entry(p_du_code  => p_du_code,
                                                            p_att_code => 'DATE_OF_ISSUANCE_DESCR');
      l_issuance_date    := cs_batch_or_print_pkg.get_entry(p_du_code  => p_du_code,
                                                            p_att_code => 'DATE_OF_ISSUANCE');


      l_cas_permit       := l_cas_permit_descr || l_cas_permit_no || ' ' ||
                            --substr(l_cas_permit_no, 1, 4) || '-' ||
                            --substr(l_cas_permit_no, 6, 5) || '-' ||
                            --substr(l_cas_permit_no, 12, 6) || ' ' ||
                            l_issuance_descr || l_issuance_date; */
    end if;

    return l_cas_permit;
  end get_cas_permit_info;

  function get_cas_serial_no(p_receipt_type varchar2,
                             p_du_code      in varchar2,
                             p_tag          in varchar2
                             ) return varchar2 as
    l_cas_series    varchar2(500);
    l_cas_seq_descr du_code_att.att_value%type;
    l_cas_start_seq du_code_att.att_value%type;
    l_cas_end_seq   du_code_att.att_value%type;
  begin
    if p_tag in ('NEW', 'OLD_1', 'OLD_2', 'OLD_0') then
      if p_receipt_type = 'AR' then
        -- acknowledgement receipt
        l_cas_seq_descr := cs_batch_or_print_pkg.get_entry(p_du_code  => p_du_code,
                                                           p_att_code => 'SEQ_DESCR');
        l_cas_start_seq := cs_batch_or_print_pkg.get_entry(p_du_code  => p_du_code,
                                                           p_att_code => 'START_SEQ_1');
        l_cas_end_seq   := cs_batch_or_print_pkg.get_entry(p_du_code  => p_du_code,
                                                           p_att_code => 'END_SEQ_1');
        l_cas_series    := l_cas_seq_descr || l_cas_start_seq || '-' ||
                           l_cas_end_seq;
      elsif p_receipt_type = 'OR' and p_tag = 'OLD_1' then
        -- official receipt
        l_cas_seq_descr := cs_batch_or_print_pkg.get_entry(p_du_code  => p_du_code,
                                                           p_att_code => 'SEQ_AC_DESCR');

        l_cas_start_seq := cs_batch_or_print_pkg.get_entry(p_du_code  => p_du_code,
                                                           p_att_code => 'START_SEQ_0');
        l_cas_end_seq   := cs_batch_or_print_pkg.get_entry(p_du_code  => p_du_code,
                                                           p_att_code => 'END_SEQ_0');
        l_cas_series    := l_cas_seq_descr || l_cas_start_seq || '-' ||
                           l_cas_end_seq;
      end if;
    end if;

    if p_receipt_type = 'OR' and p_tag = 'OLD_0'
      then
        l_cas_seq_descr := cs_batch_or_print_pkg.get_entry(p_du_code  => p_du_code,
                                                           p_att_code => 'SEQ_DESCR');
        l_cas_start_seq := cs_batch_or_print_pkg.get_entry(p_du_code  => p_du_code,
                                                           p_att_code => 'START_SEQ_0');
        l_cas_end_seq   := cs_batch_or_print_pkg.get_entry(p_du_code  => p_du_code,
                                                           p_att_code => 'END_SEQ_0');
        l_cas_series    := l_cas_seq_descr || l_cas_start_seq || '-' ||
                           l_cas_end_seq;
    elsif p_receipt_type = 'OR' and p_tag = 'OLD_2' then
        -- official receipt
        l_cas_seq_descr := cs_batch_or_print_pkg.get_entry(p_du_code  => p_du_code,
                                                           p_att_code => 'SEQ_AC_DESCR');

        l_cas_start_seq := cs_batch_or_print_pkg.get_entry(p_du_code  => p_du_code,
                                                           p_att_code => 'START_SEQ_0');
        l_cas_end_seq   := cs_batch_or_print_pkg.get_entry(p_du_code  => p_du_code,
                                                           p_att_code => 'END_SEQ_0');
        l_cas_series    := l_cas_seq_descr || l_cas_start_seq || '-' ||
                           l_cas_end_seq;
    end if;

    return l_cas_series;
  end get_cas_serial_no;

  function get_forms_of_payment(p_ext_batch_no in number,
                                p_tran_no      in number) return varchar2 as
    l_bank_code   varchar2(20);
    l_check_date  date;
    l_check_no    varchar2(20);
    l_check_amt   number;
    l_cash        varchar2(10);
    l_check       varchar2(200);
    l_cc          varchar2(100);
    l_fop         varchar2(300);
    l_iscash      boolean;
    l_ischeck     boolean;
    l_iscc        boolean;
    l_tran_type   varchar2(20);
    l_card_type   varchar2(60);
    l_amount_paid number;

    cursor cr_dr_payments is
      select cr_dr.tran_type, cr_dr.card_type, fop.amount_paid
        from ext_fop_cr_dr_cards cr_dr, ext_forms_of_payments fop
       where cr_dr.ext_batch_no = fop.ext_batch_no
         and cr_dr.tran_no = fop.tran_no
         and cr_dr.seq_no = fop.seq_no
         and cr_dr.ext_batch_no = p_ext_batch_no
         and cr_dr.tran_no = p_tran_no
       order by fop.seq_no;

    cursor check_payments is
      select checks.bank_code,
             checks.check_date,
             checks.check_no,
             fop.amount_paid
        from ext_forms_of_payments fop, ext_fop_checks checks
       where fop.ext_batch_no = checks.ext_batch_no
         and fop.tran_no = checks.tran_no
         and fop.seq_no = checks.seq_no
         and fop.ext_batch_no = p_ext_batch_no
         and fop.tran_no = p_tran_no
       order by fop.seq_no;
  begin
    open check_payments;
    fetch check_payments
      into l_bank_code, l_check_date, l_check_no, l_check_amt;

    if check_payments%found then
      l_ischeck := true;
      l_check   := l_bank_code || ' ' || replace(l_check_no, chr(10)) || ' P' ||
                   to_char(l_check_amt, 'fm999,999,999,990.00');
    else
      l_ischeck := false;
      l_check   := ' ';
    end if;

    open cr_dr_payments;
    fetch cr_dr_payments
      into l_tran_type, l_card_type, l_amount_paid;

    if cr_dr_payments%found then
      l_iscc := true;
      if l_tran_type = 'DEBIT CARD' then
        l_cc := 'DR ' || l_card_type;
      elsif l_tran_type = 'CREDIT CARD' then
        l_cc := 'CR ' || l_card_type;
      end if;
    else
      l_iscc := false;
      l_cc   := ' ';
    end if;

    begin
      select 'CASH'
        into l_cash
        from ext_forms_of_payments fop, ext_fop_cash cash
       where fop.ext_batch_no = cash.ext_batch_no
         and fop.tran_no = cash.tran_no
         and fop.seq_no = cash.seq_no
         and fop.ext_batch_no = p_ext_batch_no
         and fop.tran_no = p_tran_no;

      l_cash   := l_cash;
      l_iscash := true;
    exception
      when no_data_found then
        l_iscash := false;
        l_cash   := ' ';
    end;

    if l_iscash then
      l_fop := l_cash || '/';
    end if;

    if l_ischeck then
      l_fop := l_fop || l_check || '/';
    end if;

    if l_iscc then
      l_fop := l_fop || l_cc;
    end if;

    l_fop := rtrim(l_fop, '/');
    l_fop := substr(l_fop, 1, 40);

    return nvl(l_fop, 'CASH');
  end get_forms_of_payment;

  function get_payer_name(p_last_name   in varchar2,
                          p_first_name  in varchar2,
                          p_middle_name in varchar2) return varchar2 as
    l_name varchar2(300);
  begin
    l_name := p_last_name;
    if p_first_name is not null then
      if l_name is not null then
        l_name := l_name || ', ';
      end if;

      l_name := l_name || p_first_name;
    end if;

    if p_middle_name is not null then
      if l_name is not null then
        l_name := l_name || ' ';
      end if;

      l_name := l_name || p_middle_name;
    end if;

    return l_name;
  end get_payer_name;

  function get_entry(p_du_code in varchar2, p_att_code in varchar)
    return varchar2 as

    cursor du_reg is
      select dca.att_value
        from du_codes dc, du_code_att dca
       where dc.du_code = dca.du_code
         and dc.du_code = p_du_code
         and dca.att_code = p_att_code
         and dc.status = 'A';

    l_value du_code_att.att_value%type;
  begin
    open du_reg;
    fetch du_reg
      into l_value;
    close du_reg;

    return(l_value);
  end get_entry;

end cs_batch_or_print_pkg;
