-- Create table
create table OR_EXTRACT_PARAMS
(
  ext_batch_no NUMBER(10) not null,
  created_on   DATE default sysdate,
  created_by   VARCHAR2(30) default user,
  du_code      VARCHAR2(10),
  receipt_type VARCHAR2(5),
  date_from    DATE,
  date_to      DATE,
  rate_sched   VARCHAR2(20),
  ors_batch_no NUMBER(10),
  acct_no      VARCHAR2(10),
  or_no        NUMBER
);

-- Create/Recreate primary, unique and foreign key constraints 
alter table OR_EXTRACT_PARAMS
  add constraint OR_EXTRACT_PARAMS primary key (EXT_BATCH_NO);
-- Create/Recreate check constraints 
alter table OR_EXTRACT_PARAMS
  add constraint C28_SYS_C0028795
  check ("DU_CODE" IS NOT NULL);
alter table OR_EXTRACT_PARAMS
  add constraint C28_SYS_C0028796
  check ("RECEIPT_TYPE" IS NOT NULL);

-- Grant/Revoke object privileges 
grant select on OR_EXTRACT_PARAMS to KATAMBAK_USER;
