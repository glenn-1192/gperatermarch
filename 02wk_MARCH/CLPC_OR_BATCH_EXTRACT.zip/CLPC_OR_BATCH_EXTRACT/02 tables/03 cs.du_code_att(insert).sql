insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('CLPC', 'DEFAULT_REVENUE_TAG', 'VATABLE');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('CLPC', 'DU_COMPANY', 'Cotabato Light & Power Company');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('CLPC', 'DU_TEL_NO_1', '+63 917 847 7394, +63 917 849 5381 (Globe)');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('CLPC', 'CAS_PERMIT_NO', '05-2015-123-0013-001');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('CLPC', 'CAS_PERMIT_NO_DESCR', 'BIR Permit to use no.:');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('CLPC', 'CAS_PERMIT_NO_DESCR_OLD_0', 'CAS BIR Permit No.');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('CLPC', 'CAS_PERMIT_NO_DESCR_OLD_1', 'Permit to use (PTU) No.');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('CLPC', 'CAS_PERMIT_NO_OLD_0', '05-2015-123-0013-001');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('CLPC', 'CAS_PERMIT_NO_SEPARATOR', '_PTU_CAS_');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('CLPC', 'DATA_SOURCE', 'CCB');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('CLPC', 'DATE_OF_ISSUANCE', '06/05/2015');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('CLPC', 'DATE_OF_ISSUANCE_DESCR', 'Date of Issuance:');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('CLPC', 'CAS_PERMIT_AC_DESCR', 'Acknowledgment Certificate No.:');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('CLPC', 'SEQ_AC_DESCR', 'Series:');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('CLPC', 'CAS_PERMIT_ON_OLD_0', 'On :');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('CLPC', 'VERSION_RELEASE_1', 'This is a BIR approved system generated report from Online Receipting System Version 2 Release 2');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('CLPC', 'GENERATED_MSG_NEW', ' ');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('CLPC', 'GET_OLD2_PERMIT_EFF_FROM', '01/01/2010');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('CLPC', 'GET_OLD2_PERMIT_EFF_TO', '07/31/2020');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('CLPC', 'DU_ADDRESS', 'Sinsuat Ave. Cotabato City 9600');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('CLPC', 'DU_BUS_STYLE', 'Cotabato Light & Power Company');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('CLPC', 'DU_EMAIL', 'cotabatolight@aboitiz.com');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('CLPC', 'DU_FACEBOOK', 'cotabatolight');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('CLPC', 'DU_TEL_NO', 'Tel.(064) 520-2572 | +63 939 606 6999');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('CLPC', 'DU_TIN', '000-948-784-00001');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('CLPC', 'EFFECTIVE_DATE_DESCR', 'Effective Date:');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('CLPC', 'EFFECTIVE_DATE_FROM', '08/01/2020');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('CLPC', 'EFFECTIVE_DATE_TO', '07/31/2025');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('CLPC', 'END_SEQ_0', '999999999');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('CLPC', 'END_SEQ_1', '399999999');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('CLPC', 'GENERATED_MSG', 'THIS IS A SYSTEM GENERATED OFFICIAL RECEIPT');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('CLPC', 'GENERATED_MSG_AR', 'THIS DOCUMENT IS NOT VALID FOR CLAIM OF INPUT TAX');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('CLPC', 'GENERATED_MSG_OR', 'THIS RECEIPT SHALL BE VALID FOR FIVE(5) YEARS FROM THE DATE OF PERMIT TO USE');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('CLPC', 'GET_NEW_PERMIT_EFF', '09/22/2022');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('CLPC', 'GET_OLD_PERMIT_EFF_FROM', '08/01/2020');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('CLPC', 'GET_OLD_PERMIT_EFF_TO', '09/21/2022');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('CLPC', 'OR_PREFFIX', '000');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('CLPC', 'SEQ_DESCR', 'Series No.:');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('CLPC', 'START_SEQ_0', '1');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('CLPC', 'START_SEQ_1', '300000001');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('CLPC', 'VERSION_RELEASE', 'This is BIR approved system generated report from Online Receipting System Version 2 Release 2 No Signature is required.');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('CLPC', 'DU_WEBSITE', 'www.cotabatolight.com');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('CLPC', 'DU_GLOBE_NO', 'Globe : +63 917 847 7394  +63 917 849 5381');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('CLPC', 'DU_TWITTER', '@cotabatolight');

