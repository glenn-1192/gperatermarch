
insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-OTH-PTM', 'Other Income - Penalty-Tampered Meter', '9019999999', 'Other Income - Penalty-Tampered Meter', null, null, 0, 1, 0, 0, 0, null, null, 'M-OTH-PTM ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-OTH-PUT', 'Other Income - Penalty-Unauthorized Transfer Of Meters', '9019999999', 'Other Income - Penalty-Unauthorized Transfer Of Meters', null, null, 0, 1, 0, 0, 0, null, null, 'M-OTH-PUT ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-OTH-RCP', 'Misc - Other Income - Returned Checks Penalty', '9019099999', 'Misc - Other Income - Returned Checks Penalty', null, null, 0, 1, 0, 0, 0, null, null, 'M-OTH-RCP ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-OTH-RFL', 'Other Income - Removal Of Fuse Limiter', '9019999999', 'Other Income - Removal Of Fuse Limiter', null, null, 0, 1, 0, 0, 0, null, null, 'M-OTH-RFL ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-OTH-SFA', 'Other Income - Sale Of Property, Plant And Equipment', '9010401001', 'Other Income - Sale Of Property, Plant And Equipment', null, null, 0, 1, 0, 0, 0, null, null, 'M-OTH-SFA ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-OTH-V', 'Others - Vat', '9019999999', 'Others - Vat', null, null, 0, 1, 0, 0, 0, null, null, 'M-OTH-V   ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-PAY-REN', 'Payable-Pole Rental', '3010211005', 'Payable-Pole Rental', null, null, 0, 1, 0, 0, 0, null, null, 'M-PAY-REN ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-PET-DVO', 'Petty Cash Fund', '1010301001', 'Petty Cash Fund', null, null, 0, 1, 0, 0, 0, null, null, 'M-PET-DVO ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-REN-LOT', 'Rental Income – Lot', '9019001004', 'Rental Income – Lot', null, null, 0, 1, 0, 0, 0, null, null, 'M-REN-LOT ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-REN-OR', 'Rental Income - Office Rental', '9019001003', 'Rental Income - Office Rental', null, null, 0, 1, 0, 0, 0, null, null, 'M-REN-OR  ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-REN-PR', 'Rental Income - Pole Rental', '9019001001', 'Rental Income - Pole Rental', null, null, 0, 1, 0, 0, 0, null, null, 'M-REN-PR  ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-REN-TR', 'Rental Income - Transformer Rental', '9019001002', 'Rental Income - Transformer Rental', null, null, 0, 1, 0, 0, 0, null, null, 'M-REN-TR  ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-VAT-G', 'Vat Output-Goods-Regular Vat', '3010214001', 'Vat Output-Goods-Regular Vat', null, null, 0, 1, 0, 0, 0, null, null, 'M-VAT-G   ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-VAT-O', 'Vat Output Others', '3010216001', 'Vat Output Others', null, null, 0, 1, 0, 0, 0, null, null, 'M-VAT-O   ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-VAT-R', 'Vat Output Rental-Regular Vat', '3010215001', 'Vat Output Rental-Regular Vat', null, null, 0, 1, 0, 0, 0, null, null, 'M-VAT-R   ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PIL-DIS-G', 'Pilferage - Power Revenue-Government - Distribution Charge', '4040401001', 'Pilferage - Power Revenue-Government - Distribution Charge', null, null, 0, 1, 0, 0, 0, null, null, 'PIL-DIS-G ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PIL-DIS-R', 'Pilferage - Power Revenue-Regular', '4040401001', 'Pilferage - Power Revenue-Regular', null, null, 0, 1, 0, 0, 0, null, null, 'PIL-DIS-R ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PIL-DIS-Z', 'Pilferage - Power Revenue-Zero-Rated - Distribution Charge', '4040401001', 'Pilferage - Power Revenue-Zero-Rated - Distribution Charge', null, null, 0, 1, 0, 0, 0, null, null, 'PIL-DIS-Z ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PIL-FCT-G', 'Pilferage - Power Revenue-Government - Franchise Tax', '4040401001', 'Pilferage - Power Revenue-Government - Franchise Tax', null, null, 0, 1, 0, 0, 0, null, null, 'PIL-FCT-G ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PIL-FCT-R', 'Pilferage - Power Revenue-Regular - Franchise Tax', '4040401001', 'Pilferage - Power Revenue-Regular - Franchise Tax', null, null, 0, 1, 0, 0, 0, null, null, 'PIL-FCT-R ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PIL-FCT-Z', 'Pilferage - Power Revenue-Zero-Rated - Franchise Tax', '4040401001', 'Pilferage - Power Revenue-Zero-Rated - Franchise Tax', null, null, 0, 1, 0, 0, 0, null, null, 'PIL-FCT-Z ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PIL-GEN-G', 'Pilferage - Power Revenue-Government - Generation Charge', '4040401001', 'Pilferage - Power Revenue-Government - Generation Charge', null, null, 0, 1, 0, 0, 0, null, null, 'PIL-GEN-G ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PIL-GEN-R', 'Pilferage - Power Revenue-Regular - Generation Charge', '4040401001', 'Pilferage - Power Revenue-Regular - Generation Charge', null, null, 0, 1, 0, 0, 0, null, null, 'PIL-GEN-R ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PIL-GEN-Z', 'Pilferage - Power Revenue-Zero-Rated - Generation Charge', '4040401001', 'Pilferage - Power Revenue-Zero-Rated - Generation Charge', null, null, 0, 1, 0, 0, 0, null, null, 'PIL-GEN-Z ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PIL-GRM-G', 'Pilferage - Power Revenue-Government - Gram Recovery', '4040401001', 'Pilferage - Power Revenue-Government - Gram Recovery', null, null, 0, 1, 0, 0, 0, null, null, 'PIL-GRM-G ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PIL-GRM-R', 'Pilferage - Power Revenue-Regular - Gram Recovery', '4040401001', 'Pilferage - Power Revenue-Regular - Gram Recovery', null, null, 0, 1, 0, 0, 0, null, null, 'PIL-GRM-R ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PIL-GRM-Z', 'Pilferage - Power Revenue-Zero-Rated - Gram Recovery', '4040401001', 'Pilferage - Power Revenue-Zero-Rated - Gram Recovery', null, null, 0, 1, 0, 0, 0, null, null, 'PIL-GRM-Z ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PIL-ICS-G', 'Pilferage - Pwr Rev-Government - Interclass Cross Subsidy', '4040401001', 'Pilferage - Pwr Rev-Government - Interclass Cross Subsidy', null, null, 0, 1, 0, 0, 0, null, null, 'PIL-ICS-G ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PIL-ICS-R', 'Pilferage - Power Revenue-Regular - Interclass Cross Subsidy', '4040401001', 'Pilferage - Power Revenue-Regular - Interclass Cross Subsidy', null, null, 0, 1, 0, 0, 0, null, null, 'PIL-ICS-R ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PIL-ICS-Z', 'Pilferage - Pwr Rev-Zero-Rated - Interclass Cross Subsidy', '4040401001', 'Pilferage - Pwr Rev-Zero-Rated - Interclass Cross Subsidy', null, null, 0, 1, 0, 0, 0, null, null, 'PIL-ICS-Z ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PIL-LRS-G', 'Pilferage - Power Revenue-Government - Lifeline Rate Subsidy', '4040401001', 'Pilferage - Power Revenue-Government - Lifeline Rate Subsidy', null, null, 0, 1, 0, 0, 0, null, null, 'PIL-LRS-G ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PIL-LRS-R', 'Pilferage - Power Revenue-Regular - Lifeline Rate Subsidy', '4040401001', 'Pilferage - Power Revenue-Regular - Lifeline Rate Subsidy', null, null, 0, 1, 0, 0, 0, null, null, 'PIL-LRS-R ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PIL-LRS-Z', 'Pilferage - Power Revenue-Zero-Rated - Lifeline Rate Subsidy', '4040401001', 'Pilferage - Power Revenue-Zero-Rated - Lifeline Rate Subsidy', null, null, 0, 1, 0, 0, 0, null, null, 'PIL-LRS-Z ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PIL-LSD-G', 'Pilferage - Pwr Rev-Government - Lifeline Subsidy Discount', '4040401001', 'Pilferage - Pwr Rev-Government - Lifeline Subsidy Discount', null, null, 0, 1, 0, 0, 0, null, null, 'PIL-LSD-G ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PIL-LSD-R', 'Pilferage - Pwr Rev-Regular - Lifeline Subsidy Discount', '4040401001', 'Pilferage - Pwr Rev-Regular - Lifeline Subsidy Discount', null, null, 0, 1, 0, 0, 0, null, null, 'PIL-LSD-R ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PIL-LSD-Z', 'Pilferage - Pwr Rev-Zero-Rated - Lifeline Subsidy Discount', '4040401001', 'Pilferage - Pwr Rev-Zero-Rated - Lifeline Subsidy Discount', null, null, 0, 1, 0, 0, 0, null, null, 'PIL-LSD-Z ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PIL-LTR-G', 'Pilferage - Power Revenue-Government - Local Tax Recovery', '4040401001', 'Pilferage - Power Revenue-Government - Local Tax Recovery', null, null, 0, 1, 0, 0, 0, null, null, 'PIL-LTR-G ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PIL-LTR-R', 'Pilferage - Power Revenue-Regular - Local Tax Recovery', '4040401001', 'Pilferage - Power Revenue-Regular - Local Tax Recovery', null, null, 0, 1, 0, 0, 0, null, null, 'PIL-LTR-R ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PIL-LTR-Z', 'Pilferage - Power Revenue-Zero-Rated - Local Tax Recovery', '4040401001', 'Pilferage - Power Revenue-Zero-Rated - Local Tax Recovery', null, null, 0, 1, 0, 0, 0, null, null, 'PIL-LTR-Z ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PIL-MFX-G', 'Pilferage - Power Revenue-Government - Metering Charge', '4040401001', 'Pilferage - Power Revenue-Government - Metering Charge', null, null, 0, 1, 0, 0, 0, null, null, 'PIL-MFX-G ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PIL-MFX-R', 'Pilferage - Power Revenue-Regular - Metering Charge', '4040401001', 'Pilferage - Power Revenue-Regular - Metering Charge', null, null, 0, 1, 0, 0, 0, null, null, 'PIL-MFX-R ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PIL-MFX-Z', 'Pilferage - Power Revenue-Zero-Rated - Metering Charge', '4040401001', 'Pilferage - Power Revenue-Zero-Rated - Metering Charge', null, null, 0, 1, 0, 0, 0, null, null, 'PIL-MFX-Z ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PIL-PAR-G', 'Pilferage - Power Revenue-Government - Power Act Reduction', '4040401001', 'Pilferage - Power Revenue-Government - Power Act Reduction', null, null, 0, 1, 0, 0, 0, null, null, 'PIL-PAR-G ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PIL-PAR-R', 'Pilferage - Power Revenue-Regular - Power Act Reduction', '4040401001', 'Pilferage - Power Revenue-Regular - Power Act Reduction', null, null, 0, 1, 0, 0, 0, null, null, 'PIL-PAR-R ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PIL-PAR-Z', 'Pilferage - Power Revenue-Zero-Rated - Power Act Reduction', '4040401001', 'Pilferage - Power Revenue-Zero-Rated - Power Act Reduction', null, null, 0, 1, 0, 0, 0, null, null, 'PIL-PAR-Z ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PIL-PPD-G', 'Pilferage - Power Purchase Prompt Payment - Government', '4040401001', 'Pilferage - Power Purchase Prompt Payment - Government', null, null, 0, 1, 0, 0, 0, null, null, 'PIL-PPD-G ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PIL-PPD-R', 'Pilferage - Power Purchase Prompt Payment - Regular', '4040401001', 'Pilferage - Power Purchase Prompt Payment - Regular', null, null, 0, 1, 0, 0, 0, null, null, 'PIL-PPD-R ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PIL-PPD-Z', 'Pilferage - Power Purchase Prompt Payment - Zero', '4040401001', 'Pilferage - Power Purchase Prompt Payment - Zero', null, null, 0, 1, 0, 0, 0, null, null, 'PIL-PPD-Z ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PIL-SCD-G', 'Pilferage - Power Revenue-Government - SC Discount', '4040401001', 'Pilferage - Power Revenue-Government - SC Discount', null, null, 0, 1, 0, 0, 0, null, null, 'PIL-SCD-G ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PIL-SCD-R', 'Pilferage - Power Revenue-Regular - SC Discount', '4040401001', 'Pilferage - Power Revenue-Regular - SC Discount', null, null, 0, 1, 0, 0, 0, null, null, 'PIL-SCD-R ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PIL-SCD-Z', 'Pilferage - Power Revenue-Zero-Rated - SC Discount', '4040401001', 'Pilferage - Power Revenue-Zero-Rated - SC Discount', null, null, 0, 1, 0, 0, 0, null, null, 'PIL-SCD-Z ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PIL-SCS-G', 'Pilferage - Power Revenue-Government- Senior Citizen Subsidy', '4040401001', 'Pilferage - Power Revenue-Government- Senior Citizen Subsidy', null, null, 0, 1, 0, 0, 0, null, null, 'PIL-SCS-G ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PIL-SCS-R', 'Pilferage - Power Revenue-Regular  - Senior Citizen Subsidy', '4040401001', 'Pilferage - Power Revenue-Regular  - Senior Citizen Subsidy', null, null, 0, 1, 0, 0, 0, null, null, 'PIL-SCS-R ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PIL-SCS-Z', 'Pilferage - Power Revenue-Zero Rated- Senior Citizen Subsidy', '4040401001', 'Pilferage - Power Revenue-Zero Rated- Senior Citizen Subsidy', null, null, 0, 1, 0, 0, 0, null, null, 'PIL-SCS-Z ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PIL-SFX-G', 'Pilferage - Power Revenue-Government - Supply Charge', '4040401001', 'Pilferage - Power Revenue-Government - Supply Charge', null, null, 0, 1, 0, 0, 0, null, null, 'PIL-SFX-G ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PIL-SFX-R', 'Pilferage - Power Revenue-Regular  - Supply Charge', '4040401001', 'Pilferage - Power Revenue-Regular  - Supply Charge', null, null, 0, 1, 0, 0, 0, null, null, 'PIL-SFX-R ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PIL-SFX-Z', 'Pilferage - Power Revenue-Zero-Rated - Supply Charge', '4040401001', 'Pilferage - Power Revenue-Zero-Rated - Supply Charge', null, null, 0, 1, 0, 0, 0, null, null, 'PIL-SFX-Z ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PIL-SUR-G', 'Pilferage - Surcharge-Final Vat', '4040401001', 'Pilferage - Surcharge-Final Vat', null, null, 0, 1, 0, 0, 0, null, null, 'PIL-SUR-G ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PIL-SUR-R', 'Pilferage - Surcharge-Regular Vat', '4040401001', 'Pilferage - Surcharge-Regular Vat', null, null, 0, 1, 0, 0, 0, null, null, 'PIL-SUR-R ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PIL-SUR-Z', 'Pilferage - Surcharge-Zero-Rated', '4040401001', 'Pilferage - Surcharge-Zero-Rated', null, null, 0, 1, 0, 0, 0, null, null, 'PIL-SUR-Z ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PIL-SYS-G', 'Pilferage - Power Revenue-Government - System Loss Charge', '4040401001', 'Pilferage - Power Revenue-Government - System Loss Charge', null, null, 0, 1, 0, 0, 0, null, null, 'PIL-SYS-G ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PIL-SYS-R', 'Pilferage - Power Revenue-Regular - System Loss Charge', '4040401001', 'Pilferage - Power Revenue-Regular - System Loss Charge', null, null, 0, 1, 0, 0, 0, null, null, 'PIL-SYS-R ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PIL-SYS-Z', 'Pilferage - Power Revenue-Zero-Rated - System Loss Charge', '4040401001', 'Pilferage - Power Revenue-Zero-Rated - System Loss Charge', null, null, 0, 1, 0, 0, 0, null, null, 'PIL-SYS-Z ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PIL-TRX-G', 'Pilferage - Power Revenue-Government - Transmission Charge', '4040401001', 'Pilferage - Power Revenue-Government - Transmission Charge', null, null, 0, 1, 0, 0, 0, null, null, 'PIL-TRX-G ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PIL-TRX-R', 'Pilferage - Power Revenue-Regular - Transmission Charge', '4040401001', 'Pilferage - Power Revenue-Regular - Transmission Charge', null, null, 0, 1, 0, 0, 0, null, null, 'PIL-TRX-R ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PIL-TRX-Z', 'Pilferage - Power Revenue-Zero-Rated - Transmission Charge', '4040401001', 'Pilferage - Power Revenue-Zero-Rated - Transmission Charge', null, null, 0, 1, 0, 0, 0, null, null, 'PIL-TRX-Z ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('RV-DIS-G', 'Power Revenue-Government - Distribution Charge', '6020112005', 'Power Revenue-Government - Distribution Charge', null, null, 0, 1, 0, 0, 0, null, null, 'RV-DIS-G  ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('RV-DIS-R', 'Power Revenue-Regular  - Distribution Charge', '6020106005', 'Power Revenue-Regular  - Distribution Charge', null, null, 0, 1, 0, 0, 0, null, null, 'RV-DIS-R  ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('RV-DIS-Z', 'Power Revenue-Zero-Rated - Distribution Charge', '6020108005', 'Power Revenue-Zero-Rated - Distribution Charge', null, null, 0, 1, 0, 0, 0, null, null, 'RV-DIS-Z  ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('RV-FCT-G', 'Power Revenue-Government - Franchise Tax', '6020112011', 'Power Revenue-Government - Franchise Tax', null, null, 0, 1, 0, 0, 0, null, null, 'RV-FCT-G  ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('RV-FCT-R', 'Power Revenue-Regular  - Franchise Tax', '6020106011', 'Power Revenue-Regular  - Franchise Tax', null, null, 0, 1, 0, 0, 0, null, null, 'RV-FCT-R  ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('RV-FCT-Z', 'Power Revenue-Zero-Rated - Franchise Tax', '6020108011', 'Power Revenue-Zero-Rated - Franchise Tax', null, null, 0, 1, 0, 0, 0, null, null, 'RV-FCT-Z  ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('RV-GEN-G', 'Power Revenue-Government - Generation Charge', '6020112001', 'Power Revenue-Government - Generation Charge', null, null, 0, 1, 0, 0, 0, null, null, 'RV-GEN-G  ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('RV-GEN-R', 'Power Revenue-Regular  - Generation Charge', '6020106001', 'Power Revenue-Regular  - Generation Charge', null, null, 0, 1, 0, 0, 0, null, null, 'RV-GEN-R  ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('RV-GEN-Z', 'Power Revenue-Zero-Rated - Generation Charge', '6020108001', 'Power Revenue-Zero-Rated - Generation Charge', null, null, 0, 1, 0, 0, 0, null, null, 'RV-GEN-Z  ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('RV-GRM-G', 'Power Revenue-Government - Gram Recovery', '6020112016', 'Power Revenue-Government - Gram Recovery', null, null, 0, 1, 0, 0, 0, null, null, 'RV-GRM-G  ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('RV-GRM-R', 'Power Revenue-Regular  - Gram Recovery', '6020106027', 'Power Revenue-Regular  - Gram Recovery', null, null, 0, 1, 0, 0, 0, null, null, 'RV-GRM-R  ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('RV-GRM-Z', 'Power Revenue-Zero-Rated - Gram Recovery', '6020108016', 'Power Revenue-Zero-Rated - Gram Recovery', null, null, 0, 1, 0, 0, 0, null, null, 'RV-GRM-Z  ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('RV-ICS-G', 'Power Revenue-Government - Interclass Cross Subsidy', '6020112015', 'Power Revenue-Government - Interclass Cross Subsidy', null, null, 0, 1, 0, 0, 0, null, null, 'RV-ICS-G  ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('RV-ICS-R', 'Power Revenue-Regular  - Interclass Cross Subsidy', '6020106026', 'Power Revenue-Regular  - Interclass Cross Subsidy', null, null, 0, 1, 0, 0, 0, null, null, 'RV-ICS-R  ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('RV-ICS-Z', 'Power Revenue-Zero-Rated - Interclass Cross Subsidy', '6020108015', 'Power Revenue-Zero-Rated - Interclass Cross Subsidy', null, null, 0, 1, 0, 0, 0, null, null, 'RV-ICS-Z  ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('RV-LRS-G', 'Power Revenue-Government - Lifeline Rate Subsidy', '6020112014', 'Power Revenue-Government - Lifeline Rate Subsidy', null, null, 0, 1, 0, 0, 0, null, null, 'RV-LRS-G  ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('RV-LRS-R', 'Power Revenue-Regular  - Lifeline Rate Subsidy', '6020106025', 'Power Revenue-Regular  - Lifeline Rate Subsidy', null, null, 0, 1, 0, 0, 0, null, null, 'RV-LRS-R  ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('RV-LRS-Z', 'Power Revenue-Zero-Rated - Lifeline Rate Subsidy', '6020108014', 'Power Revenue-Zero-Rated - Lifeline Rate Subsidy', null, null, 0, 1, 0, 0, 0, null, null, 'RV-LRS-Z  ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('RV-LSD-G', 'Power Revenue-Government - Lifeline Subsidy Discount', '6020112008', 'Power Revenue-Government - Lifeline Subsidy Discount', null, null, 0, 1, 0, 0, 0, null, null, 'RV-LSD-G  ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('RV-LSD-R', 'Power Revenue-Regular  - Lifeline Subsidy Discount', '6020106008', 'Power Revenue-Regular  - Lifeline Subsidy Discount', null, null, 0, 1, 0, 0, 0, null, null, 'RV-LSD-R  ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('RV-LSD-Z', 'Power Revenue-Zero-Rated - Lifeline Subsidy Discount', '6020108008', 'Power Revenue-Zero-Rated - Lifeline Subsidy Discount', null, null, 0, 1, 0, 0, 0, null, null, 'RV-LSD-Z  ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('RV-LTR-G', 'Power Revenue-Government - Local Tax Recovery', '6020112009', 'Power Revenue-Government - Local Tax Recovery', null, null, 0, 1, 0, 0, 0, null, null, 'RV-LTR-G  ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('RV-LTR-R', 'Power Revenue-Regular  - Local Tax Recovery', '6020106009', 'Power Revenue-Regular  - Local Tax Recovery', null, null, 0, 1, 0, 0, 0, null, null, 'RV-LTR-R  ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('RV-LTR-Z', 'Power Revenue-Zero-Rated - Local Tax Recovery', '6020108009', 'Power Revenue-Zero-Rated - Local Tax Recovery', null, null, 0, 1, 0, 0, 0, null, null, 'RV-LTR-Z  ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('RV-MFX-G', 'Power Revenue-Government - Metering Charge', '6020112007', 'Power Revenue-Government - Metering Charge', null, null, 0, 1, 0, 0, 0, null, null, 'RV-MFX-G  ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('RV-MFX-R', 'Power Revenue-Regular  - Metering Charge', '6020106007', 'Power Revenue-Regular  - Metering Charge', null, null, 0, 1, 0, 0, 0, null, null, 'RV-MFX-R  ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('RV-MFX-Z', 'Power Revenue-Zero-Rated - Metering Charge', '6020108007', 'Power Revenue-Zero-Rated - Metering Charge', null, null, 0, 1, 0, 0, 0, null, null, 'RV-MFX-Z  ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('RV-PAR-G', 'Power Revenue-Government - Power Act Reduction', '6020112002', 'Power Revenue-Government - Power Act Reduction', null, null, 0, 1, 0, 0, 0, null, null, 'RV-PAR-G  ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('RV-PAR-R', 'Power Revenue-Regular  - Power Act Reduction', '6020106002', 'Power Revenue-Regular  - Power Act Reduction', null, null, 0, 1, 0, 0, 0, null, null, 'RV-PAR-R  ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('RV-PAR-Z', 'Power Revenue-Zero-Rated - Power Act Reduction', '6020108002', 'Power Revenue-Zero-Rated - Power Act Reduction', null, null, 0, 1, 0, 0, 0, null, null, 'RV-PAR-Z  ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('RV-PPD-G', 'Power Purchase Prompt Payment', '9019023001', 'Power Purchase Prompt Payment', null, null, 0, 1, 0, 0, 0, null, null, 'RV-PPD-G  ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('RV-PPD-R', 'Power Purchase Prompt Payment', '9019023001', 'Power Purchase Prompt Payment', null, null, 0, 1, 0, 0, 0, null, null, 'RV-PPD-R  ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('RV-PPD-Z', 'Power Purchase Prompt Payment', '9019023001', 'Power Purchase Prompt Payment', null, null, 0, 1, 0, 0, 0, null, null, 'RV-PPD-Z  ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('RV-SCD-G', 'Power Revenue-Government - Senior Citizen Discount', '6020112018', 'Power Revenue-Government - Senior Citizen Discount', null, null, 0, 1, 0, 0, 0, null, null, 'RV-SCD-G  ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('RV-SCD-R', 'Power Revenue-Regular  - Senior Citizen Discount', '6020106029', 'Power Revenue-Regular  - Senior Citizen Discount', null, null, 0, 1, 0, 0, 0, null, null, 'RV-SCD-R  ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('RV-SCD-Z', 'Power Revenue-Zero-Rated - Senior Citizen Discount', '6020108018', 'Power Revenue-Zero-Rated - Senior Citizen Discount', null, null, 0, 1, 0, 0, 0, null, null, 'RV-SCD-Z  ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('RV-SCS-G', 'Power Revenue-Government- Senior Citizen Subsidy', '6020112017', 'Power Revenue-Government- Senior Citizen Subsidy', null, null, 0, 1, 0, 0, 0, null, null, 'RV-SCS-G  ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('RV-SCS-R', 'Power Revenue-Regular- Senior Citizen Subsidy', '6020106028', 'Power Revenue-Regular- Senior Citizen Subsidy', null, null, 0, 1, 0, 0, 0, null, null, 'RV-SCS-R  ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('RV-SCS-Z', 'Power Revenue-Zero Rated- Senior Citizen Subsidy', '6020108017', 'Power Revenue-Zero Rated- Senior Citizen Subsidy', null, null, 0, 1, 0, 0, 0, null, null, 'RV-SCS-Z  ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('RV-SFX-G', 'Power Revenue-Government - Supply Charge', '6020112006', 'Power Revenue-Government - Supply Charge', null, null, 0, 1, 0, 0, 0, null, null, 'RV-SFX-G  ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('RV-SFX-R', 'Power Revenue-Regular  - Supply Charge', '6020106006', 'Power Revenue-Regular  - Supply Charge', null, null, 0, 1, 0, 0, 0, null, null, 'RV-SFX-R  ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('RV-SFX-Z', 'Power Revenue-Zero-Rated - Supply Charge', '6020108006', 'Power Revenue-Zero-Rated - Supply Charge', null, null, 0, 1, 0, 0, 0, null, null, 'RV-SFX-Z  ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('RV-SUR-G', 'Surcharge-Final Vat', '6020110005', 'Surcharge-Final Vat', null, null, 0, 1, 0, 0, 0, null, null, 'RV-SUR-G  ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('RV-SUR-R', 'Surcharge-Regular Vat', '6020109005', 'Surcharge-Regular Vat', null, null, 0, 1, 0, 0, 0, null, null, 'RV-SUR-R  ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('RV-SUR-Z', 'Surcharge-Zero-Rated', '6020111005', 'Surcharge-Zero-Rated', null, null, 0, 1, 0, 0, 0, null, null, 'RV-SUR-Z  ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('RV-SYS-G', 'Power Revenue-Government - System Loss Charge', '6020112004', 'Power Revenue-Government - System Loss Charge', null, null, 0, 1, 0, 0, 0, null, null, 'RV-SYS-G  ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('RV-SYS-R', 'Power Revenue-Regular  - System Loss Charge', '6020106004', 'Power Revenue-Regular  - System Loss Charge', null, null, 0, 1, 0, 0, 0, null, null, 'RV-SYS-R  ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('RV-SYS-Z', 'Power Revenue-Zero-Rated - System Loss Charge', '6020108004', 'Power Revenue-Zero-Rated - System Loss Charge', null, null, 0, 1, 0, 0, 0, null, null, 'RV-SYS-Z  ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('RV-TRX-G', 'Power Revenue-Government - Transmission Charge', '6020112003', 'Power Revenue-Government - Transmission Charge', null, null, 0, 1, 0, 0, 0, null, null, 'RV-TRX-G  ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('RV-TRX-R', 'Power Revenue-Regular  - Transmission Charge', '6020106003', 'Power Revenue-Regular  - Transmission Charge', null, null, 0, 1, 0, 0, 0, null, null, 'RV-TRX-R  ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('RV-TRX-Z', 'Power Revenue-Zero-Rated - Transmission Charge', '6020108003', 'Power Revenue-Zero-Rated - Transmission Charge', null, null, 0, 1, 0, 0, 0, null, null, 'RV-TRX-Z  ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PA-NORM ', 'PA - Payment Arrangement SA for Arrears', '1030101001', 'Normal Arrears Payment Arrangement', null, null, 0, 0, 0, 0, 0, null, null, 'AR-ELC    ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('MPPWTAX', 'BIR 2307 PPWTAX', '1050106001', 'BIR 2307', null, null, 0, 1, 0, 90, 0, null, null, 'C-BIR2307', '2307');

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PPVAT-HEDBK', 'BIR 2306 PPVAT - HEDCOR BUKIDNON', '1050107024', 'VAT Witholding', null, null, 1, 0, 0, 24, 0, null, null, 'PVO-HEDBK', 'HEDB');

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('MPPTAX-CLPC', '(MPPWTAX) BIR 2306 PPWTAX', '1050107001', '(MPPWTAX) BIR 2306 PPWTAX', null, null, 0, 1, 0, 10, 0, null, null, 'PVO-BIR', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-PCBCHG', 'Misc - Pilferage CIS Billable Charge', '2040100002', 'Misc - Pilferage CIS Billable Charge', null, null, 0, 1, 0, 10, 0, null, null, 'NR-VOC    ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-CD/TPA', 'TPA Collection Depository', '1030100001', 'COLLECTION DEPOSIT', null, null, 0, 1, 0, 10, 0, null, null, 'AR-TPA    ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-AFF-MISC', 'AR - NON TRADE MISCELLANEOUS - COTABATO', '1030290001', 'AR - NON TRADE MISCELLANEOUS - COTABATO', null, null, 0, 1, 0, 0, 0, null, null, 'M-AFF-MISC', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('E-PFR', 'Electric - Pilferage', '1030105001', 'ELECTRIC - PILFERAGE', null, null, 0, 0, 0, null, 1, null, null, 'AR-ELC    ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-NTR-RFND', 'CLPC Revolving Fund', '1010300005', 'CLPC Revolving Fund', null, null, 0, 1, 0, 10, 0, null, null, 'M-NTR-RFND', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-NTR-OTH', 'AR - NON TRADE - OTHERS', '1030201099', 'AR - NON TRADE - OTHERS', null, null, 0, 1, 0, 10, 0, null, null, 'M-NTR-OTH', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PA-BKBIL', 'PA - Payment Arrangement SA for Backbilling', '1030101001', 'Backbilling Payment Arrangement', null, null, 0, 0, 0, 0, 0, null, null, 'AR-ELC    ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PPVAT-NGCP WMPC', 'BIR 2306 PPVAT - NGCP WMPC', '1050107003', 'VAT Witholding', null, null, 1, 0, 0, 24, 0, null, null, 'PVO-NGWMPC', 'NGMP');

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PPVAT-NGCP TMI', 'BIR 2306 PPVAT - NGCP TMI', '1050107003', 'VAT Witholding', null, null, 1, 0, 0, 24, 0, null, null, 'PVO-NGTMI', 'NGTM');

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PPVAT-NGCP PSALM', 'BIR 2306 PPVAT - NGCP PSALM', '1050107003', 'VAT Witholding', null, null, 1, 0, 0, 24, 0, null, null, 'PVO-NGPSAL', 'NGPS');

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PPVAT-NGCP KEGI', 'BIR 2306 PPVAT - NGCP KEGI', '1050107003', 'VAT Witholding', null, null, 1, 0, 0, 24, 0, null, null, 'PVO-NGKEGI', 'NGKE');

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PPVAT-NGCP', 'BIR 2306 PPVAT - NGCP', '1050107003', 'VAT Witholding', null, null, 1, 0, 0, 24, 0, null, null, 'PVO-NGCP', 'NGCP');

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('UC-FIT_ALL', 'UC and FIT Allowance', '0', 'UC/Fit-All', null, 100, 0, 0, 1, 20, 0, null, null, null, null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('VAT-EXEMPT', 'VAT Exempt Sales', '0', 'VAT Exempt Sales', null, 12, 0, 0, 1, 14, 0, null, null, null, null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PA-WOFF', 'Payment Arrangement - Write off', '1030101012', 'Payment Arrangement', null, null, 0, 1, 0, 29, 0, null, null, 'ALBADDEBT ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PA-WOFF2', 'Payment Arrangement - Write off', '1030101012', 'Payment Arrangement', null, null, 0, 0, 1, 29, 0, null, null, 'ALBADDEBT ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PPVAT-BIR', 'Prepaid Vat Output - Bir', '1050104001', 'VAT Witholding', null, null, 1, 0, 0, 24, 0, null, null, 'PVO-BIR   ', 'OTH');

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-OTH-MSC', 'Other Income - Misc Others', '9019099005', 'Other Income - Misc Others', null, null, 0, 1, 0, 10, 1, null, null, 'M-OTH-MSC', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PPVAT-CLPC', 'BIR 2306 PPVAT - CLPC', '1050104001', 'VAT Witholding', null, null, 1, 0, 0, 24, 0, null, null, 'PVO-BIR   ', 'CLPC');

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PPVAT-PEMC', 'BIR 2306 PPVAT - PEMC', '1050107006', 'VAT Witholding', null, null, 1, 0, 0, 24, 0, null, null, 'PVO-PEM ', 'PEMC');

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PPVAT-UPSI', 'xxxxxBIR 2306 PPVAT - UPSI', '1080511001', 'VAT Witholding', null, null, 1, 0, 0, 24, 0, null, null, 'PVO-NUPSI', 'UPSI');

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PPWTAX', 'BIR 2307 PPWTAX', '1050106001', 'Expanded Witholding', null, null, 1, 0, 0, 26, 0, null, null, 'C-BIR2307 ', '2307');

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PVO-NPC', 'Prepaid Vat Output - Npc', '1', 'Prepaid Vat Output - Npc', null, null, 0, 1, 0, null, 1, null, null, 'PVO-NPC   ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PPVAT-NPC', 'BIR 2306 PPVAT - NPC', '1050104002', 'VAT Witholding', null, null, 1, 0, 0, 24, 0, null, null, 'PVO-NPC   ', 'NPC');

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PPVAT-NTC', 'BIR 2306 PPVAT - Transco', '1050107003', 'VAT Witholding', null, null, 1, 0, 0, 24, 0, null, null, 'PVO-NTC', 'TCO');

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PA-NORM', 'PA- Payment Arrangement SA for Arrears', '1030100001', 'PA - ARREARS', null, null, 0, 1, 0, 10, 0, null, null, 'AR-ELC', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PPVAT-SPPC', 'BIR 2306 PPVAT - SPPC', '1', 'VAT Witholding', null, null, 1, 0, 0, 24, 0, null, null, 'PVO-SPPC', 'SPPC');

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-PAY-SSSL', 'Payable-SSS Loan', '3010201002', 'Payable-SSS Loan', null, null, 0, 1, 0, 0, 0, null, null, 'M-PAY-SSSL', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('VAT-SALES', 'VAT Sales', '0', 'VAT Sales', null, 10, 0, 0, 1, 12, null, null, null, null, null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('NON-VAT-SALES', 'Non-VAT Sales', '0', 'Non-VAT Sales', null, 14, 0, 0, 1, 14, null, null, null, null, null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('VAT-0-RATED', 'VAT Zero Rated Sales', '0', 'VAT Zero Rated Sales', null, 16, 0, 0, 1, 16, null, null, null, null, null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('BIR2306', 'BIR2306', '0', 'VAT Witholding', null, 24, 0, 0, 0, 24, null, null, null, null, null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('BIR2307', 'BIR2307', '0', 'Expanded Witholding', null, 26, 0, 0, 0, 26, null, null, null, null, null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PPVAT-TSI', 'BIR 2306 PPVAT - TSI', '1050107017', 'VAT Witholding', null, null, 1, 0, 0, 24, 0, null, null, 'PVO-TSI   ', 'TSI');

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PPVAT-WMPC', 'BIR 2306 PPVAT - WMPC', '1050107003', 'VAT Witholding', null, null, 1, 0, 0, 24, 0, null, null, 'PVO-NTC', 'WMPC');

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PPVAT-TMI', 'BIR 2306 PPVAT - TMI', '1050107006', 'VAT Witholding', null, null, 1, 0, 0, 24, 0, null, null, 'PVO-TMI   ', 'TMI');

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PPVAT-SMCPC', 'BIR 2306 PPVAT - SMCPC', '1050107022', 'VAT Witholding', null, null, 1, 0, 0, 24, 0, null, null, 'PVO-SMCPC', 'SMCP');

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PPVAT-IEMOP', 'BIR 2306 PPVAT - IEMOP', '1080511001', 'VAT Witholding', null, null, 1, 0, 0, 24, 0, null, null, 'PVO-IEMOP', 'IEMO');

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PPVAT-NGCP MPC', 'BIR 2306 PPVAT - MPC', '3011101001', 'VAT Witholding', null, null, 1, 0, 0, 24, 0, null, null, 'PVO-NMPC', 'MPC');

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PPVAT-NGCP UPMALITA', 'BIR 2306 PPVAT - UMB', '3011101001', 'VAT Witholding', null, null, 1, 0, 0, 24, 0, null, null, 'PVO-NUMB', 'UMB');

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PPVAT-NGCP UPMACO', 'BIR 2306 PPVAT - UPSI', '1080511001', 'VAT Witholding', null, null, 1, 0, 0, 24, 0, null, null, 'PVO-NUPSI', 'UPSI');

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('ADVANCE', 'Advance Payment', '3010104001', 'ADVANCE', null, 150, 0, 0, 1, 30, 0, null, null, null, null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('AR', 'Accounts Receivable', '1030101001', 'AR-ELECTRIC', null, 141, 0, 0, 1, 10, 0, null, null, null, null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('AR-VAT', 'Accounts Receivable VAT', '1030101001', 'VAT Amount', null, 100, 0, 0, 1, 20, 0, null, null, null, null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PILFERAGE', 'A/R from pilferage', '1030101001', 'AR-ELECTRIC', null, 155, 0, 0, 1, 10, 0, null, null, null, null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PA-PILFR', 'PA - Payment Arrangement SA for Pilferage', '1030101001', 'Pilferage Payment Arrangement', null, null, 0, 0, 0, 0, 0, null, null, 'AR-ELC    ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PA-NR', 'PA - Payment Arrangement SA for Notes Receivable', '1030101001', 'Notes Receivable Payment Arrangement', null, null, 0, 0, 0, 0, 0, null, null, 'AR-ELC    ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('A/P-ADIP', 'A/P - Accured Deposit Interest Payable', '3010301001', 'A/P - Accured Deposit Interest Payable', null, null, 0, 1, 0, 0, 0, null, null, 'A/P-ADIP  ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('A/P-ADV', 'Advance Payment From Customers-Trade', '4010301007', 'Advance Payment From Customers-Trade', null, null, 0, 1, 0, 0, 0, null, null, 'A/P-ADV   ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('A/P-EWTP', 'A/P - Expanded Withholding Tax Payable', '3010217004', 'A/P - Expanded Withholding Tax Payable', null, null, 0, 1, 0, 0, 0, null, null, 'A/P-EWTP  ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('AP-DIS-G', 'Vat Output-Distribution Revenues-Government', '3010213002', 'Vat Output-Distribution Revenues-Government', null, null, 0, 1, 0, 0, 0, null, null, 'AP-DIS-G  ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('AP-DIS-R', 'Vat Output-Distribution Revenues', '3010213001', 'Vat Output-Distribution Revenues', null, null, 0, 1, 0, 0, 0, null, null, 'AP-DIS-R  ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('AP-ETX', 'Energy Tax Payable', '3010212001', 'Energy Tax Payable', null, null, 0, 1, 0, 0, 0, null, null, 'AP-ETX    ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('AP-NPC-G', 'Vat Output-Generation-Npc-Government', '3010213009', 'Vat Output-Generation-Npc-Government', null, null, 0, 1, 0, 0, 0, null, null, 'AP-NPC-G  ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('AP-NPC-R', 'Vat Output-Generation-Npc', '3010213008', 'Vat Output-Generation-Npc', null, null, 0, 1, 0, 0, 0, null, null, 'AP-NPC-R  ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('AP-NTC-G', 'Vat Output-Transmission-Ntc-Government', '3010213011', 'Vat Output-Transmission-Ntc-Government', null, null, 0, 1, 0, 0, 0, null, null, 'AP-NTC-G  ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('AP-NTC-R', 'Vat Output-Transmission-Ntc', '3010213010', 'Vat Output-Transmission-Ntc', null, null, 0, 1, 0, 0, 0, null, null, 'AP-NTC-R  ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('AP-OTH-G', 'Vat Output-Others-Government', '3010213002', 'Vat Output-Others-Government', null, null, 0, 1, 0, 0, 0, null, null, 'AP-OTH-G  ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('AP-OTH-R', 'Vat Output - Others - Regular VAT', '3010213001', 'Vat Output - Others - Regular VAT', null, null, 0, 1, 0, 0, 0, null, null, 'AP-OTH-R  ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('AP-SL-BPP', 'Vat Output Sl Transmission Ntc', '3010213010', 'Vat Output Sl Transmission Ntc', null, null, 0, 1, 0, 0, 0, null, null, 'AP-SL-BPP ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('AP-SL-BPPG', 'Vat Output Sl Transmission Ntc-Government', '3010213011', 'Vat Output Sl Transmission Ntc-Government', null, null, 0, 1, 0, 0, 0, null, null, 'AP-SL-BPPG', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('AP-SL-NPC', 'Vat Output Sl Generation Npc', '3010213008', 'Vat Output Sl Generation Npc', null, null, 0, 1, 0, 0, 0, null, null, 'AP-SL-NPC ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('AP-SL-NPCG', 'Vat Output Sl Generation Npc-Government', '3010213009', 'Vat Output Sl Generation Npc-Government', null, null, 0, 1, 0, 0, 0, null, null, 'AP-SL-NPCG', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('AP-UEC', 'Payable-Uc-5-Environmental Charge', '3010203005', 'Payable-Uc-5-Environmental Charge', null, null, 0, 1, 0, 0, 0, null, null, 'AP-UEC    ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('AP-UME', 'Payable-Uc-3-Missionary Electrification', '3010203003', 'Payable-Uc-3-Missionary Electrification', null, null, 0, 1, 0, 0, 0, null, null, 'AP-UME    ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-WOALL', 'Misc - Write Off Service Agreement', '1030199001', 'MISC - WRITE OFF SERVICE AGREEMENT', null, null, 0, 1, 0, 0, 0, null, null, 'AR-ABD    ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('BK-BDO', 'Cash-Bdo Sa#334-002962-2', '1010102002', 'Cash-Bdo Sa#334-002962-2', null, null, 0, 1, 0, 0, 0, null, null, 'BK-BDO    ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('BK-CBC', 'Cash-Cbc Ca#293-000081-9', '1010103001', 'Cash-Cbc Ca#293-000081-9', null, null, 0, 1, 0, 0, 0, null, null, 'BK-CBC    ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('BK-DBP', 'Cash-Dbp Ca#0910-012753-030', '1010104001', 'Cash-Dbp Ca#0910-012753-030', null, null, 0, 1, 0, 0, 0, null, null, 'BK-DBP    ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('BK-LBP', 'Cash-Lbp Sa#0371-000-97', '1010103003', 'Cash-Lbp Sa#0371-000-97', null, null, 0, 1, 0, 0, 0, null, null, 'BK-LBP    ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('BK-MBT', 'Cash-Mbtc Sa#074-302200288-0', '1010102004', 'Cash-Mbtc Sa#074-302200288-0', null, null, 0, 1, 0, 0, 0, null, null, 'BK-MBT    ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('BK-PNB', 'Cash-Pnb Ca#30-621-170001-7', '1010103004', 'Cash-Pnb Ca#30-621-170001-7', null, null, 0, 1, 0, 0, 0, null, null, 'BK-PNB    ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('BK-RBC', 'Cash-Rbc Ca#21-00045-2', '1010103005', 'Cash-Rbc Ca#21-00045-2', null, null, 0, 1, 0, 0, 0, null, null, 'BK-RBC    ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('BK-RCBC', 'Cash-Rcbc Ca#O-506-80046-3', '1010103006', 'Cash-Rcbc Ca#O-506-80046-3', null, null, 0, 1, 0, 0, 0, null, null, 'BK-RCBC   ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('BK-UCP', 'Cash-Ucpb Ca#408-012020-6', '1010103007', 'Cash-Ucpb Ca#408-012020-6', null, null, 0, 1, 0, 0, 0, null, null, 'BK-UCP    ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('C-DISCPILF', 'Subsidy/Discount On Pilferage And/Or Backbilling', '1010400002', 'Subsidy/Discount On Pilferage And/Or Backbilling', null, null, 0, 1, 0, 0, 0, null, null, 'C-DISCPILF', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('CC-CSH', 'Cash Clearing-Ccb', '1010201001', 'Cash Clearing-Ccb', null, null, 0, 1, 0, 0, 0, null, null, 'CC-CSH    ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('D-BILL', 'Customer Deposit Payable - Bill', '4010301001', 'BILL DEPOSIT', null, null, 0, 1, 0, 0, 0, null, null, 'CDP-BILL  ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('D-KVA', 'Customer Deposit Payable - Kva Transformer Capacity', '4010301009', 'KVA CAPACITY ADVANCE', null, null, 0, 1, 0, 0, 0, null, null, 'CDP-KVAR  ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('CDP-LABKV', 'Customer Deposit Payable-Labor- Kva Capacity Transformers', '4010301012', 'Customer Deposit Payable-Labor- Kva Capacity Transformers', null, null, 0, 1, 0, 0, 0, null, null, 'CDP-LABKV ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('CDP-LABLP', 'Customer Deposit Payable-Labor- Lines Poles', '4010301010', 'Customer Deposit Payable-Labor- Lines Poles', null, null, 0, 1, 0, 0, 0, null, null, 'CDP-LABLP ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('D-LABR', 'Customer Deposit Payable - Labor', '4010301007', 'SPECIAL LABOR ADVANCE', null, null, 0, 1, 0, 0, 0, null, null, 'CDP-LABR  ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('CDP-LABTR', 'Customer Deposit Payable-Labor- Transformers', '4010301011', 'Customer Deposit Payable-Labor- Transformers', null, null, 0, 1, 0, 0, 0, null, null, 'CDP-LABTR ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('D-LIPO', 'Customer Deposit Payable - Lines And Poles (Special Advance)', '4010301003', 'LINES AND POLES ADVANCE', null, null, 0, 1, 0, 0, 0, null, null, 'CDP-LIPO  ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('D-XFMR', 'Customer Deposit Payable - Transformer (Special Advance)', '4010301006', 'DEPOSITS - TRANSFORMER SPECIAL ADVANCE', null, null, 0, 1, 0, 0, 0, null, null, 'CDP-XFMR  ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-CBCHG', 'Miscellaneous Payments Clearing', '1030214001', 'MISC - CIS BILLABLE CHARGE', null, null, 0, 1, 0, 0, 0, null, null, 'CLR-MISC  ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('CLR-REF', 'Refund Clearing', '4010301013', 'Refund Clearing', null, null, 0, 1, 0, 0, 0, null, null, 'CLR-REF   ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('CLR-XFER', 'Transfer Clearing', '1010400001', 'Transfer Clearing', null, null, 0, 1, 0, 0, 0, null, null, 'CLR-XFER  ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('DUMMY', 'Dummy GL', '1050999999', 'Dummy GL', null, null, 0, 1, 0, 0, 0, null, null, 'DUMMY     ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('DV-DIS-G', 'Deferred Vat Output Distribution Revenues-Government', '4040301002', 'Deferred Vat Output Distribution Revenues-Government', null, null, 0, 1, 0, 0, 0, null, null, 'DV-DIS-G  ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('DV-DIS-R', 'Deferred Vat Output Distribution Revenues', '4040301001', 'Deferred Vat Output Distribution Revenues', null, null, 0, 1, 0, 0, 0, null, null, 'DV-DIS-R  ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('DV-ETX', 'Deferred Energy Tax', '4040501001', 'Deferred Energy Tax', null, null, 0, 1, 0, 0, 0, null, null, 'DV-ETX    ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('DV-NPC-G', 'Deferred Vat Pass-On Generation Npc-Government', '4040301004', 'Deferred Vat Pass-On Generation Npc-Government', null, null, 0, 1, 0, 0, 0, null, null, 'DV-NPC-G  ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('DV-NPC-R', 'Deferred Vat Pass-On Generation Npc', '4040301003', 'Deferred Vat Pass-On Generation Npc', null, null, 0, 1, 0, 0, 0, null, null, 'DV-NPC-R  ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('DV-NTC-G', 'Deferred Vat Pass-On Transmission Ntc-Government', '4040301006', 'Deferred Vat Pass-On Transmission Ntc-Government', null, null, 0, 1, 0, 0, 0, null, null, 'DV-NTC-G  ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('DV-NTC-R', 'Deferred Vat Pass-On Transmission Ntc', '4040301005', 'Deferred Vat Pass-On Transmission Ntc', null, null, 0, 1, 0, 0, 0, null, null, 'DV-NTC-R  ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('DV-OTH-G', 'Deferred Vat Output Others-Government', '4040301002', 'Deferred Vat Output Others-Government', null, null, 0, 1, 0, 0, 0, null, null, 'DV-OTH-G  ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('DV-OTH-R', 'Deferred Vat Output Others', '4040301001', 'Deferred Vat Output Others', null, null, 0, 1, 0, 0, 0, null, null, 'DV-OTH-R  ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('DV-SL-NPC', 'Deferred Vat Sl Generation Npc', '4040301003', 'Deferred Vat Sl Generation Npc', null, null, 0, 1, 0, 0, 0, null, null, 'DV-SL-NPC ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('DV-SL-NPCG', 'Deferred Vat Sl Generation Npc-Government', '4040301004', 'Deferred Vat Sl Generation Npc-Government', null, null, 0, 1, 0, 0, 0, null, null, 'DV-SL-NPCG', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('DV-SL-NTC', 'Deferred Vat Sl Transmission Ntc', '4040301005', 'Deferred Vat Sl Transmission Ntc', null, null, 0, 1, 0, 0, 0, null, null, 'DV-SL-NTC ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('DV-SL-NTCG', 'Deferred Vat Sl Transmission Ntc-Government', '4040301006', 'Deferred Vat Sl Transmission Ntc-Government', null, null, 0, 1, 0, 0, 0, null, null, 'DV-SL-NTCG', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('DV-UEC', 'Deferred-Uc-5-Environmental Charge', '4040601005', 'Deferred-Uc-5-Environmental Charge', null, null, 0, 1, 0, 0, 0, null, null, 'DV-UEC    ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-ADV-EMPR', 'Advances - Employees Loan-Rank And File', '1030212011', 'Advances - Employees Loan-Rank And File', null, null, 0, 1, 0, 0, 0, null, null, 'M-ADV-EMPR', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-ADV-HELC', 'Advances – Helmets-Confi/Management', '1030212013', 'Advances – Helmets-Confi/Management', null, null, 0, 1, 0, 0, 0, null, null, 'M-ADV-HELC', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-ADV-HELR', 'Advances – Helmets-Rank And File', '1030212013', 'Advances – Helmets-Rank And File', null, null, 0, 1, 0, 0, 0, null, null, 'M-ADV-HELR', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-ADV-MEC', 'Advances - Medicine - Rank And File', '1030212004', 'Advances - Medicine - Rank And File', null, null, 0, 1, 0, 0, 0, null, null, 'M-ADV-MEC ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-ADV-MECC', 'Advances - Medicine - Confi/Management', '1030212004', 'Advances - Medicine - Confi/Management', null, null, 0, 1, 0, 0, 0, null, null, 'M-ADV-MECC', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-ADV-MEDC', 'Advances – Medical/Hospitalization - Confi/Management', '1030212003', 'Advances – Medical/Hospitalization - Confi/Management', null, null, 0, 1, 0, 0, 0, null, null, 'M-ADV-MEDC', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-ADV-MEDR', 'Advances – Medical/Hospitalization - Rank And File', '1030212003', 'Advances – Medical/Hospitalization - Rank And File', null, null, 0, 1, 0, 0, 0, null, null, 'M-ADV-MEDR', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-ADV-MOTC', 'Advances - Motor Bike Plans-Confi/Management', '1030212005', 'Advances - Motor Bike Plans-Confi/Management', null, null, 0, 1, 0, 0, 0, null, null, 'M-ADV-MOTC', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-ADV-MOTR', 'Advances - Motor Bike Plans- Rank And File', '1030212005', 'Advances - Motor Bike Plans- Rank And File', null, null, 0, 1, 0, 0, 0, null, null, 'M-ADV-MOTR', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-ADV-OPT', 'Advances - Optical - Rank And File', '1030212006', 'Advances - Optical - Rank And File', null, null, 0, 1, 0, 0, 0, null, null, 'M-ADV-OPT ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-ADV-OPTC', 'Advances - Optical - Confi/Management', '1030212006', 'Advances - Optical - Confi/Management', null, null, 0, 1, 0, 0, 0, null, null, 'M-ADV-OPTC', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-ADV-OTC', 'Advances - Over-The-Counter Medicines - Rank And File', '1030212007', 'Advances - Over-The-Counter Medicines - Rank And File', null, null, 0, 1, 0, 0, 0, null, null, 'M-ADV-OTC ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-ADV-OTCC', 'Advances - Over The Counter- Confi/Management', '1030212007', 'Advances - Over The Counter- Confi/Management', null, null, 0, 1, 0, 0, 0, null, null, 'M-ADV-OTCC', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-ADV-OTHC', 'Advances – Others-Confi/Management File', '1030212091', 'Advances – Others-Confi/Management File', null, null, 0, 1, 0, 0, 0, null, null, 'M-ADV-OTHC', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-ADV-OTHR', 'Advances – Others-Rank And File', '1030212091', 'Advances – Others-Rank And File', null, null, 0, 1, 0, 0, 0, null, null, 'M-ADV-OTHR', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-ADV-PHOC', 'Advances - Photocopy', '1030212010', 'Advances - Photocopy', null, null, 0, 1, 0, 0, 0, null, null, 'M-ADV-PHOC', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-ADV-PHOR', 'Advances - Photocopy', '1030212010', 'Advances - Photocopy', null, null, 0, 1, 0, 0, 0, null, null, 'M-ADV-PHOR', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-ADV-TELC', 'Advances - Telephone/Cellphone Bills-Confi/Management', '1030212008', 'Advances - Telephone/Cellphone Bills-Confi/Management', null, null, 0, 1, 0, 0, 0, null, null, 'M-ADV-TELC', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-ADV-TELR', 'Advances - Telephone/Cellphone Bills-Rank And File', '1030212008', 'Advances - Telephone/Cellphone Bills-Rank And File', null, null, 0, 1, 0, 0, 0, null, null, 'M-ADV-TELR', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-ADV-UCA', 'Unexpended Cash Advance', '1030213001', 'Unexpended Cash Advance', null, null, 0, 1, 0, 0, 0, null, null, 'M-ADV-UCA ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-AFF-ABLA', 'Receivable From Aboitizland Inc', '1030207006', 'Receivable From Aboitizland Inc', null, null, 0, 1, 0, 0, 0, null, null, 'M-AFF-ABLA', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-AFF-ACO', 'Receivable From Aco', '1030207001', 'Receivable From Aco', null, null, 0, 1, 0, 0, 0, null, null, 'M-AFF-ACO ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-AFF-AESI', 'Receivable From Apsi / Aes', '1030207002', 'Receivable From Apsi / Aes', null, null, 0, 1, 0, 0, 0, null, null, 'M-AFF-AESI', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-AFF-AEV', 'Receivable From Aev', '1030207003', 'Receivable From Aev', null, null, 0, 1, 0, 0, 0, null, null, 'M-AFF-AEV ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-AFF-AGFI', 'Receivable From Agfi', '1030207004', 'Receivable From Agfi', null, null, 0, 1, 0, 0, 0, null, null, 'M-AFF-AGFI', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-AFF-APC', 'Receivable From Apc', '1030207005', 'Receivable From Apc', null, null, 0, 1, 0, 0, 0, null, null, 'M-AFF-APC ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-AFF-BEZC', 'Receivable From Bezc', '1030207007', 'Receivable From Bezc', null, null, 0, 1, 0, 0, 0, null, null, 'M-AFF-BEZC', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-AFF-CIPI', 'Receivable From CIPI', '1030207014', 'Receivable From CIPI', null, null, 0, 1, 0, 0, 0, null, null, 'M-AFF-CIPI', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-AFF-DLPC', 'Receivable From Dlpc', '1030207008', 'Receivable From Dlpc', null, null, 0, 1, 0, 0, 0, null, null, 'M-AFF-DLPC', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-AFF-HED', 'Receivable From Hedcor', '1030207009', 'Receivable From Hedcor', null, null, 0, 1, 0, 0, 0, null, null, 'M-AFF-HED ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-AFF-META', 'Receivable From Metaphil', '1030207013', 'Receivable From Metaphil', null, null, 0, 1, 0, 0, 0, null, null, 'M-AFF-META', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-AFF-MEZC', 'Receivable From Mezc', '1030207010', 'Receivable From Mezc', null, null, 0, 1, 0, 0, 0, null, null, 'M-AFF-MEZC', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-AFF-PIL', 'Receivable From Pilmico', '1030207015', 'Receivable From Pilmico', null, null, 0, 1, 0, 0, 0, null, null, 'M-AFF-PIL ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-AFF-SEZC', 'Receivable From Sezc', '1030207011', 'Receivable From Sezc', null, null, 0, 1, 0, 0, 0, null, null, 'M-AFF-SEZC', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-AFF-VECO', 'Receivable From Veco', '1030207012', 'Receivable From Veco', null, null, 0, 1, 0, 0, 0, null, null, 'M-AFF-VECO', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-CLA-BGC', 'Claims From Broken Glass Cover', '9019999999', 'Claims From Broken Glass Cover', null, null, 0, 1, 0, 0, 0, null, null, 'M-CLA-BGC ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-CLA-BUM', 'Claims From Bump Poles', '9019999999', 'Claims From Bump Poles', null, null, 0, 1, 0, 0, 0, null, null, 'M-CLA-BUM ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-CLA-DAM', 'Claim Damages', '9019999999', 'Claim Damages', null, null, 0, 1, 0, 0, 0, null, null, 'M-CLA-DAM ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-CLA-IMP', 'Collection From Claims From Importation', '1030203002', 'Collection From Claims From Importation', null, null, 0, 1, 0, 0, 0, null, null, 'M-CLA-IMP ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-CLA-INS', 'Collection From Insurance Claim', '1030203001', 'Collection From Insurance Claim', null, null, 0, 1, 0, 0, 0, null, null, 'M-CLA-INS ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-CLA-OTH', 'Accounts Receivable Miscellaneous Claims', '1030203999', 'Accounts Receivable Miscellaneous Claims', null, null, 0, 1, 0, 0, 0, null, null, 'M-CLA-OTH ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-CLA-SHP', 'Collection From Claims From Shipment', '1030203003', 'Collection From Claims From Shipment', null, null, 0, 1, 0, 0, 0, null, null, 'M-CLA-SHP ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-CLA-SMTR', 'Claims From Stolen Meter', '9019999999', 'Claims From Stolen Meter', null, null, 0, 1, 0, 0, 0, null, null, 'M-CLA-SMTR', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-CLA-SSS', 'Collection From Claims From Sss', '1030203004', 'Collection From Claims From Sss', null, null, 0, 1, 0, 0, 0, null, null, 'M-CLA-SSS ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-COL-BDR', 'Bad Debts Recovery', '9019025001', 'Bad Debts Recovery', null, null, 0, 1, 0, 0, 0, null, null, 'M-COL-BDR ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-CSH-O/S', 'Ar Non Trade-Cash Over/Short - Teller Or Collector', '1030201014', 'Ar Non Trade-Cash Over/Short - Teller Or Collector', null, null, 0, 1, 0, 0, 0, null, null, 'M-CSH-O/S ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-LAB-PMTS', 'Labor Payments', '9019003001', 'Labor Payments', null, null, 0, 1, 0, 0, 0, null, null, 'M-LAB-PMTS', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-LAB-TEST', 'Labor/Material For Transformer Testing', '9019009005', 'Labor/Material For Transformer Testing', null, null, 0, 1, 0, 0, 0, null, null, 'M-LAB-TEST', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-MAT-IOS', 'Income On Supplies', '9019099003', 'Income On Supplies', null, null, 0, 1, 0, 0, 0, null, null, 'M-MAT-IOS ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-MAT-LP', 'Lines And Poles Payment', '9019009004', 'Lines And Poles Payment', null, null, 0, 1, 0, 0, 0, null, null, 'M-MAT-LP  ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-MAT-SCP', 'Scrap Materials', '9019002001', 'Scrap Materials', null, null, 0, 1, 0, 0, 0, null, null, 'M-MAT-SCP ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-OTH-BFL', 'Other Income - Busted Fuse Limiter', '9019999999', 'Other Income - Busted Fuse Limiter', null, null, 0, 1, 0, 0, 0, null, null, 'M-OTH-BFL ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-OTH-CPP', 'Other Income - Compromise Penalty (Pilferage)', '9019999999', 'Other Income - Compromise Penalty (Pilferage)', null, null, 0, 1, 0, 0, 0, null, null, 'M-OTH-CPP ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-OTH-DI', 'Other Income - Cash Dividend', '9010101001', 'Other Income - Cash Dividend', null, null, 0, 1, 0, 0, 0, null, null, 'M-OTH-DI  ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-OTH-NV', 'Others - Non Vat', '9019999999', 'Others - Non Vat', null, null, 0, 1, 0, 0, 0, null, null, 'M-OTH-NV  ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-OTH-PIC', 'Other Income - Penalty-Illegal Connection', '9019999999', 'Other Income - Penalty-Illegal Connection', null, null, 0, 1, 0, 0, 0, null, null, 'M-OTH-PIC ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('DV-UME', 'Deferred-Uc-3-Missionary Electrification', '4040601003', 'Deferred-Uc-3-Missionary Electrification', null, null, 0, 1, 0, 0, 0, null, null, 'DV-UME    ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('EXP-GSL', 'Adjustment for PBR Guaranteed Service Level', '8030306001', 'Adjustment for PBR Guaranteed Service Level', null, null, 0, 1, 0, 0, 0, null, null, 'EXP-GSL   ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('EXP-INT', 'Expense - Interest Expense', '9020203001', 'Expense - Interest Expense', null, null, 0, 1, 0, 0, 0, null, null, 'EXP-INT   ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-ADV-DEN', 'Advances - Dental - Rank And File', '1030212002', 'Advances - Dental - Rank And File', null, null, 0, 1, 0, 0, 0, null, null, 'M-ADV-DEN ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-ADV-DENC', 'Advances - Dental - Confi/Management', '1030212002', 'Advances - Dental - Confi/Management', null, null, 0, 1, 0, 0, 0, null, null, 'M-ADV-DENC', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-ADV-EMPC', 'Advances - Employees Loan-Confi/Management', '1030212011', 'Advances - Employees Loan-Confi/Management', null, null, 0, 1, 0, 0, 0, null, null, 'M-ADV-EMPC', null);

commit;