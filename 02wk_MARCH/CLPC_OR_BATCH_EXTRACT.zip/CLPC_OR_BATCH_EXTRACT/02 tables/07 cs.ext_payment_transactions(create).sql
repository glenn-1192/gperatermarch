-- Create table
create table EXT_PAYMENT_TRANSACTIONS
(
  ext_batch_no NUMBER not null,
  tran_no      NUMBER not null,
  receipt_type VARCHAR2(5),
  payer_id     VARCHAR2(20),
  payer_type   VARCHAR2(10),
  last_name    VARCHAR2(100),
  first_name   VARCHAR2(50),
  mid_name     VARCHAR2(50),
  address      VARCHAR2(200),
  site_code    VARCHAR2(30),
  or_no        NUMBER,
  or_date      DATE,
  bus_style    VARCHAR2(100),
  tin          VARCHAR2(20),
  revenue_tag  VARCHAR2(20),
  teller       VARCHAR2(30),
  collector_no NUMBER,
  or_count     NUMBER,
  amount_paid  NUMBER(15,2),
  batch_no     NUMBER(15)
);
-- Create/Recreate primary, unique and foreign key constraints 
alter table EXT_PAYMENT_TRANSACTIONS
  add constraint EXT_PAYMENT_TRANS_PK primary key (EXT_BATCH_NO, TRAN_NO);
  
alter table EXT_PAYMENT_TRANSACTIONS
  add constraint EXT_PAYMENT_TRANS_FK foreign key (EXT_BATCH_NO)
  references OR_EXTRACT_PARAMS (EXT_BATCH_NO);
-- Create/Recreate check constraints 
alter table EXT_PAYMENT_TRANSACTIONS
  add constraint C28_SYS_C0028800
  check ("RECEIPT_TYPE" IS NOT NULL);
alter table EXT_PAYMENT_TRANSACTIONS
  add constraint C28_SYS_C0028801
  check ("PAYER_ID" IS NOT NULL);
alter table EXT_PAYMENT_TRANSACTIONS
  add constraint C28_SYS_C0028802
  check ("PAYER_TYPE" IS NOT NULL);
alter table EXT_PAYMENT_TRANSACTIONS
  add constraint C28_SYS_C0028803
  check ("AMOUNT_PAID" IS NOT NULL);
-- Grant/Revoke object privileges 
grant select on EXT_PAYMENT_TRANSACTIONS to KATAMBAK_USER;
