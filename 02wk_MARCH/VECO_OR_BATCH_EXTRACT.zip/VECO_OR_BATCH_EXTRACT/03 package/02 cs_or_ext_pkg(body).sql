create or replace package body cs_or_ext_pkg as

/*
       Revision History
        v1.0.0 by gperater on March 07, 2024
               purpose of change : newly created package for the sole purpose of installing VECO OR Batch Extract, replicated all functions & procedure
                                   from dlpc or batch extract

    end revision history
*/

    function get_amount_paid(p_tran_no in number) return number as
        l_amount_paid number(15, 2);
    begin
        declare
            l_esb number(5);
        begin
            select count(*)
            into   l_esb
            from   esb_paid_items
            where  tran_no = p_tran_no;

            if l_esb >= 1
            then
                select nvl(sum(amount_credit), 0)
                into   l_amount_paid
                from   esb_paid_items
                where  tran_no = p_tran_no
                and    amount_credit > 0;
            else
                select nvl(sum(amount_credit), 0)
                into   l_amount_paid
                from   esb_paid_items_hist
                where  tran_no = p_tran_no
                and    amount_credit > 0;
            end if;
        end;
        return l_amount_paid;
    end get_amount_paid;

    procedure insert_zero_paid_items(p_ext_batch_no in number,
                                   p_tran_no      in number,
                                   p_state        in out number,
                                   p_errmsg       in out varchar2) as
        l_seq_no  number := 0;
        l_errline number;

    begin
        l_errline := 10;
        l_seq_no := l_seq_no + 1;
        insert into ext_paid_items
            (ext_batch_no,
             tran_no,
             seq_no,
             pay_code,
             amount_credit,
             bill_no)
        values
            (p_ext_batch_no, p_tran_no, l_seq_no, 'VAT-SALES', 0, null);

        l_errline := 20;
        l_seq_no := l_seq_no + 1;
        insert into ext_paid_items
            (ext_batch_no,
             tran_no,
             seq_no,
             pay_code,
             amount_credit,
             bill_no)
        values
            (p_ext_batch_no, p_tran_no, l_seq_no, 'NON-VAT-SALES', 0, null);

        l_errline := 30;
        l_seq_no := l_seq_no + 1;
        insert into ext_paid_items
            (ext_batch_no,
             tran_no,
             seq_no,
             pay_code,
             amount_credit,
             bill_no)
        values
            (p_ext_batch_no, p_tran_no, l_seq_no, 'VAT-0-RATED', 0, null);


        l_errline := 40;
        l_seq_no := l_seq_no + 1;
        insert into ext_paid_items
            (ext_batch_no,
             tran_no,
             seq_no,
             pay_code,
             amount_credit,
             bill_no)
        values
            (p_ext_batch_no, p_tran_no, l_seq_no, 'UC-FIT_ALL', 0, null);

        l_errline := 50;
        l_seq_no := l_seq_no + 1;
        insert into ext_paid_items
            (ext_batch_no,
             tran_no,
             seq_no,
             pay_code,
             amount_credit,
             bill_no)
        values
            (p_ext_batch_no, p_tran_no, l_seq_no, 'AR-VAT', 0, null);

        p_state := 0;
    exception
        when others then
            p_errmsg := 'Error found @insert_for_adv_lines ' ||
                        to_char(l_errline) || ' ' || sqlerrm;
            p_state := -1;
    end insert_zero_paid_items;



    procedure insert_for_adv_lines(p_ext_batch_no in number,
                                   p_tran_no      in number,
                                   p_state        in out number,
                                   p_errmsg       in out varchar2) as
        l_seq_no  number := 0;
        l_errline number;

    begin
        l_errline := 10;
        l_seq_no := l_seq_no + 1;
        insert into ext_paid_items
            (ext_batch_no,
             tran_no,
             seq_no,
             pay_code,
             amount_credit,
             bill_no)
        values
            (p_ext_batch_no, p_tran_no, l_seq_no, 'VAT-SALES', 0, null);

        l_errline := 20;
        l_seq_no := l_seq_no + 1;
        insert into ext_paid_items
            (ext_batch_no,
             tran_no,
             seq_no,
             pay_code,
             amount_credit,
             bill_no)
        values
            (p_ext_batch_no, p_tran_no, l_seq_no, 'VAT-EXEMPT', 0, null);

        l_errline := 30;
        l_seq_no := l_seq_no + 1;
        insert into ext_paid_items
            (ext_batch_no,
             tran_no,
             seq_no,
             pay_code,
             amount_credit,
             bill_no)
        values
            (p_ext_batch_no, p_tran_no, l_seq_no, 'VAT-0-RATED', 0, null);

        l_errline := 40;
        l_seq_no := l_seq_no + 1;
        insert into ext_paid_items
            (ext_batch_no,
             tran_no,
             seq_no,
             pay_code,
             amount_credit,
             bill_no)
        values
            (p_ext_batch_no, p_tran_no, l_seq_no, 'UC-FIT_ALL', 0, null);

        l_errline := 50;
        l_seq_no := l_seq_no + 1;
        insert into ext_paid_items
            (ext_batch_no,
             tran_no,
             seq_no,
             pay_code,
             amount_credit,
             bill_no)
        values
            (p_ext_batch_no, p_tran_no, l_seq_no, 'AR-VAT', 0, null);

        p_state := 0;
    exception
        when others then
            p_errmsg := 'Error found @insert_for_adv_lines ' ||
                        to_char(l_errline) || ' ' || sqlerrm;
            p_state := -1;
    end insert_for_adv_lines;


    procedure insert_fops(p_ext_batch_no in number,
                          p_tran_no      in number,
                          p_state        in out number,
                          p_errmsg       in out varchar2) as
        l_seq_no  number(3);
        l_errline number;
    begin
        declare
            l_max_tran_no number;
            l_batch_no    number;
            l_or_date     date;
        begin
            l_errline := 10;
            select batch_no, or_date
            into   l_batch_no, l_or_date
            from   payment_transactions
            where  tran_no = p_tran_no;

            l_errline := 20;
            select max(tran_no)
            into   l_max_tran_no
            from   payment_transactions
            where  batch_no = l_batch_no
            and    or_date = l_or_date
            and    tran_no = p_tran_no;

            l_errline := 30;
            insert into ext_forms_of_payments
                (ext_batch_no, tran_no, seq_no, payment_type, amount_paid)
                select p_ext_batch_no,
                       p_tran_no,
                       seq_no,
                       payment_type,
                       amount_paid
                from   forms_of_payment
                where  tran_no = l_max_tran_no;

            l_errline := 40;
            insert into ext_fop_cash
                (ext_batch_no, tran_no, seq_no, amount_tendered)
                select p_ext_batch_no, p_tran_no, seq_no, amount_tendered
                from   fop_cash
                where  tran_no = l_max_tran_no;

            l_errline := 50;
            insert into ext_fop_checks
                (ext_batch_no,
                 tran_no,
                 seq_no,
                 bank_code,
                 check_date,
                 check_no,
                 bank_branch,
                 check_type,
                 drop_box)
                select p_ext_batch_no,
                       p_tran_no,
                       ch.seq_no,
                       lib.bank_short_name,
                       ch.check_date,
                       ch.check_no,
                       ch.bank_branch,
                       ch.check_type,
                       ch.drop_box
                from   fop_checks ch, lib_banks lib
                where  ch.bank_code = lib.bank_code
                and    ch.tran_no = l_max_tran_no;

            l_errline := 60;
            insert into ext_fop_cr_dr_cards
                (ext_batch_no,
                 tran_no,
                 seq_no,
                 service_provider,
                 tran_type,
                 card_type,
                 ref_no,
                 trace_no)
                select p_ext_batch_no,
                       p_tran_no,
                       seq_no,
                       service_provider,
                       tran_type,
                       card_type,
                       ref_no,
                       trace_no
                from   fop_cr_dr_cards
                where  tran_no = l_max_tran_no;
        end;

        /*
        l_errline := 70;
        declare
            l_total_fop number(15,2);
            l_total_paid number(15,2);
        begin
             select nvl(sum(amount_paid),0)
             into   l_total_fop
             from   forms_of_payment
             where  tran_no = p_tran_no;

             select nvl(sum(amount_credit),0)
             into   l_total_paid
             from   paid_items
             where  tran_no = p_tran_no;

             if (l_total_fop <> l_total_paid)
             then
                 l_errline := 80;
                 delete from ext_fop_cash
                 where ext_batch_no =  p_ext_batch_no
                 and  tran_no = p_tran_no;

                 l_errline := 90;
                 delete from ext_fop_cash
                 where ext_batch_no =  p_ext_batch_no
                 and  tran_no = p_tran_no;

                 l_errline := 100;
                 delete from ext_fop_checks
                 where ext_batch_no =  p_ext_batch_no
                 and  tran_no = p_tran_no;

                 l_errline := 110;
                 delete from ext_fop_cr_dr_cards
                 where ext_batch_no =  p_ext_batch_no
                 and  tran_no = p_tran_no;

                 l_errline := 120;
                 delete from ext_forms_of_payments
                 where ext_batch_no =  p_ext_batch_no
                 and  tran_no = p_tran_no;

                 l_errline := 130;
                 insert into ext_forms_of_payments
                     (ext_batch_no, tran_no, seq_no, payment_type, amount_paid)
                  values(p_ext_batch_no, p_tran_no, 1, 'CASH', l_total_paid);

                 l_errline := 140;
                 insert into ext_fop_cash
                     (ext_batch_no, tran_no, seq_no, amount_tendered)
                  values(p_ext_batch_no, p_tran_no, 1, l_total_paid);
             end if;
        end;*/

        p_state := 0;
    exception
        when others then
            p_errmsg := 'Error found @insert_fops ' || to_char(l_errline) || ' ' ||
                        sqlerrm;
            p_state := -1;
    end insert_fops;


    procedure log_error(p_raised_by in varchar2, p_errmsg in varchar2) as
        pragma autonomous_transaction;
    begin
        insert into cs.error_logs
            (raised_by, error_message)
        values
            (p_raised_by, p_errmsg);
        commit;
    end log_error;

    function get_source(p_du_code in varchar2) return varchar2 as
        l_source varchar2(500);
    begin
        l_source := 'CCB';
        begin
            select att_value
            into   l_source
            from   du_code_att
            where  att_code = 'DATA_SOURCE'
            and    du_code = p_du_code;
        exception
            when no_data_found then
                null;
        end;
        return l_source;
    end get_source;

    function get_non_vat(p_bill_no in varchar2) return number as
        --'Non-Vatable Charge'
        l_nonvat  number(15, 2);
        l_errline number;
    begin

        l_errline := 10;
        select nvl(sum(calc.calc_amt), 0)
        into   l_nonvat
        from   ci_bseg bseg, ci_bseg_calc_ln calc
        where  bseg.bseg_id = calc.bseg_id
        and    bseg.bseg_stat_flg = '50'
        and    calc.prt_sw = 'Y'
        and    calc.dst_id in ('Z-GEN     ','Z-TRX     ','Z-SLF     ','Z-SYS     ','REV-PSALM ','REV-PSALMZ')
        and    bseg.bill_id = p_bill_no;

        return l_nonvat;
    end get_non_vat;

    function get_uc(p_bill_no in varchar2) return number as
        --'Universal Charge%'
        l_uc      number(15, 2);
        l_errline number;
    begin

        l_errline := 10;
        select nvl(sum(calc.calc_amt), 0)
        into   l_uc
        from   ci_bseg bseg, ci_bseg_calc_ln calc
        where  bseg.bseg_id = calc.bseg_id
        and    bseg.bseg_stat_flg = '50'
        and    calc.prt_sw = 'Y'
        and    calc.descr_on_bill like 'Universal Charge%'
        and    bseg.bill_id = p_bill_no;

        return l_uc;
    end get_uc;

    function get_fit_all(p_bill_no in varchar2) return number as
        --'Feed In Tariff Allowance%'
        l_fit_all number(15, 2);
        l_errline number;
    begin

        l_errline := 10;
        select nvl(sum(calc.calc_amt), 0)
        into   l_fit_all
        from   ci_bseg bseg, ci_bseg_calc_ln calc
        where  bseg.bseg_id = calc.bseg_id
        and    bseg.bseg_stat_flg = '50'
        and    calc.prt_sw = 'Y'
        and    calc.descr_on_bill like 'Feed In Tariff Allowance%'
        and    bseg.bill_id = p_bill_no;

        return l_fit_all;
    end get_fit_all;


    function get_vat(p_bill_no in varchar2) return number as
        --'VAT%'
        l_vat     number(15, 2);
        l_errline number;
    begin

        l_errline := 10;
        select nvl(sum(calc.calc_amt), 0)
        into   l_vat
        from   ci_bseg bseg, ci_bseg_calc_ln calc
        where  bseg.bseg_id = calc.bseg_id
        and    bseg.bseg_stat_flg = '50'
        and    calc.prt_sw = 'N'
        and    calc.descr_on_bill = 'VAT Total'
        --and    calc.descr_on_bill like 'VAT%'
        and    bseg.bill_id = p_bill_no;

        return l_vat;
    end get_vat;

    procedure insert_cs_data(p_ext_batch_no in number,
                             p_tran_no      in number,
                             p_state        in out number,
                             p_errmsg       in out varchar2) as

        l_seq_no  number(3);
        l_errline number;
    begin
        l_seq_no := 0;

        l_errline := 10;
        for l_cur in (select pad.tran_no,
                             pad.seq_no,
                             pad.acct_no,
                             pad.bill_no,
                             pad.bill_month,
                             pad.bill_date,
                             pad.due_date,
                             pad.amount_due,
                             pi.pay_code,
                             pi.amount_credit
                      from   paid_ar_details pad, paid_items pi
                      where  pad.tran_no = pi.tran_no
                      and    pad.tran_no = p_tran_no)
        loop
            l_seq_no := l_seq_no + 1;

            l_errline := 20;
            insert into ext_paid_ar_details
                (ext_batch_no,
                 tran_no,
                 seq_no,
                 acct_no,
                 bill_no,
                 bill_month,
                 bill_date,
                 due_date,
                 ar_balance,
                 org_bill_amount)
            values
                (p_ext_batch_no,
                 l_cur.tran_no,
                 l_seq_no,
                 l_cur.acct_no,
                 l_cur.bill_no,
                 l_cur.bill_month,
                 l_cur.bill_date,
                 l_cur.due_date,
                 l_cur.amount_due,
                 l_cur.amount_due -->> for checking
                 );

            l_errline := 30;

            insert into ext_paid_items
                (ext_batch_no,
                 tran_no,
                 seq_no,
                 pay_code,
                 amount_credit,
                 bill_no)
            values
                (p_ext_batch_no,
                 l_cur.tran_no,
                 l_seq_no,
                 l_cur.pay_code,
                 l_cur.amount_credit,
                 l_cur.bill_no);

        end loop;

        p_state := 0;
    exception
        when others then
            p_errmsg := 'Error found @insert_cs_data line : ' ||
                        to_char(l_errline) || ' ' || sqlerrm;
            log_error(user, p_errmsg);
            p_state := -1;
            rollback;
    end insert_cs_data;

    procedure insert_vat_exempt(p_ext_batch_no in number,
                                p_tran_no      in number,
                                p_amount_paid  in number,
                                p_state        in out number,
                                p_errmsg       in out varchar2) as
        l_errfound exception;
        l_errline     number;
        l_seq_no      number(3);
        l_amount_paid number(15, 2);

        /*
          0 'VAT-SALES'     Vatable Sales
          x 'NON-VAT-SALES' Vat-Exempt Sales
          0 'VAT-0-RATED'   VAT Zero-rated Sales
          x 'UC-FIT_ALL'    UC/Fit-All
          x 'AR-VAT'        VAT
          - BIR 2306
          - BIR 2307
        */
    begin
        l_amount_paid := nvl(p_amount_paid, 0);

        l_errline := 10;
        select nvl(max(seq_no), 0)
        into   l_seq_no
        from   ext_paid_items
        where  ext_batch_no = p_ext_batch_no
        and    tran_no = p_tran_no;

        for l_cur in (select ext_batch_no,
                             tran_no,
                             seq_no,
                             acct_no,
                             bill_no,
                             ar_balance,
                             org_bill_amount
                      from   ext_paid_ar_details
                      where  ext_batch_no = p_ext_batch_no
                      and    tran_no = p_tran_no
                      order  by bill_date)
        loop

            declare
                l_uc             number(15, 2);
                l_fit_all        number(15, 2);
                l_vat            number(15, 2);
                l_vatable_sales  number(15, 2);
                l_non_vat_sales  number(15, 2);
                l_vat_zero_rated number(15, 2);
                l_apply_amount   number(15, 2);
            begin

                if l_amount_paid <= 0
                then
                    exit;
                end if;

                --initializing
                l_uc := 0;
                l_fit_all := 0;
                l_vat := 0;
                l_vatable_sales := 0;
                l_non_vat_sales := 0;
                l_vat_zero_rated := 0;

                if (l_amount_paid >= l_cur.ar_balance)
                then
                    l_apply_amount := l_cur.ar_balance;

                elsif (l_amount_paid < l_cur.ar_balance)
                then
                    l_apply_amount := l_amount_paid;
                end if;

                l_amount_paid := l_amount_paid - l_apply_amount;

                --inserting vatable sales
                l_errline := 10;
                l_seq_no := l_seq_no + 1;
                insert into ext_paid_items
                    (ext_batch_no,
                     tran_no,
                     seq_no,
                     pay_code,
                     amount_credit,
                     bill_no)
                values
                    (l_cur.ext_batch_no,
                     l_cur.tran_no,
                     l_seq_no,
                     'VAT-SALES',
                     l_vatable_sales,
                     l_cur.bill_no);

                --inserting vat-zero rated
                l_errline := 20;
                l_seq_no := l_seq_no + 1;
                insert into ext_paid_items
                    (ext_batch_no,
                     tran_no,
                     seq_no,
                     pay_code,
                     amount_credit,
                     bill_no)
                values
                    (l_cur.ext_batch_no,
                     l_cur.tran_no,
                     l_seq_no,
                     'VAT-0-RATED',
                     l_vat_zero_rated,
                     l_cur.bill_no);

                --inserting uc and fit-all
                l_errline := 40;
                l_uc := get_uc(l_cur.bill_no);
                l_uc := (l_uc / l_cur.org_bill_amount) * l_apply_amount;
                l_fit_all := get_fit_all(l_cur.bill_no);
                l_fit_all := (l_fit_all / l_cur.org_bill_amount) *
                             l_apply_amount;

                l_seq_no := l_seq_no + 1;
                insert into ext_paid_items
                    (ext_batch_no,
                     tran_no,
                     seq_no,
                     pay_code,
                     amount_credit,
                     bill_no)
                values
                    (l_cur.ext_batch_no,
                     l_cur.tran_no,
                     l_seq_no,
                     'UC-FIT_ALL',
                     l_uc + l_fit_all,
                     l_cur.bill_no);

                -- inserting vat
                l_errline := 50;
                l_vat := get_vat(l_cur.bill_no);
                l_vat := (l_vat / l_cur.org_bill_amount) * l_apply_amount;

                l_seq_no := l_seq_no + 1;
                insert into ext_paid_items
                    (ext_batch_no,
                     tran_no,
                     seq_no,
                     pay_code,
                     amount_credit,
                     bill_no)
                values
                    (l_cur.ext_batch_no,
                     l_cur.tran_no,
                     l_seq_no,
                     'AR-VAT',
                     l_vat,
                     l_cur.bill_no);

                -- inserting vatable sales
                l_errline := 60;
                l_non_vat_sales := l_apply_amount -
                                   (l_non_vat_sales + l_vat_zero_rated + /*l_uc + l_fit_all +*/ l_vat);

                l_seq_no := l_seq_no + 1;
                insert into ext_paid_items
                    (ext_batch_no,
                     tran_no,
                     seq_no,
                     pay_code,
                     amount_credit,
                     bill_no)
                values
                    (l_cur.ext_batch_no,
                     l_cur.tran_no,
                     l_seq_no,
                     'NON-VAT-SALES', --VAT-EXEMPT
                     l_non_vat_sales,
                     l_cur.bill_no);
            end;
        end loop;

        --inserting advance
        if nvl(l_amount_paid, 0) > 0
        then
            if l_seq_no = 0
            then
                l_errline := 70;
                insert_for_adv_lines(p_ext_batch_no,
                                     p_tran_no,
                                     p_state,
                                     p_errmsg);
                if p_state < 0
                then
                    raise l_errfound;
                end if;

                select nvl(max(seq_no), 0)
                into   l_seq_no
                from   ext_paid_items
                where  ext_batch_no = p_ext_batch_no
                and    tran_no = p_tran_no;

            end if;
            l_errline := 80;
            l_seq_no := l_seq_no + 1;
            insert into ext_paid_items
                (ext_batch_no,
                 tran_no,
                 seq_no,
                 pay_code,
                 amount_credit,
                 bill_no)
            values
                (p_ext_batch_no,
                 p_tran_no,
                 l_seq_no,
                 'ADVANCE',
                 l_amount_paid,
                 null);
        end if;

        --inserting accts with zero paid items
        if nvl(l_amount_paid, 0) = 0
        then
            if l_seq_no = 0
            then
                l_errline := 90;
                insert_zero_paid_items(p_ext_batch_no,
                                     p_tran_no,
                                     p_state,
                                     p_errmsg);
                if p_state < 0
                then
                    raise l_errfound;
                end if;

                /*select nvl(max(seq_no), 0)
                into   l_seq_no
                from   ext_paid_items
                where  ext_batch_no = p_ext_batch_no
                and    tran_no = p_tran_no;*/

            end if;
          end if;


        p_state := 0;
    exception
        when l_errfound then
            log_error(user, p_errmsg);
            p_state := -2;

        when others then
            p_errmsg := 'Error found @insert_vat_exempt line : ' ||
                        to_char(l_errline) || ' ' || sqlerrm;
            log_error(user, p_errmsg);
            p_state := -1;
    end insert_vat_exempt;


     procedure insert_vatable(p_ext_batch_no in number,
                             p_tran_no      in number,
                             p_amount_paid  in number,
                             p_state        in out number,
                             p_errmsg       in out varchar2) as
        l_errfound exception;
        l_errline     number;
        l_seq_no      number(3);
        l_amount_paid number(15, 2);

        /*
          x 'VAT-SALES'     Vatable Sales
          0 'NON-VAT-SALES' Vat-Exempt Sales
          0 'VAT-0-RATED'   VAT Zero-rated Sales
          x 'UC-FIT_ALL'    UC/Fit-All
          x 'AR-VAT'        VAT
          - BIR 2306
          - BIR 2307
        */

    begin
        l_amount_paid := nvl(p_amount_paid, 0);

        l_errline := 10;
        select nvl(max(seq_no), 0)
        into   l_seq_no
        from   ext_paid_items
        where  ext_batch_no = p_ext_batch_no
        and    tran_no = p_tran_no;

        for l_cur in (select ext_batch_no,
                             tran_no,
                             seq_no,
                             acct_no,
                             bill_no,
                             ar_balance,
                             org_bill_amount
                      from   ext_paid_ar_details
                      where  ext_batch_no = p_ext_batch_no
                      and    tran_no = p_tran_no
                      order  by bill_date)
        loop

            declare
                l_uc             number(15, 2);
                l_fit_all        number(15, 2);
                l_vat            number(15, 2);
                l_vatable_sales  number(15, 2);
                l_non_vat_sales  number(15, 2);
                l_vat_zero_rated number(15, 2);
                l_apply_amount   number(15, 2);
            begin

                if l_amount_paid <= 0
                then
                    exit;
                end if;

                --initializing
                l_uc := 0;
                l_fit_all := 0;
                l_vat := 0;
                l_vatable_sales := 0;
                l_non_vat_sales := 0;
                l_vat_zero_rated := 0;

                if (l_amount_paid >= l_cur.ar_balance)
                then
                    l_apply_amount := l_cur.ar_balance;

                elsif (l_amount_paid < l_cur.ar_balance)
                then
                    l_apply_amount := l_amount_paid;
                end if;

                l_amount_paid := l_amount_paid - l_apply_amount;

                --inserting non-vat sales
                l_non_vat_sales := get_non_vat(l_cur.bill_no);
                l_non_vat_sales := (l_non_vat_sales / l_cur.org_bill_amount) *
                                   l_apply_amount;
                l_errline := 10;
                l_seq_no := l_seq_no + 1;
                insert into ext_paid_items
                    (ext_batch_no,
                     tran_no,
                     seq_no,
                     pay_code,
                     amount_credit,
                     bill_no)
                values
                    (l_cur.ext_batch_no,
                     l_cur.tran_no,
                     l_seq_no,
                     'NON-VAT-SALES', --'VAT-EXEMPT',
                     l_non_vat_sales,
                     l_cur.bill_no);

                --inserting vat-zero rated
                l_errline := 20;
                l_seq_no := l_seq_no + 1;
                insert into ext_paid_items
                    (ext_batch_no,
                     tran_no,
                     seq_no,
                     pay_code,
                     amount_credit,
                     bill_no)
                values
                    (l_cur.ext_batch_no,
                     l_cur.tran_no,
                     l_seq_no,
                     'VAT-0-RATED',
                     l_vat_zero_rated,
                     l_cur.bill_no);

                --inserting uc and fit-all
                l_errline := 40;
                l_uc := get_uc(l_cur.bill_no);
                l_uc := (l_uc / l_cur.org_bill_amount) * l_apply_amount;

                l_fit_all := get_fit_all(l_cur.bill_no);
                l_fit_all := (l_fit_all / l_cur.org_bill_amount) *
                             l_apply_amount;
                l_seq_no := l_seq_no + 1;
                insert into ext_paid_items
                    (ext_batch_no,
                     tran_no,
                     seq_no,
                     pay_code,
                     amount_credit,
                     bill_no)
                values
                    (l_cur.ext_batch_no,
                     l_cur.tran_no,
                     l_seq_no,
                     'UC-FIT_ALL',
                     l_uc + l_fit_all,
                     l_cur.bill_no);

                -- inserting vat
                l_errline := 50;
                l_vat := get_vat(l_cur.bill_no);
                l_vat := (l_vat / l_cur.org_bill_amount) * l_apply_amount;
                l_seq_no := l_seq_no + 1;
                insert into ext_paid_items
                    (ext_batch_no,
                     tran_no,
                     seq_no,
                     pay_code,
                     amount_credit,
                     bill_no)
                values
                    (l_cur.ext_batch_no,
                     l_cur.tran_no,
                     l_seq_no,
                     'AR-VAT',
                     l_vat,
                     l_cur.bill_no);

                -- inserting vatable sales

                l_errline := 60;
                l_seq_no := l_seq_no + 1;
                l_vatable_sales := l_apply_amount -
                                   (l_non_vat_sales + l_vat_zero_rated + /*l_uc + l_fit_all +*/ l_vat);
                insert into ext_paid_items
                    (ext_batch_no,
                     tran_no,
                     seq_no,
                     pay_code,
                     amount_credit,
                     bill_no)
                values
                    (l_cur.ext_batch_no,
                     l_cur.tran_no,
                     l_seq_no,
                     'VAT-SALES',
                     l_vatable_sales,
                     l_cur.bill_no);
            end;
        end loop;

        --inserting advance
        if nvl(l_amount_paid, 0) > 0
        then
            if l_seq_no = 0
            then
                l_errline := 70;
                insert_for_adv_lines(p_ext_batch_no,
                                     p_tran_no,
                                     p_state,
                                     p_errmsg);
                if p_state < 0
                then
                    raise l_errfound;
                end if;

                select nvl(max(seq_no), 0)
                into   l_seq_no
                from   ext_paid_items
                where  ext_batch_no = p_ext_batch_no
                and    tran_no = p_tran_no;

            end if;
            l_errline := 80;
            l_seq_no := l_seq_no + 1;
            insert into ext_paid_items
                (ext_batch_no,
                 tran_no,
                 seq_no,
                 pay_code,
                 amount_credit,
                 bill_no)
            values
                (p_ext_batch_no,
                 p_tran_no,
                 l_seq_no,
                 'ADVANCE',
                 l_amount_paid,
                 null);
        end if;

        --inserting accts with zero paid items
        if nvl(l_amount_paid, 0) = 0
        then
            if l_seq_no = 0
            then
                l_errline := 90;
                insert_zero_paid_items(p_ext_batch_no,
                                     p_tran_no,
                                     p_state,
                                     p_errmsg);
                if p_state < 0
                then
                    raise l_errfound;
                end if;

                /*select nvl(max(seq_no), 0)
                into   l_seq_no
                from   ext_paid_items
                where  ext_batch_no = p_ext_batch_no
                and    tran_no = p_tran_no;*/

            end if;
          end if;

        p_state := 0;

    exception
        when l_errfound then
            log_error(user, p_errmsg);
            p_state := -2;
        when others then
            p_errmsg := 'Error found @insert_vatable line : ' ||
                        to_char(l_errline) || ' ' || sqlerrm;
            log_error(user, p_errmsg);
            p_state := -1;
    end insert_vatable;


    procedure insert_vat_zero_rated(p_ext_batch_no in number,
                                    p_tran_no      in number,
                                    p_amount_paid  in number,
                                    p_state        in out number,
                                    p_errmsg       in out varchar2) as
        l_errfound exception;
        l_errline     number;
        l_seq_no      number(3);
        l_amount_paid number(15, 2);

        /*
          0 'VAT-SALES'     Vatable Sales
          0 'NON-VAT-SALES' Vat-Exempt Sales
          x 'VAT-0-RATED'   VAT Zero-rated Sales
          x 'UC-FIT_ALL'    UC/Fit-All
          x 'AR-VAT'        VAT
          - BIR 2306
          - BIR 2307
        */

    begin
        l_amount_paid := nvl(p_amount_paid, 0);
        l_errline := 10;

        select nvl(max(seq_no), 0)
        into   l_seq_no
        from   ext_paid_items
        where  ext_batch_no = p_ext_batch_no
        and    tran_no = p_tran_no;

        for l_cur in (select ext_batch_no,
                             tran_no,
                             seq_no,
                             acct_no,
                             bill_no,
                             ar_balance,
                             org_bill_amount
                      from   ext_paid_ar_details
                      where  ext_batch_no = p_ext_batch_no
                      and    tran_no = p_tran_no
                      order  by bill_date)
        loop
            declare
                l_uc             number(15, 2);
                l_fit_all        number(15, 2);
                l_vat            number(15, 2);
                l_vatable_sales  number(15, 2);
                l_non_vat_sales  number(15, 2);
                l_vat_zero_rated number(15, 2);
                l_apply_amount   number(15, 2);
            begin

                if l_amount_paid <= 0
                then
                    exit;
                end if;

                --initializing
                l_uc := 0;
                l_fit_all := 0;
                l_vat := 0;
                l_vatable_sales := 0;
                l_non_vat_sales := 0;
                l_vat_zero_rated := 0;

                if (l_amount_paid >= l_cur.ar_balance)
                then
                    l_apply_amount := l_cur.ar_balance;

                elsif (l_amount_paid < l_cur.ar_balance)
                then
                    l_apply_amount := l_amount_paid;
                end if;

                l_amount_paid := l_amount_paid - l_apply_amount;

                --inserting vat-exempt sales
                l_errline := 10;
                l_seq_no := l_seq_no + 1;
                insert into ext_paid_items
                    (ext_batch_no,
                     tran_no,
                     seq_no,
                     pay_code,
                     amount_credit,
                     bill_no)
                values
                    (l_cur.ext_batch_no,
                     l_cur.tran_no,
                     l_seq_no,
                     'NON-VAT-SALES', --'VAT-EXEMPT',
                     l_non_vat_sales,
                     l_cur.bill_no);

                --inserting vat-zero rated
                l_errline := 20;
                l_seq_no := l_seq_no + 1;
                insert into ext_paid_items
                    (ext_batch_no,
                     tran_no,
                     seq_no,
                     pay_code,
                     amount_credit,
                     bill_no)
                values
                    (l_cur.ext_batch_no,
                     l_cur.tran_no,
                     l_seq_no,
                     'VAT-SALES',
                     l_vatable_sales,
                     l_cur.bill_no);

                --inserting uc and fit-all
                l_errline := 40;
                l_uc := get_uc(l_cur.bill_no);
                l_uc := (l_uc / l_cur.org_bill_amount) * l_apply_amount;

                l_fit_all := get_fit_all(l_cur.bill_no);
                l_fit_all := (l_fit_all / l_cur.org_bill_amount) *
                             l_apply_amount;
                l_seq_no := l_seq_no + 1;
                insert into ext_paid_items
                    (ext_batch_no,
                     tran_no,
                     seq_no,
                     pay_code,
                     amount_credit,
                     bill_no)
                values
                    (l_cur.ext_batch_no,
                     l_cur.tran_no,
                     l_seq_no,
                     'UC-FIT_ALL',
                     l_uc + l_fit_all,
                     l_cur.bill_no);

                -- inserting vat
                l_errline := 50;
                l_vat := get_vat(l_cur.bill_no);
                l_vat := (l_vat / l_cur.org_bill_amount) * l_apply_amount;
                l_seq_no := l_seq_no + 1;
                insert into ext_paid_items
                    (ext_batch_no,
                     tran_no,
                     seq_no,
                     pay_code,
                     amount_credit,
                     bill_no)
                values
                    (l_cur.ext_batch_no,
                     l_cur.tran_no,
                     l_seq_no,
                     'AR-VAT',
                     l_vat,
                     l_cur.bill_no);

                -- inserting vatable sales
                l_errline := 60;
                l_seq_no := l_seq_no + 1;
                l_vat_zero_rated := l_apply_amount -
                                    (l_non_vat_sales + l_vat_zero_rated + /*l_uc + l_fit_all +*/ l_vat);
                insert into ext_paid_items
                    (ext_batch_no,
                     tran_no,
                     seq_no,
                     pay_code,
                     amount_credit,
                     bill_no)
                values
                    (l_cur.ext_batch_no,
                     l_cur.tran_no,
                     l_seq_no,
                     'VAT-0-RATED',
                     l_vat_zero_rated,
                     l_cur.bill_no);
            end;
        end loop;

        --inserting advance
        if nvl(l_amount_paid, 0) > 0
        then
            if l_seq_no = 0
            then
                l_errline := 70;
                insert_for_adv_lines(p_ext_batch_no,
                                     p_tran_no,
                                     p_state,
                                     p_errmsg);
                if p_state < 0
                then
                    raise l_errfound;
                end if;

                select nvl(max(seq_no), 0)
                into   l_seq_no
                from   ext_paid_items
                where  ext_batch_no = p_ext_batch_no
                and    tran_no = p_tran_no;

            end if;
            l_errline := 80;
            l_seq_no := l_seq_no + 1;
            insert into ext_paid_items
                (ext_batch_no,
                 tran_no,
                 seq_no,
                 pay_code,
                 amount_credit,
                 bill_no)
            values
                (p_ext_batch_no,
                 p_tran_no,
                 l_seq_no,
                 'ADVANCE',
                 l_amount_paid,
                 null);
        end if;

        --inserting accts with zero paid items
        if nvl(l_amount_paid, 0) = 0
        then
            if l_seq_no = 0
            then
                l_errline := 90;
                insert_zero_paid_items(p_ext_batch_no,
                                     p_tran_no,
                                     p_state,
                                     p_errmsg);
                if p_state < 0
                then
                    raise l_errfound;
                end if;

                /*select nvl(max(seq_no), 0)
                into   l_seq_no
                from   ext_paid_items
                where  ext_batch_no = p_ext_batch_no
                and    tran_no = p_tran_no;*/

            end if;
          end if;

        p_state := 0;
    exception
        when l_errfound then
            log_error(user, p_errmsg);
            p_state := -2;
        when others then
            p_errmsg := 'Error found @insert_vat_zero_rated line : ' ||
                        to_char(l_errline) || ' ' || sqlerrm;

            log_error(user, p_errmsg);
            p_state := -1;
    end insert_vat_zero_rated;



    procedure insert_ar_balance(p_ext_batch_no in number,
                                p_acct_id      in varchar2,
                                p_date         in date,
                                p_tran_no      in number,
                                p_amount_paid  in number,
                                p_state        in out number,
                                p_errmsg       in out varchar2) is
        l_errline number;

        cursor ar_main_cur is
            select a.acct_id, sum(cur_amt) ar_balance
            from   ci_acct a, ci_ft ft, ci_sa sa, ci_sa_type sat
            where  a.acct_id = sa.acct_id
            and    sa.sa_id = ft.sa_id
            and    sat.sa_type_cd = sa.sa_type_cd
            and    a.acct_id = p_acct_id
            and    ((sat.svc_type_cd = 'EL') or
                  (sat.sa_type_cd = 'M-OVRPAY'))
            and    ft.ars_dt is not null
            and    ft.freeze_dttm is not null
            and    ft.freeze_dttm < p_date
            group  by a.acct_id
            having sum(cur_amt) <> 0;

        l_ar1 ar_main_cur%rowtype;

        cursor acct_bills_cur(p_acct_id in varchar2) is
            select to_number(b.bill_id) tran_no,
                   b.acct_id acct_no,
                   max(trunc(bs.end_dt, 'MM')) bill_month,
                   b.bill_id,
                   b.bill_dt,
                   b.due_dt due_dt,
                   sum(ft.cur_amt) bill_amt
            from   ci_bill b,
                   ci_ft ft,
                   ci_bseg bs,
                   ci_sa sa,
                   ci_sa_type sat
            where  bs.bill_id = b.bill_id
            and    ft.sa_id = sa.sa_id
            and    ft.sa_id = bs.sa_id
            and    sa.sa_type_cd = sat.sa_type_cd
            and    (bs.bseg_id = ft.sibling_id or
                  (ft.bill_id = b.bill_id and ft.ft_type_flg = 'AD'))
            and    b.complete_dttm <= p_date
            and    b.acct_id = p_acct_id
            and    sat.svc_type_cd = 'EL'
            and    ft.freeze_dttm is not null
            and    ft.freeze_dttm <= p_date
            and    bs.bseg_stat_flg in ('40', '50', '70')
            group  by b.bill_id, b.acct_id, b.bill_dt, b.due_dt
            order  by b.bill_dt desc, bill_month desc;

        type bill_tab_type is table of acct_bills_cur%rowtype index by binary_integer;

        l_bill         bill_tab_type;
        l_rn2          pls_integer; -- bills row pointer
        l_ar_tran_no   number;
        l_bill_balance number;

        l_arrears_balance number;
        l_bill_count      number;
        -- percent of total arrears needed to be paid for severance cancellation
        c_sev_ars_percent constant number := 0.95;

        l_in_ar  varchar2(10);
        l_seq_no number(3);
    begin
        l_seq_no := 0;

        l_errline := 30;
        delete from ext_paid_ar_details
        where  ext_batch_no = p_ext_batch_no
        and    tran_no = p_tran_no;

        l_in_ar := null;

        if l_in_ar is null
        then
            open ar_main_cur;

            fetch ar_main_cur
                into l_ar1;

            if ar_main_cur%found
            then
                -- if account has unpaid debts, traverse through bills
                if l_ar1.ar_balance > 0
                then
                    l_arrears_balance := 0;
                    l_bill_count := 0;

                    open acct_bills_cur(l_ar1.acct_id);

                    loop
                        fetch acct_bills_cur bulk collect
                            into l_bill limit 6;
                        l_rn2 := l_bill.first;

                        while (l_rn2 is not null and l_ar1.ar_balance > 0)
                        loop
                            if l_bill(l_rn2).bill_amt > 0
                            then
                                l_ar_tran_no := to_number(l_bill(l_rn2).bill_id);

                                if l_ar1.ar_balance > l_bill(l_rn2).bill_amt
                                then
                                    l_bill_balance := l_bill(l_rn2).bill_amt;
                                else
                                    l_bill_balance := l_ar1.ar_balance;
                                end if;

                                l_ar1.ar_balance := l_ar1.ar_balance -
                                                    l_bill_balance;

                                l_bill_count := l_bill_count + 1;

                                if l_bill_count > 1
                                then
                                    l_arrears_balance := l_arrears_balance +
                                                         l_bill_balance;
                                end if;

                                l_seq_no := l_seq_no + 1;

                                begin
                                    l_errline := 60;
                                    insert into ext_paid_ar_details
                                        (ext_batch_no,
                                         tran_no,
                                         seq_no,
                                         acct_no,
                                         bill_month,
                                         bill_no,
                                         bill_date,
                                         due_date,
                                         ar_balance,
                                         org_bill_amount)
                                    values
                                        (p_ext_batch_no,
                                         p_tran_no,
                                         l_seq_no,
                                         l_ar1.acct_id,
                                         l_bill(l_rn2).bill_month,
                                         l_bill(l_rn2).bill_id,
                                         l_bill(l_rn2).bill_dt,
                                         l_bill(l_rn2).due_dt,
                                         l_bill_balance,
                                         l_bill(l_rn2).bill_amt);
                                exception
                                    when others then
                                        log_error(user,
                                                  'Error Found @insert_ar_balance line: ' ||
                                                  l_errline || ' acct_no: ' ||
                                                  l_ar1.acct_id || ' ' ||
                                                  sqlerrm);
                                end;
                            end if;
                            l_rn2 := l_bill.next(l_rn2);
                        end loop;
                        exit when acct_bills_cur%notfound;
                    end loop;

                    close acct_bills_cur;
                end if;
            end if;
            close ar_main_cur;
        end if;

        p_state := 0;
    exception
        when others then
            p_errmsg := 'Error found @insert_ar_balance ' ||
                        to_char(l_errline) || ' ' || sqlerrm;
            log_error(user, p_errmsg);
            p_state := -1;
            rollback;
    end insert_ar_balance;


    procedure insert_ar_credits(p_ext_batch_no in number,
                                p_tran_no      in number,
                                p_state        in out number,
                                p_errmsg       in out varchar2) as
        l_seq_no  number(3);
        l_errline number;
    begin
        l_seq_no := 0;
        l_errline := 10;
        for l_cur in (select p_ext_batch_no ext_batch_no,
                             pi.tran_no,
                             pi.pay_code,
                             pi.amount_credit,
                             ar.bill_no
                      from   paid_items pi, paid_ar_details ar
                      where  pi.tran_no = ar.tran_no
                      and    pi.seq_no = ar.seq_no
                      and    pi.tran_no = p_tran_no
                      and    pi.amount_credit < 0)
        loop
            l_seq_no := l_seq_no + 1;

            l_errline := 20;
            insert into ext_paid_items
                (ext_batch_no,
                 tran_no,
                 seq_no,
                 pay_code,
                 amount_credit,
                 bill_no)
            values
                (l_cur.ext_batch_no,
                 l_cur.tran_no,
                 l_seq_no,
                 l_cur.pay_code,
                 l_cur.amount_credit,
                 l_cur.bill_no);
        end loop;
    exception
        when others then
            p_errmsg := 'Error found @insert_ar_credits line: ' ||
                        to_char(l_errline) || ' ' || sqlerrm;

            log_error(user, p_errmsg);
            p_state := -1;
    end insert_ar_credits;

    procedure insert_misc_details(p_ext_batch_no in number,
                                  p_tran_no      in number,
                                  p_state        in out number,
                                  p_errmsg       in out varchar2) as
        l_errline number;
    begin
        l_errline := 10;
        insert into ext_paid_items
            (ext_batch_no, tran_no, seq_no, pay_code, amount_credit)
            select p_ext_batch_no, tran_no, seq_no, pay_code, amount_credit
            from   paid_items
            where  tran_no = p_tran_no;

        p_state := 0;
    exception
        when others then
            p_errmsg := 'Error found @insert_misc_details line: ' ||
                        to_char(l_errline) || ' ' || sqlerrm;
            log_error(user, p_errmsg);
            p_state := -1;
            rollback;
    end insert_misc_details;


    function get_receipt_type(p_tran_no in number) return varchar2 as
        l_receipt_type varchar2(10);

    begin
        begin
            select 'OR'
            into   l_receipt_type
            from   payment_items paym, paid_items pi
            where  paym.pay_code = pi.pay_code
            and    pi.tran_no = p_tran_no
            and    ar = 1;
        exception
            when no_data_found then
                l_receipt_type := 'AR';
            when too_many_rows then
                l_receipt_type := 'OR';
        end;

        return l_receipt_type;

    end get_receipt_type;

    function get_bus_style(p_payer_id in varchar2) return varchar2 as
        l_bus_style varchar2(500);
    begin
        begin
            select max(trim(bus_activity_desc))
            into   l_bus_style
            from   ci_sa sa, ci_sa_type sat
            where  sa.sa_type_cd = sat.sa_type_cd
            and    sa.sa_status_flg = '20'
            and    sat.dst_id = 'A/R-ELEC  '
            and    sat.svc_type_cd = 'EL'
            and    sa.acct_id = p_payer_id;

            l_bus_style := substr(replace(l_bus_style, chr(10)), 1, 100);
        exception
            when no_data_found then
                l_bus_style := 'N/A';
        end;

        return l_bus_style;
    end get_bus_style;

    function get_revenue_tag(p_du_code  in varchar2,
                             p_payer_id in varchar2,
                             p_date     in date) return varchar2 as
        l_revenue_tag varchar2(20);
    begin
        l_revenue_tag := 'VATABLE';
        declare
            l_def_revenue varchar2(100);
        begin
            select att_value
            into   l_def_revenue
            from   du_code_att
            where  du_code = p_du_code
            and    att_code = 'DEFAULT_REVENUE_TAG';

            l_revenue_tag := l_def_revenue;
        exception
            when no_data_found then
                null;
        end;

        if p_du_code = 'VECO'
        then
            declare
                l_vattype    varchar2(100);
                l_revgrp varchar2(100);
                --l_orformat varchar2(100);
            begin
                /*select char_val
                into   l_vattype
                from   (select trim(char_val) char_val
                        from   ci_acct_char
                        where  acct_id = p_payer_id
                        and    char_type_cd = 'VATTYPE '
                        and    effdt <= trunc(p_date)
                        order  by effdt desc)
                where  rownum = 1;

                if l_vattype = 'VAT'
                then
                    l_revenue_tag := 'VATABLE';

                elsif l_vattype in ('NON-VAT', 'NONVAT')
                then
                    l_revenue_tag := 'VAT_ZERO_RATED';
                end if;*/

                select char_val
                  into l_vattype
                  from (select trim(char_val) char_val
                          from ci_acct_char
                         where acct_id = p_payer_id
                           and char_type_cd = 'VATTYPE '
                           and effdt <= trunc(p_date)
                         order by effdt desc)
                 where rownum = 1;

            select char_val
                  into l_revgrp
                  from (select trim(char_val) char_val
                          from ci_acct_char
                         where acct_id = p_payer_id
                           and char_type_cd = 'REVGRP  '
                           and effdt <= trunc(p_date)
                         order by effdt desc)
                 where rownum = 1;



            /*select char_val
                  into l_orformat
                  from (select trim(char_val) char_val
                          from ci_acct_char
                         where acct_id = p_payer_id
                           and char_type_cd = 'ORFORMAT'
                           and effdt <= trunc(p_date)
                         order by effdt desc)
                 where rownum = 1;*/

            if l_vattype = 'VAT' and l_revgrp = 'REG-RATED'
              then
                l_revenue_tag := 'VATABLE';

            elsif l_vattype in ('NON-VAT','NONVAT') and l_revgrp = 'ZERO-RATED'
              then
                l_revenue_tag := 'VAT_ZERO_RATED';


            elsif l_vattype in ('NON-VAT','NONVAT') and l_revgrp in ('VATEXEMPT','VAT-EXEMPT','VAT EXEMPT')
              then
                l_revenue_tag := 'VAT_EXEMPT';



            end if;

            exception
                when others then
                    l_revenue_tag := 'VATABLE';


            end;
        end if;

        return l_revenue_tag;
    end get_revenue_tag;

 procedure extract_ors(p_ext_batch_no in out number,
                          p_du_code      in varchar2,
                          p_date_from    in date,
                          p_date_to      in date,
                          p_receipt_type in varchar2,
                          p_rate_sched   in varchar2,
                          p_ors_batch_no in number,
                          p_acct_no      in varchar2,
                          p_or_no        in number,
                          p_state        in out number,
                          p_errmsg       in out varchar2) as
        l_errline      number;
        l_errmsg       varchar2(2000);
        l_ext_batch_no number;
        l_errfound exception;
    begin

        l_errline := 10;
        insert into or_extract_params
            (du_code,
             created_by,
             receipt_type,
             date_from,
             date_to,
             rate_sched,
             ors_batch_no,
             acct_no,
             or_no)
        values
            (p_du_code,
             nvl(v('app_user'), user),
             nvl(p_receipt_type, 'ALL'),
             p_date_from,
             p_date_to,
             p_rate_sched,
             p_ors_batch_no,
             p_acct_no,
             p_or_no)
        returning ext_batch_no into l_ext_batch_no;

        l_errline := 20;
        for l_cur in (select l_ext_batch_no ext_batch_no,
                             t.tran_no,
                             get_receipt_type(t.tran_no) receipt_type,
                             t.payer_id,
                             t.payer_type,
                             t.last_name,
                             t.first_name,
                             t.mid_name,
                             t.address,
                             b.site_code,
                             t.or_no,
                             t.or_date,
                             get_bus_style(t.payer_id) bus_style,
                             p.tin,
                             get_revenue_tag(p_du_code,
                                             t.payer_id,
                                             t.or_date) revenue_tag,
                             b.teller,
                             tt.collector_no,
                             t.or_count,
                             /*(select nvl(sum(amount_credit),0)
                              from paid_items
                             where tran_no = t.tran_no
                               and amount_credit > 0)*/
                             get_amount_paid(t.tran_no) amount_paid,
                             b.batch_no
                      from   payment_transactions t,
                             collection_batches b,
                             paid_acct_facts p,
                             tellers_tab tt
                      where  t.batch_no = b.batch_no
                      and    t.tran_no = p.tran_no
                      --and    b.created_by = tt.username
                      and    b.teller = tt.username
                      and    t.or_status in ('ISSUED', 'FOR CANCELLATION')
                      and    b.batch_no = nvl(p_ors_batch_no, b.batch_no)
                      and    t.payer_id = nvl(p_acct_no, t.payer_id)
                      and    t.or_no = nvl(p_or_no, t.or_no)
                      and    trunc(t.or_date) >= trunc(nvl(p_date_from,t.or_date))
                      and    trunc(t.or_date) <= trunc(nvl(p_date_to,t.or_date)))
                      --and    t.or_date >= trunc(p_date_from)
                      --and    t.or_date < trunc(p_date_to) + 1)
        loop

            if ((l_cur.receipt_type =
               nvl(p_receipt_type, l_cur.receipt_type)) or
               (p_receipt_type = 'ALL') or
               (p_receipt_type = l_cur.receipt_type))
            then
                begin
                    l_errline := 30;
                    insert into ext_payment_transactions
                        (ext_batch_no,
                         tran_no,
                         receipt_type,
                         payer_id,
                         payer_type,
                         last_name,
                         first_name,
                         mid_name,
                         address,
                         site_code,
                         or_no,
                         or_date,
                         bus_style,
                         tin,
                         revenue_tag,
                         teller,
                         collector_no,
                         or_count,
                         amount_paid,
                         batch_no)
                    values
                        (l_cur.ext_batch_no,
                         l_cur.tran_no,
                         l_cur.receipt_type,
                         l_cur.payer_id,
                         l_cur.payer_type,
                         l_cur.last_name,
                         l_cur.first_name,
                         l_cur.mid_name,
                         l_cur.address,
                         l_cur.site_code,
                         l_cur.or_no,
                         l_cur.or_date,
                         l_cur.bus_style,
                         l_cur.tin,
                         l_cur.revenue_tag,
                         l_cur.teller,
                         l_cur.collector_no,
                         l_cur.or_count,
                         l_cur.amount_paid,
                         l_cur.batch_no);

                end;

                l_errline := 35;
                --insert forms_of_payment;
                insert_fops(l_cur.ext_batch_no,
                            l_cur.tran_no,
                            p_state,
                            p_errmsg);
                if p_state < 0
                then
                    raise l_errfound;
                end if;

                if l_cur.receipt_type = 'OR'
                then

                    if get_source(p_du_code) = 'CS'
                    then
                        l_errline := 40;
                        insert_cs_data(l_cur.ext_batch_no,
                                       l_cur.tran_no,
                                       p_state,
                                       p_errmsg);
                        if p_state < 0
                        then
                            raise l_errfound;
                        end if;
                    else
                        l_errline := 50;
                        insert_ar_credits(l_cur.ext_batch_no,
                                          l_cur.tran_no,
                                          p_state,
                                          p_errmsg);
                        if p_state < 0
                        then
                            raise l_errfound;
                        end if;

                        l_errline := 60;
                        insert_ar_balance(l_cur.ext_batch_no,
                                          l_cur.payer_id,
                                          l_cur.or_date,
                                          l_cur.tran_no,
                                          l_cur.amount_paid,
                                          p_state,
                                          p_errmsg);
                        if p_state < 0
                        then
                            raise l_errfound;
                        end if;

                        declare
                            l_revenue_tag varchar2(20);
                        begin
                            l_errline := 70;
                            l_revenue_tag := l_cur.revenue_tag;

                            if l_revenue_tag = 'VAT_EXEMPT'
                            then
                                l_errline := 80;
                                insert_vat_exempt(l_cur.ext_batch_no,
                                                  l_cur.tran_no,
                                                  l_cur.amount_paid,
                                                  p_state,
                                                  p_errmsg);
                                if p_state < 0
                                then
                                    raise l_errfound;
                                end if;

                            elsif l_revenue_tag = 'VATABLE'
                            then
                                l_errline := 90;
                                insert_vatable(l_cur.ext_batch_no,
                                               l_cur.tran_no,
                                               l_cur.amount_paid,
                                               p_state,
                                               p_errmsg);
                                if p_state < 0
                                then
                                    raise l_errfound;
                                end if;

                            elsif l_revenue_tag = 'VAT_ZERO_RATED'
                            then
                                l_errline := 100;
                                insert_vat_zero_rated(l_cur.ext_batch_no,
                                                      l_cur.tran_no,
                                                      l_cur.amount_paid,
                                                      p_state,
                                                      p_errmsg);
                                if p_state < 0
                                then
                                    raise l_errfound;
                                end if;
                            end if;
                        end;
                    end if;

                elsif l_cur.receipt_type = 'AR'
                then
                    insert_misc_details(l_cur.ext_batch_no,
                                        l_cur.tran_no,
                                        p_state,
                                        p_errmsg);
                    if p_state < 0
                    then
                        raise l_errfound;
                    end if;
                end if;
            end if;

        end loop;

        p_ext_batch_no := l_ext_batch_no;

        commit;
        p_state := 0;

    exception
        when l_errfound then
            log_error(user, p_errmsg);
            p_state := -2;
            rollback;

        when others then
            p_errmsg := 'Error found @extract_ors line : ' || l_errline || ' ' ||
                        sqlerrm;
            log_error(user, p_errmsg);
            p_state := -1;
            rollback;

    end extract_ors;

end;
