-- Create table
create table USER_DU_CONTROLS
(
  username VARCHAR2(30) not null,
  du_code  VARCHAR2(10) not null
);
-- Create/Recreate primary, unique and foreign key constraints 
alter table USER_DU_CONTROLS
  add constraint DEFAULT_USER_DUS_PK primary key (USERNAME, DU_CODE);
-- Grant/Revoke object privileges 
grant select on USER_DU_CONTROLS to KATAMBAK_USER;
