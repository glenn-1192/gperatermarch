-- Create table
create table EXT_FOP_CHECKS
(
  ext_batch_no NUMBER not null,
  tran_no      NUMBER not null,
  seq_no       NUMBER(3) not null,
  bank_code    VARCHAR2(20),
  check_date   DATE,
  check_no     VARCHAR2(20),
  bank_branch  VARCHAR2(30),
  check_type   VARCHAR2(30),
  drop_box     NUMBER(1)
);
-- Create/Recreate primary, unique and foreign key constraints 
alter table EXT_FOP_CHECKS
  add constraint EXT_FOP_CHECKS_PK primary key (EXT_BATCH_NO, TRAN_NO, SEQ_NO);
alter table EXT_FOP_CHECKS
  add constraint EXT_FOP_CHECKS_FK foreign key (EXT_BATCH_NO, TRAN_NO, SEQ_NO)
  references EXT_FORMS_OF_PAYMENTS (EXT_BATCH_NO, TRAN_NO, SEQ_NO);
-- Grant/Revoke object privileges 
grant select on EXT_FOP_CHECKS to KATAMBAK_USER;
