update cs.pop_sites_tin
set tin = '000-566-230-00014'
where site_code = '10'
and   last_3_digit = '014';

commit;