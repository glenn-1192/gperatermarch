

insert into cs.du_codes (DU_CODE, DU_DESCRIPTION, STATUS)
values ('VECO', 'Visayan Electric Company', 'A');

commit;
