insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('VECO', 'DU_ADDRESS_014', 'LGF-03A One Pavilion Mall 22 R. Duterte Guadalupe Cebu City (Capital) Cebu Philippines 6000');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('VECO', 'DU_TWITTER', '@visayanelectric');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('VECO', 'DEFAULT_REVENUE_TAG', 'VATABLE');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('VECO', 'CAS_PERMIT_NO_EFFDT', '03-2015-123-0006');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('VECO', 'CAS_PERMIT_NO', '03-2015-123-0006-');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('VECO', 'CAS_PERMIT_NO_DESCR', 'BIR Permit to use no.:');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('VECO', 'CAS_PERMIT_NO_DESCR_OLD_0', 'CAS BIR Permit No.');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('VECO', 'CAS_PERMIT_NO_DESCR_OLD_1', 'Permit to use (PTU) No.');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('VECO', 'CAS_PERMIT_NO_OLD_0', 'AC_123_092022_000060');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('VECO', 'CAS_PERMIT_NO_SEPARATOR', '_PTU_CAS_');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('VECO', 'DATA_SOURCE', 'CCB');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('VECO', 'DATE_OF_ISSUANCE', '03/04/2015');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('VECO', 'DATE_OF_ISSUANCE_DESCR', 'Date of Issuance:');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('VECO', 'CAS_PERMIT_AC_DESCR', 'Acknowledgment Certificate No.:');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('VECO', 'SEQ_AC_DESCR', 'Series:');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('VECO', 'CAS_PERMIT_ON_OLD_0', 'On :');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('VECO', 'VERSION_RELEASE_1', 'This is BIR approved system generated report from Online Receipting System Version 2 Release 2');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('VECO', 'GENERATED_MSG_NEW', ' ');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('VECO', 'GET_OLD2_PERMIT_EFF_FROM', '01/01/2010');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('VECO', 'GET_OLD2_PERMIT_EFF_TO', '03/14/2015');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('VECO', 'DU_ADDRESS', 'VECO Engineering Office J. Panis Street, Banilad Cebu City (Capital) Cebu Philippines 6000');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('VECO', 'DU_BUS_STYLE', 'Visayan Electric Company Inc.');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('VECO', 'DU_EMAIL', 'info@visayanelectric.com');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('VECO', 'DU_FACEBOOK', 'visayanelectriccompany');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('VECO', 'DU_TEL_NO', '(032)-230-8326');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('VECO', 'DU_TIN', '000-566-230-00000');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('VECO', 'EFFECTIVE_DATE_DESCR', 'Effective Date:');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('VECO', 'EFFECTIVE_DATE_FROM', '08/01/2020');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('VECO', 'EFFECTIVE_DATE_TO', '07/31/2025');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('VECO', 'END_SEQ_0', '999999999');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('VECO', 'END_SEQ_1', '399999999');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('VECO', 'GENERATED_MSG', 'THIS IS A SYSTEM GENERATED OFFICIAL RECEIPT');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('VECO', 'GENERATED_MSG_AR', 'THIS DOCUMENT IS NOT VALID FOR CLAIM OF INPUT TAX');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('VECO', 'GENERATED_MSG_OR', 'THIS RECEIPT SHALL BE VALID FOR FIVE(5) YEARS FROM THE DATE OF PERMIT TO USE');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('VECO', 'GET_NEW_PERMIT_EFF', '09/22/2022');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('VECO', 'GET_OLD_PERMIT_EFF_FROM', '03/15/2015');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('VECO', 'GET_OLD_PERMIT_EFF_TO', '09/21/2022');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('VECO', 'OR_PREFFIX', '000');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('VECO', 'SEQ_DESCR', 'Series No.:');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('VECO', 'START_SEQ_0', '1');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('VECO', 'START_SEQ_1', '300000001');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('VECO', 'VERSION_RELEASE', 'This is a BIR approved system generated report from Online Receipting System Version 2 Release 2 No Signature is required.');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('VECO', 'DU_WEBSITE', 'www.visayanelectric.com');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('VECO', 'DU_FAX_NO', 'Fax.(082) 221-2105');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('VECO', 'DU_ADDRESS_012', 'J Centre Mall, A.S Fortuna St. Bakilid, Mandaue City Cebu Philippines 6014');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('VECO', 'DU_ADDRESS_003', 'Bulacao, City of Talisay, Cebu Philippines 6045');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('VECO', 'DU_ADDRESS_004', 'Bldg. C Piazza Elesia Coma Complex C.C Talamban Cebu City (Capital) Cebu Philippines 6000');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('VECO', 'DU_ADDRESS_013', '52 D. Jakosalem St. Cebu City (Capital) Cebu Philippines 6000');

insert into du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('VECO', 'CAS_PERMIT_032015_092022', 'CAS#:');

