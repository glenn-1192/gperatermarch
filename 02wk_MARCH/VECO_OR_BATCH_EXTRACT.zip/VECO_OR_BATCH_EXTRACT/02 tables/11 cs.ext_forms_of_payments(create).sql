-- Create table
create table EXT_FORMS_OF_PAYMENTS
(
  ext_batch_no NUMBER not null,
  tran_no      NUMBER not null,
  seq_no       NUMBER(3) not null,
  payment_type VARCHAR2(12),
  amount_paid  NUMBER(15,2)
);
-- Create/Recreate primary, unique and foreign key constraints 
alter table EXT_FORMS_OF_PAYMENTS
  add constraint EXT_FORMS_OF_PAYMENTS_PK primary key (EXT_BATCH_NO, TRAN_NO, SEQ_NO);
alter table EXT_FORMS_OF_PAYMENTS
  add constraint EXT_FORMS_OF_PAYMENTS_FK foreign key (EXT_BATCH_NO, TRAN_NO)
  references EXT_PAYMENT_TRANSACTIONS (EXT_BATCH_NO, TRAN_NO);
-- Grant/Revoke object privileges 
grant select on EXT_FORMS_OF_PAYMENTS to KATAMBAK_USER;
