create or replace package cs_or_ext_pkg AS

  function get_revenue_tag(p_du_code in varchar2, p_payer_id in varchar2, p_date in date) return varchar2;
  
  function get_amount_paid(p_tran_no in number) return number;

    function get_receipt_type(p_tran_no in number) return varchar2;

    function get_bus_style(p_payer_id in varchar2) return varchar2;

    procedure insert_ar_balance(p_ext_batch_no in number,
                                p_acct_id      in varchar2,
                                p_date         in date,
                                p_tran_no      in number,
                                p_amount_paid  in number,
                                p_state        in out number,
                                p_errmsg       in out varchar2);

    procedure extract_ors(p_ext_batch_no in out number,
                          p_du_code      in varchar2,
                          p_date_from    in date,
                          p_date_to      in date,
                          p_receipt_type in varchar2,
                          p_rate_sched   in varchar2,
                          p_ors_batch_no in number,
                          p_acct_no      in varchar2,
                          p_or_no        in number,
                          p_state        in out number,
                          p_errmsg       in out varchar2);

end;
