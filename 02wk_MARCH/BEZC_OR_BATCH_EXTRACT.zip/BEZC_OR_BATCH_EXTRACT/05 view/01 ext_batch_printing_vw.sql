create or replace view ext_batch_printing_vw as
select ext_batch_no,
       created_on,
       created_by,
       du_code,
       receipt_type,
       batch_no,
       --tran_no,
       --or_no,
       date_from,
       date_to,
       rate_sched,
       ors_batch_no,
       acct_no_params,
       or_no_params,
       tran_no,
       payer_id,
       payer_type,
       payer_address,
       site_code,
       to_char(or_no,'fm000000000') or_no,
       or_date,
       payer_bus_style,
       payer_tin,
       revenue_tag,
       teller,
       collector_no,
       or_count,
       amount_paid,
       payer_name,
       form_of_payment,
       site_info,
       cs_batch_or_print_pkg.get_cas_permit_info(p_du_code => du_code,
                                                 p_tag     => tag,
                                                 p_batch_no => batch_no,
                                                 p_tran_no => tran_no,
                                                 p_or_no => or_no,
                                                 p_ext_batch_no => ext_batch_no) cas_permit_info,
       cs_batch_or_print_pkg.get_cas_serial_no(p_receipt_type => receipt_type,
                                               p_du_code      => du_code,
                                               p_tag          => tag
                                               ) cas_serial_no,
       or_preffix,
       du_logo,
       du_address,
       du_tel_no,
       du_tin,
       du_email,
       du_bus_style,
       du_facebook,
       du_address_1,
       --du_website,
       --du_globe_no,
       --du_twitter,
       case
         when tag = 'NEW' and receipt_type = 'OR' then
           cs_batch_or_print_pkg.get_entry(p_du_code  => du_code,
                                             p_att_code => 'GENERATED_MSG_NEW')
         when tag = 'NEW' and receipt_type = 'AR' then
           cs_batch_or_print_pkg.get_entry(p_du_code  => du_code,
                                             p_att_code => 'GENERATED_MSG_AR')
         when tag = 'OLD_1' and receipt_type = 'OR' then
           cs_batch_or_print_pkg.get_entry(p_du_code  => du_code,
                                             p_att_code => 'GENERATED_MSG_NEW')
         when tag = 'OLD_0' and receipt_type = 'OR' then
           cs_batch_or_print_pkg.get_entry(p_du_code  => du_code,
                                             p_att_code => 'GENERATED_MSG')
         when tag = 'OLD_2' and receipt_type = 'OR' then
           cs_batch_or_print_pkg.get_entry(p_du_code  => du_code,
                                             p_att_code => 'GENERATED_MSG_OR')
         else
          cs_batch_or_print_pkg.get_entry(p_du_code  => du_code,
                                          p_att_code => 'GENERATED_MSG_NEW')

       end generated_msg,
       /*case
         when tag = 'NEW' then
          \*case
            when receipt_type = 'OR' then
             cs_batch_or_print_pkg.get_entry(p_du_code  => du_code,
                                             p_att_code => 'GENERATED_MSG_OR')*\
            case
            when receipt_type = 'AR' then
             cs_batch_or_print_pkg.get_entry(p_du_code  => du_code,
                                             p_att_code => 'GENERATED_MSG_AR')
          end
         else
          cs_batch_or_print_pkg.get_entry(p_du_code  => du_code,
                                          p_att_code => 'GENERATED_MSG')
       end generated_msg,*/
       case
         when tag = 'NEW' then
          version_release
         when tag in ('OLD_1','OLD_2')
           then
             version_release_1
         else
          null
       end version_release,
       tag
  from (select oep.ext_batch_no,
               oep.created_on,
               oep.created_by,
               oep.du_code,
               ept.receipt_type,
               ept.batch_no,
               --ept.tran_no,
               --ept.or_no,
               oep.date_from,
               oep.date_to,
               oep.rate_sched,
               oep.ors_batch_no,
               oep.acct_no acct_no_params,
               oep.or_no or_no_params,
               ept.tran_no,
               ept.payer_id,
               ept.payer_type,
               ept.address payer_address,
               ept.site_code,
               ept.or_no,
               ept.or_date,
               ept.bus_style payer_bus_style,
               ept.tin payer_tin,
               ept.revenue_tag,
               ept.teller,
               ept.collector_no,
               ept.or_count,
               ept.amount_paid,
               cs_batch_or_print_pkg.get_payer_name(p_last_name   => ept.last_name,
                                                    p_first_name  => ept.first_name,
                                                    p_middle_name => ept.mid_name) payer_name,
               cs_batch_or_print_pkg.get_forms_of_payment(p_ext_batch_no => ept.ext_batch_no,
                                                          p_tran_no      => ept.tran_no) form_of_payment,
               cs_batch_or_print_pkg.get_site_info(p_site_code    => ept.site_code,
                                                   p_collector_no => ept.collector_no,
                                                   p_or_count     => ept.or_count) site_info,
               cs_batch_or_print_pkg.get_du_prefix(p_du_code => oep.du_code,
                                                   p_batch_no => ept.batch_no,
                                                   p_tran_no => ept.tran_no) or_preffix,
               /*cs_batch_or_print_pkg.get_entry(p_du_code  => oep.du_code,
                                               p_att_code => 'OR_PREFFIX') or_preffix,*/
               (select cs_batch_or_print_pkg.blob2img(p_blob => dc.du_logo)
                  from du_codes dc
                 where dc.du_code = oep.du_code
                   and dc.status = 'A') du_logo,

               cs_batch_or_print_pkg.get_du_address(p_du_code =>  oep.du_code,
                                                    p_batch_no => ept.batch_no,
                                                    p_tran_no => ept.tran_no) du_address,
               cs_batch_or_print_pkg.get_entry(p_du_code  => oep.du_code,
                                               p_att_code => 'DU_ADDRESS_1') du_address_1,
               cs_batch_or_print_pkg.get_entry(p_du_code  => oep.du_code,
                                               p_att_code => 'DU_TEL_NO') du_tel_no,
               cs_batch_or_print_pkg.get_entry(p_du_code  => oep.du_code,
                                               p_att_code => 'DU_TIN') du_tin,
               /*cs_batch_or_print_pkg.get_du_tin(p_du_code => oep.du_code,
                                                p_batch_no => ept.batch_no) du_tin,*/
               cs_batch_or_print_pkg.get_entry(p_du_code  => oep.du_code,
                                               p_att_code => 'DU_EMAIL') du_email,
               cs_batch_or_print_pkg.get_entry(p_du_code  => oep.du_code,
                                               p_att_code => 'DU_BUS_STYLE') du_bus_style,
               cs_batch_or_print_pkg.get_entry(p_du_code  => oep.du_code,
                                               p_att_code => 'DU_FACEBOOK') du_facebook,
               /*cs_batch_or_print_pkg.get_entry(p_du_code  => oep.du_code,
                                               p_att_code => 'DU_WEBSITE') du_website,*/
               /*cs_batch_or_print_pkg.get_entry(p_du_code  => oep.du_code,
                                               p_att_code => 'DU_GLOBE_NO') du_globe_no,*/
               /*cs_batch_or_print_pkg.get_entry(p_du_code  => oep.du_code,
                                               p_att_code => 'DU_TWITTER') du_twitter,*/
               cs_batch_or_print_pkg.get_entry(p_du_code  => oep.du_code,
                                               p_att_code => 'VERSION_RELEASE') version_release,
               cs_batch_or_print_pkg.get_entry(p_du_code  => oep.du_code,
                                               p_att_code => 'VERSION_RELEASE_1') version_release_1,
               case
                 when ept.or_date >= to_date(cs_batch_or_print_pkg.get_entry(p_du_code  => oep.du_code,
                                                                             p_att_code => 'GET_NEW_PERMIT_EFF'),
                                             'MM/DD/YYYY') then
                  'NEW'
                 when (ept.or_date >= to_date(cs_batch_or_print_pkg.get_entry(p_du_code  => oep.du_code,
                                                                              p_att_code => 'GET_OLD_PERMIT_EFF_FROM'),
                                              'MM/DD/YYYY') and
                      ept.or_date <= to_date(cs_batch_or_print_pkg.get_entry(p_du_code  => oep.du_code,
                                                                              p_att_code => 'GET_OLD_PERMIT_EFF_TO'),
                                              'MM/DD/YYYY')) then
                  'OLD_1'
                 when (ept.or_date >= to_date(cs_batch_or_print_pkg.get_entry(p_du_code  => oep.du_code,
                                                                              p_att_code => 'GET_OLD2_PERMIT_EFF_FROM'),
                                              'MM/DD/YYYY') and
                      ept.or_date <= to_date(cs_batch_or_print_pkg.get_entry(p_du_code  => oep.du_code,
                                                                              p_att_code => 'GET_OLD2_PERMIT_EFF_TO'),
                                              'MM/DD/YYYY')) then
                  'OLD_2'
                 else
                  'OLD_0'
               end tag
          from or_extract_params oep, ext_payment_transactions ept
         where oep.ext_batch_no = ept.ext_batch_no
         order by ept.or_no)
;
