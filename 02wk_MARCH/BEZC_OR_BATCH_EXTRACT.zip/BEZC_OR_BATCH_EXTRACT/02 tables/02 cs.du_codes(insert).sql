

insert into cs.du_codes (DU_CODE, DU_DESCRIPTION, STATUS)
values ('BEZC', 'Balamban Enerzone Corporation', 'A');

commit;
