create or replace package body cs_batch_or_print_pkg as

/*
       version history
       1.0.2 by gperater Jan.30, 2024
             Purpose of Change : revised existing functions get_cas_permit_info and get_cas_serial_no
                               : get_cas_permit_info --> change the value of the substr(l_cas_permit_no) from 6,4 & 11,6 to 6,5 & 12,6 respectively
                               : get_cas_serial_no --> enabled the elsif condition receipt_type = 'OR' and p_tag = 'OLD_1' 
                                 this is to cater the requirements on the cas permit section for those ORs whose or_date is < 2022
                               : modify att_value of att_code CAS_PERMIT_NO_SEPARATOR from _PTU_CAS_ to _PTU_CAS removed the underscore after CAS
             Affected Objects  : get_cas_permit_info, get_cas_serial_no, du_code_att att_code CAS_PERMIT_NO_SEPARATOR
             Remarks           : revised existing functions
                               
       1.0.1 by gperater Jan.18, 2024
             Purpose of Change : added new function get_or_footer_info to cater the new cas permit footer requirements
                                 cas permit footer is based on the effectivity date each effectivity has its own designated cas footer
             Affected Objects  : ext_payment_transactions --> alter table new column batch_no
                               : get_or_footer_info --> new function added
                               : get_cas_permit_info --> inject the new function created and disabled the existing set up of cas permit footer
                               : get_cas_serial_no --> disabled the existing set up of getting the serial no as the serial no is 
                                                       already included in the new function get_or_footer_info
             Remarks           : revised existing functions and add new function to cater requirements of the new cas permit footer 
                               : altered ext_payment_transactions and ext_batch_printing_vw
       1.0.0 by gmepieza May 15, 2023
             Purpose of Change : revised existing function due to the new format in the cas permit info, removed existing effective date and 
                                 updated data in existing configuration in table based for cas_permit_no & version_release
             Affected Objects  : old, get_cas_permit_info
             Remarks           : revision of the existing function due to the new cas permit info format

*/

  function blob2img(p_blob in blob) return clob is
    l_clob clob;
    l_step pls_integer := 12000;
  begin
    for i in 0 .. trunc((dbms_lob.getlength(p_blob) - 1) / l_step) loop
      l_clob := l_clob ||
                utl_raw.cast_to_varchar2(utl_encode.base64_encode(dbms_lob.substr(p_blob,
                                                                                  l_step,
                                                                                  i *
                                                                                  l_step + 1)));
    end loop;
    return l_clob;
  end blob2img;
  
  function get_or_footer_info(p_du_code in varchar2, p_batch_no in number, p_tran_no in number, p_or_no in number, p_ext_batch_no in number)
    return varchar2 as
  
    l_or_footer varchar2(200);
  begin
    declare
       l_cas_permit_no varchar2(100);
       l_issued_on varchar2(50);
       l_receipt_prefix varchar2(2);
       l_last_digit varchar2(5);
       l_or_date date;
           
       l_or_start number;
       l_or_end   number;
       l_ar_start number;
       l_ar_end   number;
    begin 
      select  substr(tin.cas_permit_no,1,30) cas_permit_no,
                    to_char(tin.issued_on, 'MM/DD/YYYY'),
                    cs_or_pkg.get_receipt_prefix(p_tran_no),
                    tin.last_3_digit,
                    trunc(pt.or_date)
            into   l_cas_permit_no,
                   l_issued_on,
                   l_receipt_prefix,
                   l_last_digit,
                   l_or_date
            from
                    collection_batches batches,
                    pop_sites_tin      tin,
                    ext_payment_transactions pt,
                    or_extract_params oep
            where   batches.site_code = tin.site_code
            and     batches.batch_no = pt.batch_no
            and     oep.ext_batch_no = pt.ext_batch_no
            and     pt.or_no = p_or_no
            and     oep.ext_batch_no = p_ext_batch_no
            and     batches.batch_no = p_batch_no
            and     pt.tran_no = p_tran_no;        
            
            select or_series_start,
                   or_series_end,
                   ar_series_start,
                   ar_series_end
            into l_or_start,
                 l_or_end,
                 l_ar_start,
                 l_ar_end
            from   cas_permit_config
            where  cas_permit_no = l_cas_permit_no
            and    last_3_digit = l_last_digit;
            
        if l_or_date >= cs_batch_or_print_pkg.get_entry(p_du_code  => p_du_code,p_att_code => 'OR_DATE_AC') --to_date('09/27/2022','mm/dd/yyyy')
          then
        if l_receipt_prefix is null
            then
        l_or_footer := cs_batch_or_print_pkg.get_entry(p_du_code  => p_du_code,p_att_code => 'CAS_PERMIT_AC_DESCR')--'Acknowledgement Certificate No.:'
                        || l_cas_permit_no
                        || ' '
                        || cs_batch_or_print_pkg.get_entry(p_du_code  => p_du_code,p_att_code => 'DATE_OF_ISSUANCE_DESCR') --' Date of Issuance:'
                        || l_issued_on --to_char(tin.issued_on, 'MM/DD/YYYY')
                        || ' '
                        || cs_batch_or_print_pkg.get_entry(p_du_code  => p_du_code,p_att_code => 'SEQ_AC_DESCR') --'Series:'
                        --|| l_receipt_prefix --get_receipt_prefix(p_tran_no)
                        --|| ' ' --tin.last_3_digit
                        --|| '-'
                        || to_char(l_or_start, 'fm000000000')
                        || '-'
                        --|| l_receipt_prefix --get_receipt_prefix(p_tran_no)
                        --|| ' ' --tin.last_3_digit
                        --|| '-'
                        || l_or_end;
                    
        else l_receipt_prefix := 'N'; 
        l_or_footer := cs_batch_or_print_pkg.get_entry(p_du_code  => p_du_code,p_att_code => 'CAS_PERMIT_AC_DESCR') --'Acknowledgement Certificate No.:'
                        || l_cas_permit_no --tin.cas_permit_no
                        || ' '
                        || cs_batch_or_print_pkg.get_entry(p_du_code  => p_du_code,p_att_code => 'DATE_OF_ISSUANCE_DESCR') --' Date of Issuance:'
                        || l_issued_on --to_char(tin.issued_on, 'MM/DD/YYYY')
                        || ' '
                        || cs_batch_or_print_pkg.get_entry(p_du_code  => p_du_code,p_att_code => 'SEQ_AC_DESCR') --'Series:'
                        --|| l_receipt_prefix --get_receipt_prefix(p_tran_no)
                        --|| ' ' --tin.last_3_digit
                        --|| '-'
                        || to_char(l_ar_start, 'fm000000000')
                        || '-'
                        --|| l_receipt_prefix --get_receipt_prefix(p_tran_no)
                        --|| l_last_digit --tin.last_3_digit
                        --|| '-'
                        || l_ar_end;
                        
           
        end if;
    end if;
    
    if l_or_date <= cs_batch_or_print_pkg.get_entry(p_du_code  => p_du_code,p_att_code => 'OR_DATE_BIR') --to_date('09/26/2022','mm/dd/yyyy')
      then
       l_or_footer := cs_batch_or_print_pkg.get_entry(p_du_code  => p_du_code,p_att_code => 'CAS_PERMIT_NO_DESCR') --'BIR Permit to use no.:'
                   || substr(cs_batch_or_print_pkg.get_entry(p_du_code  => p_du_code,p_att_code => 'CAS_PERMIT_NO'),1,30) --'1812-01210-000410'
                   || ' '
                   || cs_batch_or_print_pkg.get_entry(p_du_code  => p_du_code,p_att_code => 'DATE_OF_ISSUANCE_DESCR') --'Date of Issuance:'
                   || cs_batch_or_print_pkg.get_entry(p_du_code  => p_du_code,p_att_code => 'DATE_OF_ISSUANCE') --to_date('01/01/2019','mm/dd/yyyy')
                   || ' '
                   || cs_batch_or_print_pkg.get_entry(p_du_code  => p_du_code,p_att_code => 'EFFECTIVE_DATE_DESCR') --'Effective Date'
                   || ' '
                   || cs_batch_or_print_pkg.get_entry(p_du_code  => p_du_code,p_att_code => 'EFFECTIVE_DATE_FROM')--'08/01/2020'
                   || '-'
                   || cs_batch_or_print_pkg.get_entry(p_du_code  => p_du_code,p_att_code => 'EFFECTIVE_DATE_TO')--'09/26/2022'
                   || ' '
                   || cs_batch_or_print_pkg.get_entry(p_du_code  => p_du_code,p_att_code => 'SEQ_DESCR') --'Series No.:' SEQ_DESCR
                   || cs_batch_or_print_pkg.get_entry(p_du_code  => p_du_code,p_att_code => 'START_SEQ_0')--'1000000001'
                   || '-'
                   || cs_batch_or_print_pkg.get_entry(p_du_code  => p_du_code,p_att_code => 'END_SEQ_0');--'1999999999';
    end if;
    
    exception
      when no_data_found then
        null;
    end;
  
    return l_or_footer;
  
  end get_or_footer_info;

  function get_site_info(p_site_code    in varchar2,
                         p_collector_no in number,
                         p_or_count     in number) return varchar2 as
    l_site_code varchar2(300);
  begin
    l_site_code := p_site_code;
    if p_collector_no is not null then
      if l_site_code is not null then
        l_site_code := l_site_code || '-';
      end if;
    
      l_site_code := l_site_code || p_collector_no;
    end if;
  
    if p_or_count is not null then
      if l_site_code is not null then
        l_site_code := l_site_code || '-';
      end if;
    
      l_site_code := l_site_code || p_or_count;
    end if;
  
    return l_site_code;
  end get_site_info;

  function get_total_change(p_ext_batch_no in number, p_tran_no in number)
    return number as
    l_total_cash number;
    l_change     number;
  begin
    l_total_cash := cs_batch_or_print_pkg.get_total_cash(p_ext_batch_no => p_ext_batch_no,
                                                         p_tran_no      => p_tran_no);
  
    select l_total_cash - nvl(sum(amount_paid), 0)
      into l_change
      from ext_forms_of_payments
     where ext_batch_no = p_ext_batch_no
       and tran_no = p_tran_no
       and payment_type = 'CASH';
  
    return nvl(l_change, 0);
  end get_total_change;

  function get_total_amount_received(p_ext_batch_no in number,
                                     p_tran_no      in number) return number as
    l_total_cash            number;
    l_total_amount_received number;
  begin
    l_total_cash := cs_batch_or_print_pkg.get_total_cash(p_ext_batch_no => p_ext_batch_no,
                                                         p_tran_no      => p_tran_no);
  
    select nvl(sum(amount_paid), 0) + l_total_cash
      into l_total_amount_received
      from ext_forms_of_payments
     where ext_batch_no = p_ext_batch_no
       and tran_no = p_tran_no
       and payment_type != 'CASH';
  
    return nvl(l_total_amount_received, 0);
  end get_total_amount_received;

  function get_total_cash(p_ext_batch_no in number, p_tran_no in number)
    return number as
    l_cash number;
  begin
    select nvl(sum(amount_tendered), 0)
      into l_cash
      from ext_fop_cash
     where ext_batch_no = p_ext_batch_no
       and tran_no = p_tran_no;
  
    return nvl(l_cash, 0);
  end get_total_cash;

  function get_cas_permit_info(p_du_code in varchar2, p_tag in varchar2, 
                             p_batch_no in number,
                             p_tran_no in number,
                             p_or_no in number,
                             p_ext_batch_no in number)
    return varchar2 as
    /*
       revision history
           1.0.1 by gperater on January 18, 2024
                 Remarks : inject new function get_or_footer_info and disabled the existing set up of the cas permit info
           1.0.0 by gmepieza May 15, 2023
                 Remarks : revised existing function due to the new format in cas permit info
    
    */
    l_cas_permit       varchar2(500);
    l_cas_permit_descr du_code_att.att_value%type;
    l_cas_permit_no    du_code_att.att_value%type;
    l_cas_permit_septr du_code_att.att_value%type;
    l_issuance_descr   du_code_att.att_value%type;
    l_issuance_date    du_code_att.att_value%type;
    l_eff_dt_descr     du_code_att.att_value%type;
    l_eff_dt_from      du_code_att.att_value%type;
    l_eff_dt_to        du_code_att.att_value%type;
  begin
    if p_tag = 'OLD_0' then
      l_cas_permit_descr := cs_batch_or_print_pkg.get_entry(p_du_code  => p_du_code,
                                                            p_att_code => 'CAS_PERMIT_NO_DESCR_OLD_0');
      l_cas_permit_no    := cs_batch_or_print_pkg.get_entry(p_du_code  => p_du_code,
                                                            p_att_code => 'CAS_PERMIT_NO_OLD_0');
      l_cas_permit       := l_cas_permit_descr || ' ' || l_cas_permit_no;
    elsif p_tag = 'OLD_1' then
      l_cas_permit_descr := cs_batch_or_print_pkg.get_entry(p_du_code  => p_du_code,
                                                            p_att_code => 'CAS_PERMIT_NO_DESCR_OLD_1');
      l_cas_permit_no    := cs_batch_or_print_pkg.get_entry(p_du_code  => p_du_code,
                                                            p_att_code => 'CAS_PERMIT_NO');
      l_cas_permit_septr := cs_batch_or_print_pkg.get_entry(p_du_code  => p_du_code,
                                                            p_att_code => 'CAS_PERMIT_NO_SEPARATOR');
      l_cas_permit       := l_cas_permit_descr || ' ' ||
                            substr(l_cas_permit_no, 1, 4) || '_' ||
                            substr(l_cas_permit_no, 6, 5) ||
                            l_cas_permit_septr ||
                            substr(l_cas_permit_no, 12, 6);
    elsif p_tag = 'NEW' then
      l_cas_permit  := cs_batch_or_print_pkg.get_or_footer_info(p_du_code => p_du_code,
                                                                p_batch_no => p_batch_no,
                                                                p_tran_no => p_tran_no,
                                                                p_or_no => p_or_no,
                                                                p_ext_batch_no => p_ext_batch_no);
      --existing source
      /*l_cas_permit_descr := cs_batch_or_print_pkg.get_entry(p_du_code  => p_du_code,
                                                            p_att_code => 'CAS_PERMIT_NO_DESCR');
      l_cas_permit_no    := cs_batch_or_print_pkg.get_entry(p_du_code  => p_du_code,
                                                            p_att_code => 'CAS_PERMIT_NO');
      l_issuance_descr   := cs_batch_or_print_pkg.get_entry(p_du_code  => p_du_code,
                                                            p_att_code => 'DATE_OF_ISSUANCE_DESCR');
      l_issuance_date    := cs_batch_or_print_pkg.get_entry(p_du_code  => p_du_code,
                                                            p_att_code => 'DATE_OF_ISSUANCE');
      l_eff_dt_descr     := cs_batch_or_print_pkg.get_entry(p_du_code  => p_du_code,
                                                            p_att_code => 'EFFECTIVE_DATE_DESCR');
      l_eff_dt_from      := cs_batch_or_print_pkg.get_entry(p_du_code  => p_du_code,
                                                            p_att_code => 'EFFECTIVE_DATE_FROM');
      l_eff_dt_to        := cs_batch_or_print_pkg.get_entry(p_du_code  => p_du_code,
                                                            p_att_code => 'EFFECTIVE_DATE_TO');
      l_cas_permit       := l_cas_permit_descr ||
                            substr(l_cas_permit_no, 1, 4) || '-' ||
                            substr(l_cas_permit_no, 6, 5) || '-' ||
                            substr(l_cas_permit_no, 12, 6) || ' ' ||
                            l_issuance_descr || l_issuance_date || ' ' ||
                            l_eff_dt_descr || l_eff_dt_from || '-' ||
                            l_eff_dt_to;*/
      --existing source
                          
      --CR : SEZC OR BATCH EXTRACT 05/15/2023                
     /* l_cas_permit_descr := cs_batch_or_print_pkg.get_entry(p_du_code  => p_du_code,
                                                            p_att_code => 'CAS_PERMIT_NO_DESCR');
      l_cas_permit_no    := cs_batch_or_print_pkg.get_entry(p_du_code  => p_du_code,
                                                            p_att_code => 'CAS_PERMIT_NO');
      l_issuance_descr   := cs_batch_or_print_pkg.get_entry(p_du_code  => p_du_code,
                                                            p_att_code => 'DATE_OF_ISSUANCE_DESCR');
      l_issuance_date    := cs_batch_or_print_pkg.get_entry(p_du_code  => p_du_code,
                                                            p_att_code => 'DATE_OF_ISSUANCE');
                                                            
                                                            
      l_cas_permit       := l_cas_permit_descr || l_cas_permit_no || ' ' ||
                            --substr(l_cas_permit_no, 1, 4) || '-' ||
                            --substr(l_cas_permit_no, 6, 5) || '-' ||
                            --substr(l_cas_permit_no, 12, 6) || ' ' ||
                            l_issuance_descr || l_issuance_date; 
                            --|| ' ' ||
                            --l_eff_dt_descr || l_eff_dt_from || '-' ||
                            --l_eff_dt_to; */
      --CR : SEZC OR BATCH EXTRACT 05/15/2023       
    end if;
  
    return l_cas_permit;
  end get_cas_permit_info;

  function get_cas_serial_no(p_receipt_type varchar2,
                             p_du_code      in varchar2,
                             p_tag          in varchar2
                             ) return varchar2 as
                             
    /*
    revision history
             v1.0.1 by gperater on January 18, 2024
                    remarks : disabled condition receipt_type = 'OR' this format will be catered and included to the new 
                              function get_or_footer_info
    
    */
    l_cas_series    varchar2(500);
    l_cas_seq_descr du_code_att.att_value%type;
    l_cas_start_seq du_code_att.att_value%type;
    l_cas_end_seq   du_code_att.att_value%type;
  begin
    if p_tag in ('NEW', 'OLD_1') then
      if p_receipt_type = 'AR' then
        -- acknowledgement receipt
        l_cas_seq_descr := cs_batch_or_print_pkg.get_entry(p_du_code  => p_du_code,
                                                           p_att_code => 'SEQ_DESCR');
        l_cas_start_seq := cs_batch_or_print_pkg.get_entry(p_du_code  => p_du_code,
                                                           p_att_code => 'START_SEQ_1');
        l_cas_end_seq   := cs_batch_or_print_pkg.get_entry(p_du_code  => p_du_code,
                                                           p_att_code => 'END_SEQ_1');
        l_cas_series    := l_cas_seq_descr || l_cas_start_seq || '-' ||
                           l_cas_end_seq;
      elsif p_receipt_type = 'OR' and p_tag = 'OLD_1' then
        -- official receipt
        l_cas_seq_descr := cs_batch_or_print_pkg.get_entry(p_du_code  => p_du_code,
                                                           p_att_code => 'SEQ_AC_DESCR');
        l_cas_start_seq := cs_batch_or_print_pkg.get_entry(p_du_code  => p_du_code,
                                                           p_att_code => 'START_SEQ_0');
        l_cas_end_seq   := cs_batch_or_print_pkg.get_entry(p_du_code  => p_du_code,
                                                           p_att_code => 'END_SEQ_0');
        l_cas_series    := l_cas_seq_descr || l_cas_start_seq || '-' ||
                           l_cas_end_seq;
      end if;
    end if;
  
    return l_cas_series;
  end get_cas_serial_no;

  function get_forms_of_payment(p_ext_batch_no in number,
                                p_tran_no      in number) return varchar2 as
    l_bank_code   varchar2(20);
    l_check_date  date;
    l_check_no    varchar2(20);
    l_check_amt   number;
    l_cash        varchar2(10);
    l_check       varchar2(200);
    l_cc          varchar2(100);
    l_fop         varchar2(300);
    l_iscash      boolean;
    l_ischeck     boolean;
    l_iscc        boolean;
    l_tran_type   varchar2(20);
    l_card_type   varchar2(60);
    l_amount_paid number;
  
    cursor cr_dr_payments is
      select cr_dr.tran_type, cr_dr.card_type, fop.amount_paid
        from ext_fop_cr_dr_cards cr_dr, ext_forms_of_payments fop
       where cr_dr.ext_batch_no = fop.ext_batch_no
         and cr_dr.tran_no = fop.tran_no
         and cr_dr.seq_no = fop.seq_no
         and cr_dr.ext_batch_no = p_ext_batch_no
         and cr_dr.tran_no = p_tran_no
       order by fop.seq_no;
  
    cursor check_payments is
      select checks.bank_code,
             checks.check_date,
             checks.check_no,
             fop.amount_paid
        from ext_forms_of_payments fop, ext_fop_checks checks
       where fop.ext_batch_no = checks.ext_batch_no
         and fop.tran_no = checks.tran_no
         and fop.seq_no = checks.seq_no
         and fop.ext_batch_no = p_ext_batch_no
         and fop.tran_no = p_tran_no
       order by fop.seq_no;
  begin
    open check_payments;
    fetch check_payments
      into l_bank_code, l_check_date, l_check_no, l_check_amt;
  
    if check_payments%found then
      l_ischeck := true;
      l_check   := l_bank_code || ' ' || replace(l_check_no, chr(10)) || ' P' ||
                   to_char(l_check_amt, 'fm999,999,999,990.00');
    else
      l_ischeck := false;
      l_check   := ' ';
    end if;
  
    open cr_dr_payments;
    fetch cr_dr_payments
      into l_tran_type, l_card_type, l_amount_paid;
  
    if cr_dr_payments%found then
      l_iscc := true;
      if l_tran_type = 'DEBIT CARD' then
        l_cc := 'DR ' || l_card_type;
      elsif l_tran_type = 'CREDIT CARD' then
        l_cc := 'CR ' || l_card_type;
      end if;
    else
      l_iscc := false;
      l_cc   := ' ';
    end if;
  
    begin
      select 'CASH'
        into l_cash
        from ext_forms_of_payments fop, ext_fop_cash cash
       where fop.ext_batch_no = cash.ext_batch_no
         and fop.tran_no = cash.tran_no
         and fop.seq_no = cash.seq_no
         and fop.ext_batch_no = p_ext_batch_no
         and fop.tran_no = p_tran_no;
    
      l_cash   := l_cash;
      l_iscash := true;
    exception
      when no_data_found then
        l_iscash := false;
        l_cash   := ' ';
    end;
  
    if l_iscash then
      l_fop := l_cash || '/';
    end if;
  
    if l_ischeck then
      l_fop := l_fop || l_check || '/';
    end if;
  
    if l_iscc then
      l_fop := l_fop || l_cc;
    end if;
  
    l_fop := rtrim(l_fop, '/');
    l_fop := substr(l_fop, 1, 40);
  
    return nvl(l_fop, 'CASH');
  end get_forms_of_payment;

  function get_payer_name(p_last_name   in varchar2,
                          p_first_name  in varchar2,
                          p_middle_name in varchar2) return varchar2 as
    l_name varchar2(300);
  begin
    l_name := p_last_name;
    if p_first_name is not null then
      if l_name is not null then
        l_name := l_name || ', ';
      end if;
    
      l_name := l_name || p_first_name;
    end if;
  
    if p_middle_name is not null then
      if l_name is not null then
        l_name := l_name || ' ';
      end if;
    
      l_name := l_name || p_middle_name;
    end if;
  
    return l_name;
  end get_payer_name;

  function get_entry(p_du_code in varchar2, p_att_code in varchar)
    return varchar2 as
  
    cursor du_reg is
      select dca.att_value
        from du_codes dc, du_code_att dca
       where dc.du_code = dca.du_code
         and dc.du_code = p_du_code
         and dca.att_code = p_att_code
         and dc.status = 'A';
  
    l_value du_code_att.att_value%type;
  begin
    open du_reg;
    fetch du_reg
      into l_value;
    close du_reg;
  
    return(l_value);
  end get_entry;

end cs_batch_or_print_pkg;
