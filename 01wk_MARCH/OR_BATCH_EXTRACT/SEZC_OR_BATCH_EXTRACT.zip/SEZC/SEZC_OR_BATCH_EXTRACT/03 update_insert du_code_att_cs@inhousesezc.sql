update cs.du_code_att
set att_value = ' '
where att_code = 'OR_PREFFIX';

update cs.du_code_att
set att_value = '1812-01210-000410'
where att_code = 'CAS_PERMIT_NO';

update cs.du_code_att
set att_value = to_date('09/26/2022','mm/dd/yyyy')
where att_code = 'EFFECTIVE_DATE_TO';

update cs.du_code_att
set att_value = 'This is BIR approved system generated report from Online Receipting System Version 2 Release 2'
where att_code = 'VERSION_RELEASE';

update cs.du_code_att
set att_value = '_PTU_CAS'
where att_code = 'CAS_PERMIT_NO_SEPARATOR';

update cs.du_code_att
set att_value = to_date('09/26/2022','mm/dd/yyyy')
where att_code = 'EFFECTIVE_DATE_TO';

update cs.du_code_att
set att_value = to_date('08/01/2020','mm/dd/yyyy')
where att_code = 'GET_NEW_PERMIT_EFF';

update cs.du_code_att
set att_value = to_date('07/31/2020','mm/dd/yyyy')
where att_code = 'GET_OLD_PERMIT_EFF_TO';


insert into cs.du_code_att
	(du_code,att_code,att_value) values ('SEZC','CAS_PERMIT_AC_DESCR','Acknowledgement Certificate No.:');

insert into cs.du_code_att
	(du_code,att_code,att_value) values ('SEZC','SEQ_AC_DESCR','Series:');

insert into cs.du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('SEZC', 'OR_DATE_AC', to_date('09/27/2022','mm/dd/yyyy'));

insert into cs.du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('SEZC', 'OR_DATE_BIR', to_date('09/26/2022','mm/dd/yyyy'));

commit;