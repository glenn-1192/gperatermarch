alter table cs.ext_payment_transactions add batch_no number(15);

ALTER TABLE cs.or_extract_params
DROP CONSTRAINT C28_SYS_C0028797;

ALTER TABLE cs.or_extract_params
DROP CONSTRAINT C28_SYS_C0028798;