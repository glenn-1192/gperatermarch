update cs.ext_payment_items
set print_priority = 21
where pay_code = 'AR-VAT';

commit;