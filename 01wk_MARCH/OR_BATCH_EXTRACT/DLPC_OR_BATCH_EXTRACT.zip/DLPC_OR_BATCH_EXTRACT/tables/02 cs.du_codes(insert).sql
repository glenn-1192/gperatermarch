

insert into cs.du_codes (DU_CODE, DU_DESCRIPTION, STATUS)
values ('DLPC', ' Davao Light and Power Company', 'A');

commit;
