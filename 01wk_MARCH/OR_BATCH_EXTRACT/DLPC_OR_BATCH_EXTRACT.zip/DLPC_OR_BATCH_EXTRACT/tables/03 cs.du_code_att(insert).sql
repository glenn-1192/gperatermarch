insert into cs.du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('DLPC', 'CAS_PERMIT_NO', '04-2016-123-0008-00006');

insert into cs.du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('DLPC', 'CAS_PERMIT_NO_DESCR', 'BIR Permit to use no.:');

insert into cs.du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('DLPC', 'CAS_PERMIT_NO_DESCR_OLD_0', 'CAS BIR Permit No.');

insert into cs.du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('DLPC', 'CAS_PERMIT_NO_DESCR_OLD_1', 'Permit to use (PTU) No.');

insert into cs.du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('DLPC', 'CAS_PERMIT_NO_OLD_0', '04-2016-123-0008-00001');

insert into cs.du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('DLPC', 'CAS_PERMIT_NO_SEPARATOR', '_PTU_CAS_');

insert into cs.du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('DLPC', 'DATA_SOURCE', 'CCB');

insert into cs.du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('DLPC', 'DATE_OF_ISSUANCE', '04/12/2016');

insert into cs.du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('DLPC', 'DATE_OF_ISSUANCE_DESCR', 'Date of Issuance:');

insert into cs.du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('DLPC', 'CAS_PERMIT_AC_DESCR', 'Acknowledgment Certificate No.:');

insert into cs.du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('DLPC', 'SEQ_AC_DESCR', 'Series:');

insert into cs.du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('DLPC', 'CAS_PERMIT_ON_OLD_0', 'On :');

insert into cs.du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('DLPC', 'VERSION_RELEASE_1', 'This is BIR approved system generated report from Online Receipting System Version 2 Release 2');

insert into cs.du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('DLPC', 'GENERATED_MSG_NEW', ' ');

insert into cs.du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('DLPC', 'GET_OLD2_PERMIT_EFF_FROM', '08/01/2020');

insert into cs.du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('DLPC', 'GET_OLD2_PERMIT_EFF_TO', '06/30/2022');

insert into cs.du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('DLPC', 'DU_ADDRESS', 'Aboitiz Corporate Center Bldg., Gov. Manuel A. Cuenco Avenue, Kasambagan, Cebu City 6000');

insert into cs.du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('DLPC', 'DU_BUS_STYLE', 'Davao Light and Power Company');

insert into cs.du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('DLPC', 'DU_EMAIL', 'davaolight@aboitiz.com');

insert into cs.du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('DLPC', 'DU_FACEBOOK', 'Davaolightofficial');

insert into cs.du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('DLPC', 'DU_TEL_NO', '(082) 229-3572(DLPC)');

insert into cs.du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('DLPC', 'DU_TIN', '000-553-043-00000');

insert into cs.du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('DLPC', 'EFFECTIVE_DATE_DESCR', 'Effective Date:');

insert into cs.du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('DLPC', 'EFFECTIVE_DATE_FROM', '08/01/2020');

insert into cs.du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('DLPC', 'EFFECTIVE_DATE_TO', '07/31/2025');

insert into cs.du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('DLPC', 'END_SEQ_0', '199999999');

insert into cs.du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('DLPC', 'END_SEQ_1', '399999999');

insert into cs.du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('DLPC', 'GENERATED_MSG', 'THIS IS A SYSTEM GENERATED OFFICIAL RECEIPT');

insert into cs.du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('DLPC', 'GENERATED_MSG_AR', 'THIS DOCUMENT IS NOT VALID FOR CLAIM OF INPUT TAX');

insert into cs.du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('DLPC', 'GENERATED_MSG_OR', 'THIS RECEIPT SHALL BE VALID FOR FIVE(5) YEARS FROM THE DATE OF PERMIT TO USE');

insert into cs.du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('DLPC', 'GET_NEW_PERMIT_EFF', '09/22/2022');

insert into cs.du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('DLPC', 'GET_OLD_PERMIT_EFF_FROM', '07/01/2022');

insert into cs.du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('DLPC', 'GET_OLD_PERMIT_EFF_TO', '09/21/2022');

insert into cs.du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('DLPC', 'OR_PREFFIX', '000');

insert into cs.du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('DLPC', 'SEQ_DESCR', 'Series No.:');

insert into cs.du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('DLPC', 'START_SEQ_0', '1');

insert into cs.du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('DLPC', 'START_SEQ_1', '300000001');

insert into cs.du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('DLPC', 'VERSION_RELEASE', 'This is BIR approved system generated report from Online Receipting System Version 2 Release 2 No Signature is required.');

insert into cs.du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('DLPC', 'DU_WEBSITE', 'www.davaolight.com');

insert into cs.du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('DLPC', 'DU_FAX_NO', 'Fax.(082) 221-2105');

insert into cs.du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('DLPC', 'DU_ADDRESS_001', '163-165 C Bangoy St., Barangay 4-A (Pob.) Poblacion District Davao City Davao Del Sur Philippines 8000');

insert into cs.du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('DLPC', 'DU_ADDRESS_003', 'Bldg 1 Door 1 & 2 Ms Land Complex Fronting Toyota Matina Crossing Talomo Davao City Davao Del Sur Philippines 8000');

insert into cs.du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('DLPC', 'DU_ADDRESS_004', 'G/F NCCC Building J.P. Laurel Avenue Barangay 20-B (Pob.) Poblacion District Davao City Davao Del Sur Philippines 8000 ');

insert into cs.du_code_att (DU_CODE, ATT_CODE, ATT_VALUE)
values ('DLPC', 'DU_ADDRESS_005', 'Ground Floor Rivera Medical Center, Inc., Prk. 5, San Francisco (Pob.) City of Panabo Davao Del Norte Philippines 8105');

commit;