-- Create table
create table EXT_FOP_CR_DR_CARDS
(
  ext_batch_no     NUMBER not null,
  tran_no          NUMBER not null,
  seq_no           NUMBER not null,
  service_provider VARCHAR2(50),
  tran_type        VARCHAR2(20),
  card_type        VARCHAR2(50),
  ref_no           VARCHAR2(50),
  trace_no         VARCHAR2(50)
);
-- Create/Recreate primary, unique and foreign key constraints 
alter table EXT_FOP_CR_DR_CARDS
  add constraint EXT_FOP_CR_DR_CARDS_PK primary key (EXT_BATCH_NO, TRAN_NO, SEQ_NO);
alter table EXT_FOP_CR_DR_CARDS
  add constraint EXT_FOP_CR_DR_CARDS_FK foreign key (EXT_BATCH_NO, TRAN_NO, SEQ_NO)
  references EXT_FORMS_OF_PAYMENTS (EXT_BATCH_NO, TRAN_NO, SEQ_NO);
-- Grant/Revoke object privileges 
grant select on EXT_FOP_CR_DR_CARDS to KATAMBAK_USER;
