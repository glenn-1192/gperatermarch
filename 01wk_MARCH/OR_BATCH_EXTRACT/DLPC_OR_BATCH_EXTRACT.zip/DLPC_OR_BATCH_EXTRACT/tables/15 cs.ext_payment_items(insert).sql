insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('ADVANCE', 'Advance Payment', '1030105001', 'ADVANCE', null, 150, 0, 0, 1, 30, 0, null, null, null, null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('AR', 'Accounts Receivable', '1030105001', 'AR-ELECTRIC', null, 141, 0, 0, 1, 10, 0, null, null, null, null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('AR-VAT', 'Accounts Receivable VAT', '101022000', 'VAT Amount', null, 100, 0, 0, 1, 20, 0, null, null, null, null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PILFERAGE', 'A/R from pilferage', '1030105001', 'AR-ELECTRIC', null, 155, 0, 0, 1, 10, 0, null, null, null, null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PPVAT-DLPC', 'BIR 2306 PPVAT - DLPC', '1', 'VAT Witholding', null, null, 1, 0, 0, 24, 0, null, null, 'PVO-BIR', 'DLPC');

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PPVAT-HEDCOR', 'BIR 2306 PPVAT - HEDCOR', '1', 'VAT Witholding', null, null, 1, 0, 0, 24, 0, null, null, 'PVO-HED', 'HED');

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PPVAT-HSI', 'BIR 2306 PPVAT - HSI', '1', 'VAT Witholding', null, null, 1, 0, 0, 24, 0, null, null, 'PVO-HSI', 'HSI');

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PPVAT-NPC', 'BIR 2306 PPVAT - PSALM', '1', 'VAT Witholding', null, null, 1, 0, 0, 24, 0, null, null, 'PVO-NPC', 'NPC');

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PPVAT-OTHERS', 'BIR 2306 PPVAT - OTHERS', '1', 'VAT Witholding', null, null, 1, 0, 0, 24, 0, null, null, 'PVO-BIR', 'OTH');

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('xxxPPVAT-Transco', 'BIR 2306 PPVAT - NGCP', '1', 'VAT Witholding', null, null, 1, 0, 0, 24, 0, null, null, 'PVO-NTC', 'TCO');

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PPWTAX', 'BIR 2307 PPWTAX', '1', 'Expanded Witholding', null, null, 1, 0, 0, 26, 0, null, null, 'C-BIR2307', '2307');

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-ADV-OTCC', 'Advances - Over The Counter- Confi/Management', '1030212020', 'Advances - Over The Counter- Confi/Management', null, null, 0, 1, 0, null, 0, null, null, 'M-ADV-OTCC', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-AFF-DVOW', 'Receivable From Davao Wood', '1030208017', 'Receivable From Davao Wood', null, null, 0, 1, 0, null, 0, null, null, 'M-AFF-DVOW', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-AFF-OTH', 'Receivable From Other Affiliates', '1030208999', 'Receivable From Other Affiliates', null, null, 0, 1, 0, null, 0, null, null, 'M-AFF-OTH ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-AFF-VECO', 'Receivable From VECO', '1030208011', 'Receivable From VECO', null, null, 0, 1, 0, null, 0, null, null, 'M-AFF-VECO', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-CLA-BUM', 'Claims From Bump Poles', '9019999999', 'Claims From Bump Poles', null, null, 0, 1, 0, null, 0, null, null, 'M-CLA-BUM ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-CLA-IMP', 'Collection From Claims From Importation', '1030203002', 'Collection From Claims From Importation', null, null, 0, 1, 0, null, 0, null, null, 'M-CLA-IMP ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-CLA-SHP', 'Collection From Claims From Shipment', '1030203003', 'Collection From Claims From Shipment', null, null, 0, 1, 0, null, 0, null, null, 'M-CLA-SHP ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-COL-BDR', 'Bad Debts Recovery', '9019999002', 'Bad Debts Recovery', null, null, 0, 1, 0, null, 1, null, null, 'M-COL-BDR ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-CON-COT', 'Non-Trade Rec. - Cotrades', '1030209006', 'Non-Trade Rec. - Cotrades', null, null, 0, 1, 0, null, 0, null, null, 'M-CON-COT ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-CON-LSB', 'Non-Trade Rec.- Lsb', '1030209014', 'Non-Trade Rec.- Lsb', null, null, 0, 1, 0, null, 0, null, null, 'M-CON-LSB ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-CON-PSE', 'Non-Trade Rec. - Pseco', '1030209007', 'Non-Trade Rec. - Pseco', null, null, 0, 1, 0, null, 0, null, null, 'M-CON-PSE ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-COO-COS', 'Non-Trade Rec. - Coserv', '1030209019', 'Non-Trade Rec. - Coserv', null, null, 0, 1, 0, null, 0, null, null, 'M-COO-COS ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-COO-DESC', 'Non-Trade Rec. - Descoop', '1030209002', 'Non-Trade Rec. - Descoop', null, null, 0, 1, 0, null, 0, null, null, 'M-COO-DESC', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-COO-PRO', 'Non-Trade Rec.- Procserv', '1030209011', 'Non-Trade Rec.- Procserv', null, null, 0, 1, 0, null, 0, null, null, 'M-COO-PRO ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-OTH-CPP', 'Other Income - Compromise Penalty (Pilferage)', '9019999999', 'Other Income - Compromise Penalty (Pilferage)', null, null, 0, 1, 0, null, 1, null, null, 'M-OTH-CPP ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-REN-CR', 'Rental Income - Car-Rental', '9019901004', 'Rental Income - Car-Rental', null, null, 0, 1, 0, null, 1, null, null, 'M-REN-CR  ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PVO-HSI', 'Prepaid Vat Output - Hsi', '1050106011', 'Prepaid Vat Output - Hsi', null, null, 0, 1, 0, null, 1, null, null, 'PVO-HSI   ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-AFF-HED', 'Receivable From Hedcor', '1030208007', 'Receivable From Hedcor', null, null, 0, 1, 0, null, 0, null, null, 'M-AFF-HED ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-AFF-CLPC', 'Receivable From Clpc', '1030208012', 'Receivable From Clpc', null, null, 0, 1, 0, null, 0, null, null, 'M-AFF-CLPC', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-AFF-SEZC', 'Receivable From Sezc', '1030208013', 'Receivable From Sezc', null, null, 0, 1, 0, null, 0, null, null, 'M-AFF-SEZC', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-AFF-PIL', 'Receivable From Pilmico', '1030208014', 'Receivable From Pilmico', null, null, 0, 1, 0, null, 0, null, null, 'M-AFF-PIL ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-AFF-ACO', 'Receivable From Aco', '1030208015', 'Receivable From Aco', null, null, 0, 1, 0, null, 0, null, null, 'M-AFF-ACO ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-AFF-PDCP', 'Receivable From Pdcp', '1030208016', 'Receivable From Pdcp', null, null, 0, 1, 0, null, 0, null, null, 'M-AFF-PDCP', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-ADV-DEN', 'Advances - Dental - Rank And File', '1030212003', 'Advances - Dental - Rank And File', null, null, 0, 1, 0, null, 0, null, null, 'M-ADV-DEN ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-ADV-DENC', 'Advances - Dental - Confi/Management', '1030212004', 'Advances - Dental - Confi/Management', null, null, 0, 1, 0, null, 0, null, null, 'M-ADV-DENC', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-ADV-EDU', 'Advances - Educational Plans', '1030212005', 'Advances - Educational Plans', null, null, 0, 1, 0, null, 0, null, null, 'M-ADV-EDU ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-ADV-HOS', 'Advances - Hospitalization - Rank And File', '1030212008', 'Advances - Hospitalization - Rank And File', null, null, 0, 1, 0, null, 0, null, null, 'M-ADV-HOS ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-ADV-HOSC', 'Advances - Hospitalization - Confi/Management', '1030212009', 'Advances - Hospitalization - Confi/Management', null, null, 0, 1, 0, null, 0, null, null, 'M-ADV-HOSC', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-ADV-MED', 'Advances - Medical - Rank And File', '1030212010', 'Advances - Medical - Rank And File', null, null, 0, 1, 0, null, 0, null, null, 'M-ADV-MED ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-ADV-MEDP', 'Advances - Medical - Cash', '1030212011', 'Advances - Medical - Cash', null, null, 0, 1, 0, null, 0, null, null, 'M-ADV-MEDP', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-ADV-MEDC', 'Advances - Medical - Confi/Management', '1030212012', 'Advances - Medical - Confi/Management', null, null, 0, 1, 0, null, 0, null, null, 'M-ADV-MEDC', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-ADV-MEDO', 'Advances - Medical Others', '1030212013', 'Advances - Medical Others', null, null, 0, 1, 0, null, 0, null, null, 'M-ADV-MEDO', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-ADV-MEC', 'Advances - Medicine - Rank And File', '1030212014', 'Advances - Medicine - Rank And File', null, null, 0, 1, 0, null, 0, null, null, 'M-ADV-MEC ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-ADV-MECC', 'Advances - Medicine - Confi/Management', '1030212015', 'Advances - Medicine - Confi/Management', null, null, 0, 1, 0, null, 0, null, null, 'M-ADV-MECC', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-ADV-MOT', 'Advances - Motor Bike Plans', '1030212016', 'Advances - Motor Bike Plans', null, null, 0, 1, 0, null, 0, null, null, 'M-ADV-MOT ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-ADV-OPT', 'Advances - Optical - Rank And File', '1030212017', 'Advances - Optical - Rank And File', null, null, 0, 1, 0, null, 0, null, null, 'M-ADV-OPT ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-ADV-OPTC', 'Advances - Optical - Confi/Management', '1030212018', 'Advances - Optical - Confi/Management', null, null, 0, 1, 0, null, 0, null, null, 'M-ADV-OPTC', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-SUSPEN', 'Misc - Suspense Service Agreement', '1050999999', 'MISC - SUSPENSE SERVICE AGREEMENT', null, null, 0, 1, 0, null, 0, null, null, 'DUMMY     ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('D-SCPL', 'Deposits - Special Old Accounts SA', '4010301004', 'DEPOSITS - SPECIAL OLD ACCOUNTS', null, null, 0, 1, 0, null, 0, null, null, 'CDP-BILL  ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('D-BILL', 'Deposits - Bill Deposit SA', '4010301004', 'BILL DEPOSIT', null, null, 0, 1, 0, null, 0, null, null, 'CDP-BILL  ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('D-LIPO', 'Deposits - Lines and Poles Special Advance Deposit SA', '4010301003', 'LINES AND POLES ADVANCE', null, null, 0, 1, 0, null, 0, null, null, 'CDP-LIPO  ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PA-BKBIL', 'PA - Payment Arrangement SA for Backbilling', '1030105001', 'PA - BACKBILLING', null, null, 0, 1, 0, null, 1, null, null, 'AR-ELC    ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('D-XFMR', 'Deposits - Transformer Special Advance Deposit SA', '4010301006', 'DEPOSITS - TRANSFORMER SPECIAL ADVANCE', null, null, 0, 1, 0, null, 0, null, null, 'CDP-XFMR  ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PA-PILFR', 'PA - Payment Arrangement SA for Pilferage', '1030105001', 'PA - PILFERAGE', null, null, 0, 1, 0, null, 1, null, null, 'AR-ELC    ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PA-NORM', 'PA - Payment Arrangement SA for Arrears', '1030105001', 'PA - ARREARS', null, null, 0, 1, 0, null, 1, null, null, 'AR-ELC    ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('D-LABR', 'Deposits - Special Labor Advance Deposit SA', '4010301007', 'SPECIAL LABOR ADVANCE', null, null, 0, 1, 0, null, 0, null, null, 'CDP-LABR  ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-BCHARG', 'Misc - Billable Charge', '1030105001', 'MISC - BILLABLE CHARGE', null, null, 0, 1, 0, null, 0, null, null, 'AR-ELC    ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PA-NR', 'PA - Payment Arrangement SA for Notes Receivable', '1030105001', 'PA - NOTES RECEIVABLE', null, null, 0, 1, 0, null, 1, null, null, 'AR-ELC    ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-WOALL', 'Misc - Write Off Service Agreement', '1030199001', 'MISC - WRITE OFF SERVICE AGREEMENT', null, null, 0, 1, 0, null, 1, null, null, 'AR-ABD    ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('D-KVA', 'Deposits - KVA Capacity Advance Deposit SA', '4010301008', 'KVA CAPACITY ADVANCE', null, null, 0, 1, 0, null, 0, null, null, 'CDP-KVAR  ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-SUBSDY', 'Misc - Employee Subsidy', '1050999999', 'MISC - EMPLOYEE SUBSIDY', null, null, 0, 1, 0, null, 0, null, null, 'DUMMY     ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-CBCHG', 'Misc - CIS Billable Charge', '1010189007', 'MISC - CIS BILLABLE CHARGE', null, null, 0, 1, 0, null, 0, null, null, 'CLR-MISC  ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-PAY-REN', 'Payable-Pole Rental', '3010299005', 'Payable-Pole Rental', null, null, 0, 1, 0, null, 0, null, null, 'M-PAY-REN ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-OTH-SFA', 'Other Income - Sale Of Property, Plant And Equipment', '9010401001', 'Other Income - Sale Of Property, Plant And Equipment', null, null, 0, 1, 0, null, 1, null, null, 'M-OTH-SFA ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-VAT-R', 'Vat Output Rental-Regular Vat', '3010212009', 'Vat Output Rental-Regular Vat', null, null, 0, 1, 0, null, 1, null, null, 'M-VAT-R   ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-ADV-OTC', 'Advances - Over-The-Counter Medicines - Rank And File', '1030212019', 'Advances - Over-The-Counter Medicines - Rank And File', null, null, 0, 1, 0, null, 0, null, null, 'M-ADV-OTC ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-ADV-TEL', 'Advances-Telephone Toll', '1030212021', 'Advances-Telephone Toll', null, null, 0, 1, 0, null, 0, null, null, 'M-ADV-TEL ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-ADV-OTH', 'Advances-Others', '1030212999', 'Advances-Others', null, null, 0, 1, 0, null, 0, null, null, 'M-ADV-OTH ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-ADV-UCA', 'Unexpended Cash Advance', '1030213001', 'Unexpended Cash Advance', null, null, 0, 1, 0, null, 0, null, null, 'M-ADV-UCA ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-CLA-INS', 'Collection From Insurance Claim', '1030203001', 'Collection From Insurance Claim', null, null, 0, 1, 0, null, 0, null, null, 'M-CLA-INS ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-CLA-SSS', 'Collection From Claims From Sss', '1030203004', 'Collection From Claims From Sss', null, null, 0, 1, 0, null, 0, null, null, 'M-CLA-SSS ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-CLA-OTH', 'Accounts Receivable Miscellaneous Claims', '1030203999', 'Accounts Receivable Miscellaneous Claims', null, null, 0, 1, 0, null, 0, null, null, 'M-CLA-OTH ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-CLA-DAM', 'Claim Damages', '9019999999', 'Claim Damages', null, null, 0, 1, 0, null, 0, null, null, 'M-CLA-DAM ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-CLA-BGC', 'Claims From Broken Glass Cover', '9019999999', 'Claims From Broken Glass Cover', null, null, 0, 1, 0, null, 0, null, null, 'M-CLA-BGC ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PVO-NPC', 'Prepaid Vat Output - Npc', '1050106008', 'Prepaid Vat Output - Npc', null, null, 0, 1, 0, null, 1, null, null, 'PVO-NPC   ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-REN-MR', 'Rental Income - Motorbike-Rental', '9019901004', 'Rental Income - Motorbike-Rental', null, null, 0, 1, 0, null, 1, null, null, 'M-REN-MR  ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('C-BIR2307', 'Cash - Prepaid Income Tax Bir Form 2307', '1050106001', 'Cash - Prepaid Income Tax Bir Form 2307', null, null, 0, 1, 0, null, 1, null, null, 'C-BIR2307 ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-CLA-SMTR', 'Claims From Stolen Meter', '9019999999', 'Claims From Stolen Meter', null, null, 0, 1, 0, null, 0, null, null, 'M-CLA-SMTR', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-PET-DVO', 'Petty Cash Fund - Davao  ', '1010302002', 'Petty Cash Fund - Davao  ', null, null, 0, 1, 0, null, 0, null, null, 'M-PET-DVO ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-LAB-TEST', 'Labor/Material For Transformer Testing', '9019905001', 'Labor/Material For Transformer Testing', null, null, 0, 1, 0, null, 1, null, null, 'M-LAB-TEST', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-LAB-PMTS', 'Labor Payments', '9019907002', 'Labor Payments', null, null, 0, 1, 0, null, 1, null, null, 'M-LAB-PMTS', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-COO-ASC', 'Non-Trade Rec. - Ascoop', '1030209001', 'Non-Trade Rec. - Ascoop', null, null, 0, 1, 0, null, 0, null, null, 'M-COO-ASC ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-COO-DISC', 'Non-Trade Rec. - Discoop', '1030209003', 'Non-Trade Rec. - Discoop', null, null, 0, 1, 0, null, 0, null, null, 'M-COO-DISC', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-COO-COM', 'Non-Trade Rec. - Comet', '1030209005', 'Non-Trade Rec. - Comet', null, null, 0, 1, 0, null, 0, null, null, 'M-COO-COM ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-COO-MDS', 'Non-Trade Rec.- Mdsdc', '1030209008', 'Non-Trade Rec.- Mdsdc', null, null, 0, 1, 0, null, 0, null, null, 'M-COO-MDS ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-COO-CPR', 'Non-Trade Rec.- C-Prime', '1030209022', 'Non-Trade Rec.- C-Prime', null, null, 0, 1, 0, null, 0, null, null, 'M-COO-CPR ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-CON-ESA', 'Non-Trade Rec. - Esaccoop', '1030209004', 'Non-Trade Rec. - Esaccoop', null, null, 0, 1, 0, null, 0, null, null, 'M-CON-ESA ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-CON-PLE', 'Non-Trade Rec.- Plecs', '1030209009', 'Non-Trade Rec.- Plecs', null, null, 0, 1, 0, null, 0, null, null, 'M-CON-PLE ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-CON-BLC', 'Non-Trade Rec.- Blcon', '1030209013', 'Non-Trade Rec.- Blcon', null, null, 0, 1, 0, null, 0, null, null, 'M-CON-BLC ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-CON-GEP', 'Non-Trade Rec.- Gepami', '1030209015', 'Non-Trade Rec.- Gepami', null, null, 0, 1, 0, null, 0, null, null, 'M-CON-GEP ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-CON-AGU', 'Non-Trade Rec.- Aguilar', '1030209016', 'Non-Trade Rec.- Aguilar', null, null, 0, 1, 0, null, 0, null, null, 'M-CON-AGU ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-CON-VAL', 'Non-Trade Rec. - Valston', '1030209017', 'Non-Trade Rec. - Valston', null, null, 0, 1, 0, null, 0, null, null, 'M-CON-VAL ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-CON-TOP', 'Non-Trade Rec.- Topspin', '1030209020', 'Non-Trade Rec.- Topspin', null, null, 0, 1, 0, null, 0, null, null, 'M-CON-TOP ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-OTH-V', 'Others - Vat', '9019999999', 'Others - Vat', null, null, 0, 1, 0, null, 1, null, null, 'M-OTH-V   ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-OTH-NV', 'Others - Non Vat', '9019999999', 'Others - Non Vat', null, null, 0, 1, 0, null, 0, null, null, 'M-OTH-NV  ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-REN-PR', 'Rental Income - Pole Rental', '9019901001', 'Rental Income - Pole Rental', null, null, 0, 1, 0, null, 1, null, null, 'M-REN-PR  ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-REN-OR', 'Rental Income - Office Rental', '9019901003', 'Rental Income - Office Rental', null, null, 0, 1, 0, null, 1, null, null, 'M-REN-OR  ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-REN-TR', 'Rental Income - Transformer Rental', '9019901002', 'Rental Income - Transformer Rental', null, null, 0, 1, 0, null, 1, null, null, 'M-REN-TR  ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-MAT-LP', 'Lines And Poles Payment', '9019999004', 'Lines And Poles Payment', null, null, 0, 1, 0, null, 1, null, null, 'M-MAT-LP  ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-MAT-SCP', 'Scrap Materials', '9019903001', 'Scrap Materials', null, null, 0, 1, 0, null, 1, null, null, 'M-MAT-SCP ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-MAT-KWH', 'Kwh Meter Equipment ', '9019904001', 'Kwh Meter Equipment ', null, null, 0, 1, 0, null, 1, null, null, 'M-MAT-KWH ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-MAT-IOS', 'Income On Supplies', '9019906001', 'Income On Supplies', null, null, 0, 1, 0, null, 1, null, null, 'M-MAT-IOS ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-NTR-LMC', 'Lmc Dependent Medical Fund', '1030288001', 'Lmc Dependent Medical Fund', null, null, 0, 1, 0, null, 0, null, null, 'M-NTR-LMC ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-AFF-CPDC', 'Receivable From Cpdc', '1030208018', 'Receivable From Cpdc', null, null, 0, 1, 0, null, 0, null, null, 'M-AFF-CPDC', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-AFF-RDC', 'Receivable From Rdc', '1030208019', 'Receivable From Rdc', null, null, 0, 1, 0, null, 0, null, null, 'M-AFF-RDC ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-AFF-BEZC', 'Receivable From Bezc', '1030208022', 'Receivable From Bezc', null, null, 0, 1, 0, null, 0, null, null, 'M-AFF-BEZC', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-AFF-MEZC', 'Receivable From Mezc', '1030208023', 'Receivable From Mezc', null, null, 0, 1, 0, null, 0, null, null, 'M-AFF-MEZC', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-AFF-APRI', 'Receivable From Apri', '1030208025', 'Receivable From Apri', null, null, 0, 1, 0, null, 0, null, null, 'M-AFF-APRI', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-AFF-TMI', 'Receivable From Therma Marine', '1030208026', 'Receivable From Therma Marine', null, null, 0, 1, 0, null, 0, null, null, 'M-AFF-TMI ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-CSH-O/S', 'Cash Over/Short - Teller Or Collector', '1030201015', 'Cash Over/Short - Teller Or Collector', null, null, 0, 1, 0, null, 0, null, null, 'M-CSH-O/S ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PVO-BIR', 'Prepaid Vat Output - Bir', '1050106007', 'Prepaid Vat Output - Bir', null, null, 0, 1, 0, null, 1, null, null, 'PVO-BIR   ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PVO-NTC', 'Prepaid Vat Output - Ntc', '1050106009', 'Prepaid Vat Output - Ntc', null, null, 0, 1, 0, null, 1, null, null, 'PVO-NTC   ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PVO-HED', 'Prepaid Vat Output - Hedcor', '1050106010', 'Prepaid Vat Output - Hedcor', null, null, 0, 1, 0, null, 1, null, null, 'PVO-HED   ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-NTR-MFED', 'Medical Fund For Employees Dependent', '1030288005', 'Medical Fund For Employees Dependent', null, null, 0, 1, 0, null, 0, null, null, 'M-NTR-MFED', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-OTH-DI', 'Other Income - Cash Dividend  ', '9010101001', 'Other Income - Cash Dividend  ', null, null, 0, 1, 0, null, 1, null, null, 'M-OTH-DI  ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-OTH-BFL', 'Other Income - Busted Fuse Limiter', '9019999999', 'Other Income - Busted Fuse Limiter', null, null, 0, 1, 0, null, 1, null, null, 'M-OTH-BFL ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-OTH-RFL', 'Other Income - Removal Of Fuse Limiter', '9019999999', 'Other Income - Removal Of Fuse Limiter', null, null, 0, 1, 0, null, 1, null, null, 'M-OTH-RFL ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-OTH-PUT', 'Other Income - Penalty-Unauthorized Transfer Of Meters', '9019999999', 'Other Income - Penalty-Unauthorized Transfer Of Meters', null, null, 0, 1, 0, null, 1, null, null, 'M-OTH-PUT ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-OTH-PIC', 'Other Income - Penalty-Illegal Connection', '9019999999', 'Other Income - Penalty-Illegal Connection', null, null, 0, 1, 0, null, 1, null, null, 'M-OTH-PIC ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-OTH-PTM', 'Other Income - Penalty-Tampered Meter', '9019999999', 'Other Income - Penalty-Tampered Meter', null, null, 0, 1, 0, null, 1, null, null, 'M-OTH-PTM ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-VAT-G', 'Vat Output-Goods-Regular Vat', '3010212005', 'Vat Output-Goods-Regular Vat', null, null, 0, 1, 0, null, 1, null, null, 'M-VAT-G   ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-VAT-O', 'Vat Output Others-Regular Vat', '3010212013', 'Vat Output Others-Regular Vat', null, null, 0, 1, 0, null, 1, null, null, 'M-VAT-O   ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-AFF-AEV', 'Receivable From Aev', '1030208003', 'Receivable From Aev', null, null, 0, 1, 0, null, 0, null, null, 'M-AFF-AEV ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-AFF-AGFI', 'Receivable From Agfi', '1030208004', 'Receivable From Agfi', null, null, 0, 1, 0, null, 0, null, null, 'M-AFF-AGFI', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-AFF-APC', 'Receivable From Apc', '1030208005', 'Receivable From Apc', null, null, 0, 1, 0, null, 0, null, null, 'M-AFF-APC ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-AFF-AESI', 'Receivable From Apsi / Aes', '1030208006', 'Receivable From Apsi / Aes', null, null, 0, 1, 0, null, 0, null, null, 'M-AFF-AESI', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('MPPWTAX', 'BIR 2307 PPWTAX', '1', 'BIR 2307', null, null, 0, 1, 0, 4, 0, 0.00, null, 'C-BIR2307', '2307');

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-REN-WF', 'Non-trade Rec.-Wheeling Fee', '1030201001', 'Non-trade Rec.-Wheeling Fee', null, null, 0, 1, 0, null, 0, 0.00, null, 'M-REN-WF  ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-NTR-MISC', 'Non Trade Receivable - Miscellaneous', '1030288999', 'Non Trade Receivable - Miscellaneous', null, null, 0, 1, 0, null, 0, null, null, 'M-NTR-MISC', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-PAY-CSB', 'Payable to Affiliate - CSB', '3010209015', 'Payable to Affiliate - CSB', null, null, 0, 1, 0, null, 0, null, null, 'M-PAY-CSB ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('E-PFR', 'Electric - Pilferage', '1030105001', 'ELECTRIC - PILFERAGE', null, null, 0, 1, 0, null, 1, null, null, 'AR-ELC    ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PPVAT-TMI', 'BIR 2306 PPVAT - TMI', '1', 'VAT Witholding', null, null, 1, 0, 0, 24, 0, null, null, 'PVO-TMI', 'TMI');

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('MPPV-O', 'BIR 2306 PPVAT - OUTPUT', '1', 'BIR 2306', null, null, 0, 1, 0, 4, 0, 0.00, null, 'PVO-BIR   ', 'DLPC');

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('CDP-ELEQPT', 'Customer''s Deposit - Electrical Equipment', '4010301010', 'Customer''s Deposit - Electrical Equipment', null, null, 0, 1, 0, null, 0, null, null, 'CDP-ELEQPT', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('CDP-SSF', 'Customer''s Deposit - Site, Structure & Foundation', '4010301010', 'Customer''s Deposit - Site, Structure & Foundation', null, null, 0, 1, 0, null, 0, null, null, 'CDP-ELEQPT', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('CDP-MSE', 'Customer''s Deposit - Miscellaneous Substation Equipment', '4010301010', 'Customer''s Deposit - Miscellaneous Substation Equipment', null, null, 0, 1, 0, null, 0, null, null, 'CDP-ELEQPT', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('CDP-ES', 'Customer''s Deposit - Earthing System', '4010301010', 'Customer''s Deposit - Earthing System', null, null, 0, 1, 0, null, 0, null, null, 'CDP-ELEQPT', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('CDP-PE', 'Customer''s Deposit - Protective Equipment', '4010301010', 'Customer''s Deposit - Protective Equipment', null, null, 0, 1, 0, null, 0, null, null, 'CDP-ELEQPT', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('CDP-MCE', 'Customer''s Deposit - Metering and Control Equipment', '4010301010', 'Customer''s Deposit - Metering and Control Equipment', null, null, 0, 1, 0, null, 0, null, null, 'CDP-ELEQPT', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PPVAT-PEMC', 'BIR 2306 PPVAT - PEMC', '1', 'VAT Witholding', null, null, 1, 0, 0, 24, 0, null, null, 'PVO-IME', 'IMEM');

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PPVAT-TSI', 'BIR 2306 PPVAT - TSI', '1', 'VAT Witholding', null, null, 1, 0, 0, 24, 0, null, null, 'PVO-TSI', 'TSI');

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PPVAT-WMP', 'BIR 2306 PPVAT-WMPC', '1050107018', 'VAT Witholding', null, null, 1, 0, 0, 24, 0, null, null, 'PVO-WMP', 'WMPC');

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('VAT-SALES', 'VAT Sales', '0', 'VAT Sales', null, 10, 0, 0, 1, 12, null, null, null, null, null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('NON-VAT-SALES', 'Non-VAT Sales', '0', 'Non-VAT Sales', null, 14, 0, 0, 1, 14, null, null, null, null, null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('VAT-0-RATED', 'VAT Zero Rated Sales', '0', 'VAT Zero Rated Sales', null, 16, 0, 0, 1, 16, null, null, null, null, null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('BIR2306', 'BIR2306', '0', 'VAT Witholding', null, 24, 1, 0, 0, 24, null, null, null, null, null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('BIR2307', 'BIR2307', '0', 'Expanded Witholding', null, 26, 1, 0, 0, 26, null, null, null, null, null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PPVAT-SPPC', 'BIR 2306 PPVAT - SPPC', '1050107020', 'VAT Witholding', null, null, 1, 0, 0, 24, 0, null, null, 'PVO-SPPC', 'SPPC');

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('A/R NT-PR', 'Misc - Other Charges', '1', 'Misc - Other Charges', null, null, 0, 1, 0, 10, 1, null, null, 'A/R NT-PR', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-OSBCHG', 'Misc - Other Services Billable Charge', '1030201009', 'OTHER SERVICES PAYABLE', null, null, 0, 1, 0, 10, 0, null, null, 'A/R-NTSR', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-OSS2', 'OSS Service Rev-Bills Elek', '6020109001', 'OSS SRVC REV-BILIS ELEK', null, null, 0, 1, 0, 10, 0, null, null, 'M-OSS REV ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-VAT-OSS2', 'VAT OUTPUT - Bills Elek', '3010217001', 'VAT OUTPUT - BILLS ELEK', null, null, 0, 1, 0, 10, 1, null, null, 'A/P-VATOOR', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('MPPTAX-DLPC', '(MPPWTAX) BIR 2306 PPWTAX', '1050107001', '(MPPWTAX) BIR 2306 PPWTAX', null, null, 0, 1, 0, 10, 0, null, null, 'PVO-BIR', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PPVAT-SMCP', 'BIR 2306 PPVAT-SMCP', '1050107022', 'VAT Witholding', null, null, 1, 0, 0, 24, 0, null, null, 'PVO-SMCPC', 'SMCP');

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-ADV-OTHE', 'Advances-Others', '1030212099', 'Advances-Others', null, null, 0, 1, 0, 10, 0, null, null, 'M-ADV-OTHE', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('A/P-NON-MS', 'DLPC A/P NON-TRADE - MISC', '3010211001', 'DLPC A/P NON-TRADE - MISC', null, null, 0, 1, 0, 10, 1, null, null, 'A/P-NON-MS', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-OTHCHR', 'Pole Rental Payable', '9019001002', 'POLE RENTAL PAYABLE', null, null, 0, 1, 0, null, 0, null, null, 'A/R NT-PR ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-REIN-POL3', 'Rental Income - Pole Rental', '9019001002', 'RENTAL INCOME - POLE RENTAL', null, null, 0, 1, 0, 10, 0, null, null, 'UI-MISC   ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-VATO-R3', 'VAT Output Rental - Regular VAT', '3010216001', 'VAT OUTPUT RENTAL - REGULAR VAT', null, null, 0, 1, 0, 20, 1, null, null, 'DV-VATOP  ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-ADV-PERS', 'Advances - Personal', '1030212002', 'Advances - Personal', null, null, 0, 1, 0, null, 0, null, null, 'M-ADV-PERS', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PPVAT-NGCP WMPC', 'BIR 2306 PPVAT - NGCP WMPC', '1050107003', 'VAT Witholding', null, null, 1, 0, 0, 24, 0, null, null, 'PVO-NGWMPC', 'NGMP');

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PPVAT-NGCP TMI', 'BIR 2306 PPVAT - NGCP TMI', '1050107003', 'VAT Witholding', null, null, 1, 0, 0, 24, 0, null, null, 'PVO-NGTMI', 'NGTM');

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PPVAT-NGCP PSALM', 'BIR 2306 PPVAT - NGCP PSALM', '1050107003', 'VAT Witholding', null, null, 1, 0, 0, 24, 0, null, null, 'PVO-NGPSAL', 'NGPS');

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PPVAT-NGCP KEGI', 'BIR 2306 PPVAT - NGCP KEGI', '1050107003', 'VAT Witholding', null, null, 1, 0, 0, 24, 0, null, null, 'PVO-NGKEGI', 'NGKE');

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PPVAT-NGCP', 'BIR 2306 PPVAT - NGCP', '1050107003', 'VAT Witholding', null, null, 1, 0, 0, 24, 0, null, null, 'PVO-NGCP', 'NGCP');

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('UC-FIT_ALL', 'UC and FIT Allowance', '0', 'UC/Fit-All', null, 100, 0, 0, 1, 20, 0, null, null, null, null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('VAT-EXEMPT', 'VAT Exempt Sales', '0', 'VAT Exempt Sales', null, 12, 0, 0, 1, 14, 0, null, null, null, null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PA-WOFF2', 'Payment Arrangement - Write off', '1030101012', 'Payment Arrangement', null, null, 0, 0, 1, 29, 0, null, null, 'ALBADDEBT ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PPVAT-NGCP UPMACO', 'BIR 2306 PPVAT - UPSI', '1080511001', 'VAT Witholding', null, null, 1, 0, 0, 24, 0, null, null, 'PVO-NUPSI', 'UPSI');

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('A/R-NT-OTH', 'A/R Non-Trade Others', '1030201099', 'A/R Non-Trade Others', null, null, 0, 1, 0, 10, 0, null, null, 'A/R-NT-OTH', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('A/R-NTSC', 'A/R Non Trade-Service Connection', '1030201016', 'A/R Non Trade-Service Connection', null, null, 0, 1, 0, 10, 0, null, null, 'A/R-NTSC', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-NTR-RFND', 'DLPC Revolving Fund', '1010300005', 'DLPC Revolving Fund', null, null, 0, 1, 0, 10, 0, null, null, 'M-NTR-RFND', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-REC-DEP', 'Recoverable Deposit', '1030204001', 'Recoverable Deposit', null, null, 0, 1, 0, null, 0, null, null, 'M-REC-DEP', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-PCBCHG', 'Misc - Pilferage CIS Billable Charge', '2040100002', 'Misc - Pilferage CIS Billable Charge', null, null, 0, 1, 0, 10, 0, null, null, 'NR-VOC ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('M-CD/TPA', 'TPA Collection Depository', '1030100001', 'COLLECTION DEPOSIT', null, null, 0, 1, 0, 10, 0, null, null, 'AR-TPA    ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PPVAT-IEMOP', 'BIR 2306 PPVAT - IEMOP', '1080511001', 'VAT Witholding', null, null, 1, 0, 0, 24, 0, null, null, 'PVO-IEMOP', 'IEMO');

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PA-WOFF', 'Payment Arrangement - Write off', '1030101012', 'Payment Arrangement', null, null, 0, 1, 0, 29, 0, null, null, 'ALBADDEBT ', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('D-ELEQPT', 'Deposits - Electrical Equipment Special Deposit SA', '4090101091', 'DEPOSITS - ELECTRICAL EQUIPMENT SPECIAL', null, null, 0, 1, 0, null, 0, null, null, 'CDP-ELEQPT', null);

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PPVAT-NGCP MPC', 'BIR 2306 PPVAT - MPC', '3011101001', 'VAT Witholding', null, null, 1, 0, 0, 24, 0, null, null, 'PVO-NMPC', 'MPC');

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PPVAT-NGCP UPMALITA', 'BIR 2306 PPVAT - UMB', '3011101001', 'VAT Witholding', null, null, 1, 0, 0, 24, 0, null, null, 'PVO-NUMB', 'UMB');

insert into cs.ext_payment_items (PAY_CODE, DESCRIPTION, GL_ACCT_CODE, PRINT_LABEL, FEEDBACK_PROC, PAY_PRIORITY, AR_CREDIT, MISCELLANEOUS, AR, PRINT_PRIORITY, MISC_VATABLE, MISC_DEFAULT_AMT, MISC_VAT_PAY_CODE, DST_ID, TENDER_TYPE_CD)
values ('PPVAT-NGCP UPSI', 'xxxxxBIR 2306 PPVAT - UPSI', '1080511001', 'VAT Witholding', null, null, 1, 0, 0, 24, 0, null, null, 'PVO-NUPSI', 'UPSI');

commit;