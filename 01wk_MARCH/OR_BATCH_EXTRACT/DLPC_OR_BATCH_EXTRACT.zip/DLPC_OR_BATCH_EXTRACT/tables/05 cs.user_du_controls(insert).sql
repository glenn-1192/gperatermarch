

insert into cs.user_du_controls (USERNAME, DU_CODE)
values ('JCOVERO', 'DLPC');

insert into cs.user_du_controls (USERNAME, DU_CODE)
values ('JBILASON', 'DLPC');

commit;
