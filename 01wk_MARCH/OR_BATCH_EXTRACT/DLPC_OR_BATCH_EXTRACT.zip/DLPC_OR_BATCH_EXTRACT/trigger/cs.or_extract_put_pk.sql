CREATE OR REPLACE TRIGGER or_extract_put_pk
before insert on "OR_EXTRACT_PARAMS"
for each row
begin
   begin
      select ext_batch_numbers.nextval
      into   :new.ext_batch_no
      from   dual;
   exception
      when others
   then
      raise_application_error(-20001, sqlerrm);
   end;
end;
